const $=id=>document.getElementById(id);
let positions=[], initialPositions=[], edges=[], geometricEdges=[], radioEdges=[], simulationEdges=[], routingEdges=[], nodeResults=[], selected=-1, dragging=-1, cfgBase=null, radioProfiles={}, pluginMeta={}, lastRun=false, lastExperiment=null;
let trace=[], scientificTrace=[], mobilityTrace=[], packetTrace=[], traceMeta=null, liveNodes=[], activePackets=[], estimateHistory=[], realizedGroundTruth=null;
let playback={time:0,playing:false,speed:5,lastWall:0,index:0,duration:30,raf:0};
const canvas=$('networkCanvas'), ctx=canvas.getContext('2d'), errorCanvas=$('errorChart'), errorCtx=errorCanvas.getContext('2d');


function clearExperimentDownloads(){lastExperiment=null;const box=$("experimentDownloads");if(box)box.classList.add("hidden");const st=$("experimentStatus");if(st)st.textContent="Ejecuta una simulación para generar el dataset descargable."}
function setDownload(id,url){const a=$(id);if(a)a.href=url}
function showExperimentDownloads(exp){lastExperiment=exp;if(!exp)return clearExperimentDownloads();$("experimentDownloads").classList.remove("hidden");$("experimentStatus").innerHTML=`Experimento <b>${exp.id}</b><br><span class="muted">Guardado localmente en ${exp.folder}</span>`;setDownload("downloadZip",exp.zip_url);const f=exp.files||{};setDownload("downloadSummary",f["summary.csv"]);setDownload("downloadTrace",f["event_trace.csv"]);setDownload("downloadPackets",f["packets.csv"]);setDownload("downloadStates",f["node_states.csv"]);setDownload("downloadEstimates",f["estimates.csv"]);setDownload("downloadNodes",f["nodes_final.csv"]);setDownload("downloadConfig",f["config.json"]);setDownload("downloadMetadata",f["metadata.json"])}

function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function num(id){return Number($(id).value)}
function placement(){return document.querySelector('input[name=placement]:checked').value}
function area(){return [Math.max(1,num('areaW')),Math.max(1,num('areaH'))]}
function pluginParameters(){const p=$('policy').value;if(!p.startsWith('plugin:'))return {};const slug=p.split(':',2)[1],vals={};document.querySelectorAll('#pluginParams [data-plugin-param]').forEach(el=>{const typ=el.dataset.type;let v=el.value;if(typ==='float'||typ==='number')v=Number(v);else if(typ==='int')v=Math.floor(Number(v));else if(typ==='bool')v=el.checked;vals[el.dataset.pluginParam]=v});return {[slug]:vals}}
function payload(){
  const [w,h]=area();
  return {node_count:Math.max(1,Math.floor(num('nodeCount'))),seed:Math.floor(num('seed')),policy:$('policy').value,positions:positions.length===Math.floor(num('nodeCount'))?positions:null,config:{
    simulation_time_s:num('simTime'),area_m:[w,h],sink_position:[num('sinkX'),num('sinkY')],period_s:num('period'),deadline_s:num('deadline'),
    event:{
      model:$('eventModel').value,
      origin:[num('eventX'),num('eventY')],start_time_s:num('eventStart'),speed_m_s:num('eventSpeed'),radius_max_m:num('eventRadius'),
      start_min_s:Math.max(0,num('eventStartMin')),start_max_s:Math.max(0,num('eventStartMax')),
      speed_min_m_s:Math.max(0.01,num('eventSpeedMin')),speed_max_m_s:Math.max(0.01,num('eventSpeedMax')),
      radius_min_m:Math.max(0,num('eventRadiusMin')),radius_max_m_stochastic:Math.max(0,num('eventRadiusMaxStochastic')),
      origin_margin_m:Math.max(0,num('eventOriginMargin')),risk_center:[num('eventRiskX'),num('eventRiskY')],risk_sigma_m:Math.max(0.1,num('eventRiskSigma'))
    },
    radio:{radio_profile:$('radioProfile').value,tx_power_dbm:num('txPower'),receiver_sensitivity_dbm:num('rxSensitivity'),bitrate_bps:num('bitrate'),payload_bytes:Math.floor(num('payload')),neighbor_radius_m:num('neighborRadius'),connectivity_mode:$('connectivity').value,use_hard_sensitivity_cutoff:$('hardCutoff').checked,channel_model:$('channelModel').value,pl_d0_db:num('plD0'),d0_m:num('d0'),path_loss_exponent:num('pathLoss'),shadow_sigma_db:num('shadowSigma'),tx_height_m:num('txHeight'),rx_height_m:num('rxHeight'),wavelength_m:num('wavelength'),rician_k_db:num('ricianK'),nakagami_m:num('nakagamiM')},
    environment:{profile:$('environment').value,channel_model:$('channelModel').value},
    communication:{architecture:$('architecture').value,routing:{strategy:'shortest_hop',max_hops:Math.max(1,Math.floor(num('maxHops')))}},
    mobility:{model:$('mobilityModel').value,speed_m_s:Math.max(0,num('mobilitySpeed')),update_interval_s:Math.max(0.01,num('mobilityInterval')),direction_change_interval_s:Math.max(0.01,num('mobilityChange')),direction_deg:num('mobilityDirection'),mobile_fraction:Math.max(0,Math.min(1,num('mobilityFraction')/100)),boundary:'reflect'},
    battery:{mode:$('batteryMode').value,capacity_mah:Math.max(0.1,num('batteryCapacity')),voltage_v:Math.max(0.1,num('batteryVoltage')),initial_soc:Math.max(0.01,Math.min(1,num('batterySoc')/100))},
    plugin_parameters:pluginParameters(),
    topology:{placement:'manual',manual_positions:positions}
  }};
}
async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw new Error(d.error||'Error');return d}

function fitCanvas(){const rect=canvas.parentElement.getBoundingClientRect();const dpr=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));canvas.style.width=rect.width+'px';canvas.style.height=rect.height+'px';ctx.setTransform(dpr,0,0,dpr,0,0);draw()}
function bounds(){const rect=canvas.getBoundingClientRect(), pad=46,[w,h]=area();const availW=Math.max(10,rect.width-pad*2),availH=Math.max(10,rect.height-pad*2);const scale=Math.min(availW/w,availH/h);const pw=w*scale,ph=h*scale;return {x:(rect.width-pw)/2,y:(rect.height-ph)/2,w:pw,h:ph,scale}}
function toPx(p){const b=bounds();return [b.x+p[0]*b.scale,b.y+b.h-p[1]*b.scale]}
function toWorld(px,py){const b=bounds();return [Math.max(0,Math.min(area()[0],(px-b.x)/b.scale)),Math.max(0,Math.min(area()[1],(b.y+b.h-py)/b.scale))]}
function currentGroundTruth(){
  if(realizedGroundTruth)return realizedGroundTruth;
  if($('eventModel')?.value==='deterministic')return {model:'deterministic',origin:[num('eventX'),num('eventY')],start_time_s:num('eventStart'),speed_m_s:num('eventSpeed'),radius_max_m:num('eventRadius')};
  return null;
}
function truthArrival(i){const gt=currentGroundTruth();if(!positions[i]||!gt)return Infinity;return Number(gt.start_time_s)+Math.hypot(positions[i][0]-Number(gt.origin[0]),positions[i][1]-Number(gt.origin[1]))/Math.max(1e-9,Number(gt.speed_m_s))}
function isPhysicallyAffected(i,t){const gt=currentGroundTruth();return !!gt&&t>=truthArrival(i)&&Math.hypot(positions[i][0]-Number(gt.origin[0]),positions[i][1]-Number(gt.origin[1]))<=Number(gt.radius_max_m)}
function bestEstimate(){const candidates=liveNodes.filter(s=>s&&Array.isArray(s.est_origin)&&Number.isFinite(s.est_speed)&&Number.isFinite(s.est_t0));if(!candidates.length)return null;return candidates.sort((a,b)=>(b.estimate_points-a.estimate_points)||((b.confirmed?1:0)-(a.confirmed?1:0))||(b.belief-a.belief)||(b.confidence-a.confidence))[0]}
function estimateErrors(est){const gt=currentGroundTruth();if(!est||!gt)return null;const oe=Math.hypot(est.est_origin[0]-gt.origin[0],est.est_origin[1]-gt.origin[1]);return {origin:oe,speed:Math.abs(est.est_speed-gt.speed_m_s),t0:Math.abs(est.est_t0-gt.start_time_s)}}
function nodeColor(i){
  const s=liveNodes[i];
  if(!s) return '#70b7ff';
  if(s.alive===false||s.state==='DEAD') return '#59636f';
  if(s.state==='PROPAGATE') return '#c792ea';
  if(s.state==='CONFIRMED'||s.confirmed||s.detected) return '#67e8a5';
  if($('showAffected')?.checked&&isPhysicallyAffected(i,playback.time)) return '#ff6b7a';
  if(s.state==='VERIFY') return '#ff9f5b';
  if(s.state==='SUSPECT') return '#f7c65d';
  return '#70b7ff';
}
function drawGrid(){
  const b=bounds(),[aw,ah]=area();
  ctx.fillStyle='#081521';ctx.fillRect(b.x,b.y,b.w,b.h);ctx.strokeStyle='#39506b';ctx.lineWidth=1;ctx.strokeRect(b.x,b.y,b.w,b.h);
  ctx.font='11px system-ui';ctx.fillStyle='#6f879f';ctx.textAlign='center';
  for(let i=0;i<=4;i++){const x=b.x+b.w*i/4;ctx.beginPath();ctx.moveTo(x,b.y);ctx.lineTo(x,b.y+b.h);ctx.strokeStyle='rgba(80,110,140,.17)';ctx.stroke();ctx.fillText((aw*i/4).toFixed(0),x,b.y+b.h+17)}
  ctx.textAlign='right';
  for(let i=0;i<=4;i++){const y=b.y+b.h-b.h*i/4;ctx.beginPath();ctx.moveTo(b.x,y);ctx.lineTo(b.x+b.w,y);ctx.strokeStyle='rgba(80,110,140,.17)';ctx.stroke();ctx.fillText((ah*i/4).toFixed(0),b.x-7,y+4)}
}
function currentLinkEdges(){
  const mode=$('linkView')?.value||'radio';
  if(mode==='geometric') return geometricEdges;
  if(mode==='simulation') return simulationEdges;
  if(mode==='routing') return routingEdges;
  return radioEdges;
}
function linkTargetPoint(e){
  if(e.target===-1)return [num('sinkX'),num('sinkY')];
  return positions[e.target]||null;
}
function drawLinks(){
  if(!$('showLinks').checked)return;
  const shown=currentLinkEdges(); ctx.lineWidth=1;
  for(const e of shown){
    if(e.source===-1||!positions[e.source])continue;
    const target=linkTargetPoint(e);if(!target)continue;
    const a=toPx(positions[e.source]),c=toPx(target);
    const view=$('linkView')?.value||'radio';
    if(view==='geometric') ctx.strokeStyle='rgba(112,183,255,.18)';
    else if(view==='routing') {ctx.strokeStyle='rgba(199,146,234,.58)';ctx.lineWidth=1.8;}
    else {ctx.strokeStyle=e.margin_db>=6?'rgba(87,207,157,.30)':'rgba(255,203,107,.30)';ctx.lineWidth=1;}
    ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...c);ctx.stroke();
  }
}
function drawEvent(){
  const gt=currentGroundTruth();
  if(!gt)return;
  const ev=toPx(gt.origin);
  if($('showEventFront').checked&&trace.length){const t=playback.time,start=Number(gt.start_time_s),speed=Number(gt.speed_m_s),maxR=Number(gt.radius_max_m);const rr=t>=start?Math.max(0,Math.min(maxR,(t-start)*speed)):0;if(rr>0){const b=bounds();ctx.fillStyle='rgba(255,123,114,.07)';ctx.strokeStyle='rgba(255,123,114,.58)';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(ev[0],ev[1],rr*b.scale,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='rgba(255,155,145,.95)';ctx.font='11px system-ui';ctx.textAlign='left';ctx.fillText(`Frente físico del fenómeno · r=${rr.toFixed(1)} / ${maxR.toFixed(1)} m · NO es radio RF`,ev[0]+10,ev[1]-12)}}
  ctx.strokeStyle='#ff7b72';ctx.lineWidth=2;ctx.beginPath();ctx.arc(ev[0],ev[1],8,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(ev[0]-11,ev[1]);ctx.lineTo(ev[0]+11,ev[1]);ctx.moveTo(ev[0],ev[1]-11);ctx.lineTo(ev[0],ev[1]+11);ctx.stroke();
}
function drawKnowledge(){
  if(!$('showKnowledge')?.checked||!trace.length)return;
  const est=bestEstimate();if(!est)return;
  const p=toPx(est.est_origin),b=bounds();
  ctx.save();ctx.strokeStyle='rgba(182,147,255,.95)';ctx.fillStyle='rgba(182,147,255,.12)';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.beginPath();ctx.arc(p[0],p[1],9,0,Math.PI*2);ctx.fill();ctx.stroke();
  const rr=Math.max(0,(playback.time-est.est_t0)*est.est_speed);if(rr>0){ctx.beginPath();ctx.arc(p[0],p[1],rr*b.scale,0,Math.PI*2);ctx.stroke()}
  if(Array.isArray(est.est_direction)){ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(p[0]+est.est_direction[0]*32,p[1]-est.est_direction[1]*32);ctx.stroke()}ctx.restore();
}
function drawPackets(){
  if(!$('showPackets').checked||!trace.length)return;
  const life=0.65;
  activePackets=activePackets.filter(e=>playback.time-e.t<=life&&playback.time>=e.t-0.001);
  for(const e of activePackets){if(!positions[e.source])continue;const a=toPx(positions[e.source]);const target=e.target===-1?[num('sinkX'),num('sinkY')]:positions[e.target];if(!target)continue;const b=toPx(target);const age=Math.max(0,playback.time-e.t),q=Math.min(1,age/life),alpha=Math.max(.08,1-q);ctx.strokeStyle=e.success?`rgba(103,232,165,${0.5*alpha})`:`rgba(255,107,122,${0.6*alpha})`;ctx.lineWidth=e.success?2:1.4;ctx.setLineDash(e.success?[]:[4,4]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();ctx.setLineDash([]);const x=a[0]+(b[0]-a[0])*q,y=a[1]+(b[1]-a[1])*q;ctx.fillStyle=e.success?`rgba(120,245,188,${alpha})`:`rgba(255,120,135,${alpha})`;ctx.beginPath();ctx.arc(x,y,3.2,0,Math.PI*2);ctx.fill()}
}
function drawNodes(){
  const sink=toPx([num('sinkX'),num('sinkY')]);ctx.fillStyle='#ffd166';ctx.beginPath();ctx.arc(sink[0],sink[1],8,0,Math.PI*2);ctx.fill();ctx.fillStyle='#07111e';ctx.font='bold 9px system-ui';ctx.textAlign='center';ctx.fillText('S',sink[0],sink[1]+3);
  positions.forEach((p,i)=>{const [x,y]=toPx(p),s=liveNodes[i];ctx.fillStyle=nodeColor(i);ctx.beginPath();ctx.arc(x,y,i===selected?7:5,0,Math.PI*2);ctx.fill();if(s&&s.lastSample!==null&&playback.time-s.lastSample<0.18&&playback.time>=s.lastSample){ctx.strokeStyle='rgba(225,244,255,.8)';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y,9,0,Math.PI*2);ctx.stroke()}if(i===selected){ctx.strokeStyle='#fff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x,y,7,0,Math.PI*2);ctx.stroke()}if($('showLabels').checked){ctx.fillStyle='#b9cbe0';ctx.font='10px system-ui';ctx.textAlign='center';ctx.fillText(String(i),x,y-10)}})
}
function draw(){const r=canvas.getBoundingClientRect();ctx.clearRect(0,0,r.width,r.height);drawGrid();drawLinks();drawEvent();drawKnowledge();drawPackets();drawNodes();$('canvasEmpty').style.display=positions.length?'none':'flex';const lp=traceMeta?.packet_last_time_s;const silent=(lp!=null&&playback.time>Number(lp)+1)?` · sin nuevos intentos de enlace desde ${Number(lp).toFixed(1)} s; simulación continúa`:'';$('simClock').textContent=`t = ${playback.time.toFixed(2)} s${silent}`;}
function findNode(x,y){let best=-1,dist=12;positions.forEach((p,i)=>{const q=toPx(p),d=Math.hypot(q[0]-x,q[1]-y);if(d<dist){dist=d;best=i}});return best}

function fmtHumanDuration(seconds){
  if(seconds===null||seconds===undefined||!Number.isFinite(Number(seconds)))return '—';
  const s=Math.max(0,Number(seconds));
  if(s<60)return `${s.toFixed(1)} s`;
  const min=s/60;if(min<60)return `${min.toFixed(1)} min`;
  const h=min/60;if(h<24)return `${h.toFixed(2)} h`;
  const d=h/24;if(d<365.25)return `${d.toFixed(1)} días`;
  return `${(d/365.25).toFixed(2)} años (${d.toFixed(0)} días)`;
}
function batteryRank(){
  if(!nodeResults.length)return {max:null,min:null};
  const arr=nodeResults.filter(n=>Number.isFinite(Number(n.energy_mj)));
  if(!arr.length)return {max:null,min:null};
  return {
    max:arr.reduce((x,y)=>Number(y.energy_mj)>Number(x.energy_mj)?y:x),
    min:arr.reduce((x,y)=>Number(y.energy_mj)<Number(x.energy_mj)?y:x)
  };
}
function updateNodeInfo(){
  if(selected<0||!positions[selected]){$('nodeInfo').innerHTML='<span class="muted">Haz clic sobre un nodo.</span>';return}
  const p=positions[selected],s=liveNodes[selected],res=nodeResults.find(n=>n.id===selected);
  const state=(res?.alive===false?'DEAD':(s?.state||'NORMAL')),energy=s?.energy_mj??res?.energy_mj??0,tx=s?.tx_count??res?.tx_count??0,rx=s?.rx_count??res?.rx_count??0,conf=s?.confidence??0,belief=s?.belief??0;
  const arr=truthArrival(selected), estArr=(s?.est_origin&&Number.isFinite(s?.est_t0)&&Number.isFinite(s?.est_speed))?s.est_t0+Math.hypot(p[0]-s.est_origin[0],p[1]-s.est_origin[1])/Math.max(1e-9,s.est_speed):null;
  const batteryFinite=$('batteryMode')?.value==='battery';
  let batteryHtml='';
  if(batteryFinite&&res){
    const alive=res.alive!==false;
    batteryHtml=`<hr class="node-sep"><b>Batería</b><br>Estado energético = <b>${alive?'VIVO':'MUERTO'}</b>${res.death_time_s!=null?` · murió en t=${Number(res.death_time_s).toFixed(2)} s`:''}<br>Batería restante = <b>${res.battery_remaining_pct==null?'—':Number(res.battery_remaining_pct).toFixed(4)+' %'}</b><br>Energía restante = ${res.battery_remaining_mj==null?'—':Number(res.battery_remaining_mj).toFixed(2)+' mJ'}<br>Autonomía estimada = <b>${fmtHumanDuration(res.estimated_lifetime_s)}</b>`;
  }else if(batteryFinite){
    batteryHtml='<hr class="node-sep"><b>Batería</b><br><span class="muted">Ejecuta la simulación para calcular autonomía y carga restante.</span>';
  }
  $('nodeInfo').innerHTML=`<b>Nodo ${selected}</b><br>X = ${p[0].toFixed(2)} m &nbsp; Y = ${p[1].toFixed(2)} m<br>Estado = <b>${state}</b> &nbsp; TX power = ${(s?.tx_power_dbm??num('txPower')).toFixed(1)} dBm<br>Confianza = ${conf.toFixed(3)} &nbsp; Creencia = ${belief.toFixed(3)}<br>Paquetes TX/RX = ${tx}/${rx}<br>Energía acumulada = ${Number(energy).toFixed(4)} mJ${batteryHtml}<br>Llegada real = ${Number.isFinite(arr)?arr.toFixed(2):'—'} s${estArr!=null?` &nbsp; Predicha = ${estArr.toFixed(2)} s`:''}${s?.estimate_points?`<br>Estimación local: ${s.estimate_points} puntos · v=${Number(s.est_speed).toFixed(2)} m/s`:''}${s?.lastSampleValue!=null?`<br>Última muestra = ${s.lastSampleValue.toFixed(3)}`:''}`;
}
function renderMetrics(m){
  if(!m){$('metrics').innerHTML='<span class="muted">Vista previa actualizada. Ejecuta la simulación para obtener métricas.</span>';return}
  const alertDelay=m.mean_alert_delay_s==null?null:Number(m.mean_alert_delay_s);
  const alertTimingLabel=alertDelay==null?'Tiempo alerta':(alertDelay<0?'Anticipación media':'Retardo medio alerta');
  const alertTimingValue=alertDelay==null?'—':`${Math.abs(alertDelay).toFixed(4)} s`;
  const lead=Number(m.mean_lead_time_s);
  const leadValue=m.mean_lead_time_s==null?'—':(lead>0?`${lead.toFixed(4)} s antes`:(lead<0?`${Math.abs(lead).toFixed(4)} s después`:'0.0000 s'));
  const fields=[['F1',m.f1],['DCR',m.dcr],['PDR enlace',m.link_pdr==null?'—':`${(100*Number(m.link_pdr)).toFixed(1)} %`],['Intentos/éxitos enlace',`${m.link_delivery_attempts??0}/${m.link_delivery_successes??0}`],['Pérdida colisión',m.collision_loss_rate==null?'—':`${(100*Number(m.collision_loss_rate)).toFixed(1)} %`],['Pérdida canal',m.channel_loss_rate==null?'—':`${(100*Number(m.channel_loss_rate)).toFixed(1)} %`],['Pérdida sensibilidad',m.sensitivity_loss_rate==null?'—':`${(100*Number(m.sensitivity_loss_rate)).toFixed(1)} %`],['Energía (mJ)',m.energy_mj],['Equidad energía · Jain',m.energy_jain_fairness],['CV energía',m.energy_cv],['TX packets',m.tx_packets],['RX packets',m.rx_packets],[alertTimingLabel,alertTimingValue],['Lead time predictivo',leadValue],['Colisiones',m.collisions],['Bajo sensibilidad',m.below_sensitivity],['Arquitectura',architectureLabel(m.communication_architecture)],['Routing entregados',m.routing_delivered],['Sin ruta',m.routing_no_route],['Saltos routing',m.routing_hops_attempted]];
  if(m.battery_mode==='battery'){
    const rank=batteryRank();
    const dead=Number(m.battery_dead_nodes||0),alive=Number(m.battery_alive_nodes||0);
    const deathStatus=dead===0?`Ninguno (${alive} vivos)`:dead===1?`1 nodo (${alive} vivos)`: `${dead} nodos (${alive} vivos)`;
    fields.push(
      ['Tiempo simulado',fmtHumanDuration(playback.duration||num('simTime'))],
      ['Batería media restante',m.battery_mean_remaining_pct==null?'—':`${Number(m.battery_mean_remaining_pct).toFixed(4)} %`],
      ['Mayor consumo',rank.max?`Nodo ${rank.max.id} · ${Number(rank.max.energy_mj).toFixed(4)} mJ`:'—'],
      ['Menor consumo',rank.min?`Nodo ${rank.min.id} · ${Number(rank.min.energy_mj).toFixed(4)} mJ`:'—'],
      ['Nodos muertos',deathStatus],
      ['Vida estimada WSN (FND)',fmtHumanDuration(m.battery_min_estimated_lifetime_s)],
      ['FND real',m.battery_fnd_time_s==null?'No ocurrió':fmtHumanDuration(m.battery_fnd_time_s)],
      ['HND real',m.battery_hnd_time_s==null?'No ocurrió':fmtHumanDuration(m.battery_hnd_time_s)],
      ['LND real',m.battery_lnd_time_s==null?'No ocurrió':fmtHumanDuration(m.battery_lnd_time_s)]
    );
  }
  $('metrics').innerHTML=fields.map(([k,v])=>`<div class="metric"><span>${k}</span><b>${v===null?'—':v}</b></div>`).join('');
}
function pct(v){return `${(100*Number(v||0)).toFixed(1)}%`}
function fmtDistance(v){v=Number(v||0);return v>=1000?`${(v/1000).toFixed(2)} km`:`${v.toFixed(1)} m`}
function renderHealth(h){
  if(!h){$('healthSummary').innerHTML='<span class="muted">Sin diagnóstico.</span>';$('healthWarnings').innerHTML='';return}
  const g=h.geometric||{},rc=h.radio_configured||{},r=h.radio||{},rt=h.routing||{};
  const cards=[
    ['Conectividad geométrica',pct(g.largest_component_fraction),`${g.connected_components??'—'} componentes · radio ${fmtDistance(h.geometric_radius_m)}`],
    ['Radio baseline (potencia configurada)',pct(rc.largest_component_fraction),`${rc.connected_components??'—'} componentes · grado medio ${Number(rc.mean_degree||0).toFixed(2)}`],
    ['Radio post-simulación (link budget)',pct(r.largest_component_fraction),`${r.connected_components??'—'} componentes · ${r.isolated_nodes??0} aislados · potencia TX final/adaptada`],
    ['Alcance al sink',pct(rt.sink_reach_fraction??h.sink_reachability_fraction),`${rt.reachable_nodes??h.sink_reachable_nodes??0}/${positions.length} nodos con ruta nominal`],
    ['Saltos al sink',rt.mean_hops_to_sink==null?'—':Number(rt.mean_hops_to_sink).toFixed(2),`Máximo: ${rt.max_hops_to_sink??'—'} · directos ${pct(rt.direct_sink_fraction)}`],
    ['Grado medio geométrico',Number(g.mean_degree||0).toFixed(2),`Radio baseline: ${Number(rc.mean_degree||0).toFixed(2)} · Radio post-run: ${Number(r.mean_degree||0).toFixed(2)}`],
    ['Densidad de nodos',`${Number(h.node_density_per_km2||0).toFixed(1)} /km²`,`Vecino más cercano medio: ${fmtDistance(h.mean_nearest_neighbor_m)}`],
    ['Densidad enlaces radio post-run',pct(r.link_density),`Grado mín/medio/máx: ${r.min_degree??'—'} / ${Number(r.mean_degree||0).toFixed(2)} / ${r.max_degree??'—'}`],
    ['Distancia media entre pares',fmtDistance(h.mean_pair_distance_m),'Promedio topológico'],
    ['Distancia máxima',fmtDistance(h.max_pair_distance_m),'Extensión entre nodos']
  ];
  $('healthSummary').innerHTML=cards.map(([k,v,d])=>`<div class="health-card"><span>${k}</span><b>${v}</b><small>${d}</small></div>`).join('');
  const warnings=h.warnings||[];
  const bad=(r.connected_components||0)>1 || Number(h.sink_reachability_fraction)<1;
  const badge=$('healthBadge');badge.textContent=bad?'Revisar escenario':'Escenario nominal OK';
  const lv=$('linkView'); if(lv){const count=currentLinkEdges().length; lv.title=`${count} enlaces mostrados. Radio=${radioEdges.length}, geométricos=${geometricEdges.length}, simulación=${simulationEdges.length}, rutas=${routingEdges.length}`;}badge.className='health-badge '+(bad?'warn':'good');
  $('healthWarnings').innerHTML=warnings.map(w=>`<div class="health-warning ${w.startsWith('No se')?'good':''}">${w}</div>`).join('');
}

function renderAlgorithmDiagnostic(d){
  if(!d){$('algorithmDiagnostic').innerHTML='<span class="muted">Ejecuta una simulación para obtener el diagnóstico.</span>';$('diagnosticNotes').innerHTML='';return}
  const labels={detection:'Detección',deadline_reliability:'Cumplimiento deadline',link_delivery:'Entrega de enlaces',connectivity:'Robustez de conectividad',energy_fairness:'Equidad energética',event_estimation:'Estimación del evento',node_survival:'Supervivencia de nodos'};
  const dims=d.dimensions||{};
  $('algorithmDiagnostic').innerHTML=Object.entries(dims).map(([k,v])=>`<div class="health-card"><span>${labels[k]||k}</span><b>${v}</b><small>${v==='GOOD'?'Fortaleza observada':v==='WEAK'?'Debilidad observada':v==='MODERATE'?'Zona a vigilar':'No aplica'}</small></div>`).join('');
  const life=d.functional_at_end?`La WSN permaneció funcional durante toda la ventana observada (≥ ${fmtHumanDuration(d.functional_lifetime_observed_lower_bound_s)}).`:'La WSN no cumple al final uno o más criterios funcionales; esta versión no inventa un instante exacto de fallo sin muestreo temporal.';
  const weak=(d.weaknesses||[]).map(x=>labels[x]||x).join(', '), strong=(d.strengths||[]).map(x=>labels[x]||x).join(', ');
  $('diagnosticNotes').innerHTML=`<div class="health-warning ${d.functional_at_end?'good':''}">${life}</div>${strong?`<div class="health-warning good">Fortalezas: ${strong}</div>`:''}${weak?`<div class="health-warning">Debilidades: ${weak}</div>`:''}`;
}
function initLiveNodes(){if(initialPositions.length===positions.length)positions=initialPositions.map(p=>[p[0],p[1]]);liveNodes=positions.map((_,i)=>({id:i,state:'NORMAL',detected:false,confirmed:false,confidence:0,belief:0,energy_mj:0,tx_count:0,rx_count:0,tx_power_dbm:num('txPower'),lastSample:null,lastSampleValue:null,est_origin:null,est_t0:null,est_speed:null,est_direction:null,est_eta:null,estimate_points:0,first_detection_time:null,first_confirmation_time:null}));activePackets=[];playback.index=0}
function applyTraceEvent(e){
  if(e.kind==='move'&&positions[e.node]){positions[e.node]=[Number(e.x),Number(e.y)];return}
  if(e.kind==='sample'&&liveNodes[e.node]){liveNodes[e.node].lastSample=e.t;liveNodes[e.node].lastSampleValue=e.value;return}
  if(e.kind==='decision'&&liveNodes[e.node]){Object.assign(liveNodes[e.node],{state:e.state||liveNodes[e.node].state,detected:!!e.detected,confirmed:!!e.confirmed,confidence:Number(e.confidence||0),belief:Number(e.belief||0),energy_mj:Number(e.energy_mj||0),tx_count:Number(e.tx_count||0),rx_count:Number(e.rx_count||0),tx_power_dbm:Number(e.tx_power_dbm??liveNodes[e.node].tx_power_dbm),est_origin:e.est_origin,est_t0:e.est_t0,est_speed:e.est_speed,est_direction:e.est_direction,est_eta:e.est_eta,estimate_points:Number(e.estimate_points||0),first_detection_time:e.first_detection_time,first_confirmation_time:e.first_confirmation_time});return}
  if(e.kind==='receive'&&liveNodes[e.node]){liveNodes[e.node].state=e.state||liveNodes[e.node].state;liveNodes[e.node].rx_count=Number(e.rx_count||liveNodes[e.node].rx_count);liveNodes[e.node].energy_mj=Math.max(liveNodes[e.node].energy_mj,Number(e.energy_mj||0));return}
  if(e.kind==='packet'){activePackets.push(e);if(liveNodes[e.source])liveNodes[e.source].tx_count=Math.max(liveNodes[e.source].tx_count,(liveNodes[e.source].tx_count||0)+0);return}
}
function rebuildTo(t){initLiveNodes();for(let i=0;i<trace.length;i++){if(trace[i].t>t){playback.index=i;break}applyTraceEvent(trace[i]);playback.index=i+1}playback.time=t;activePackets=trace.filter(e=>e.kind==='packet'&&e.t<=t&&t-e.t<=0.65);updatePlaybackUI();updateNodeInfo();updateKnowledge();draw()}
function advanceTo(t){if(t<playback.time){rebuildTo(t);return}playback.time=Math.min(playback.duration,t);while(playback.index<trace.length&&trace[playback.index].t<=playback.time){applyTraceEvent(trace[playback.index]);playback.index++}activePackets=activePackets.filter(e=>playback.time-e.t<=0.65);updatePlaybackUI();updateNodeInfo();updateKnowledge();draw()}
function updatePlaybackUI(){$('timeSlider').value=playback.time;$('timeReadout').textContent=`${playback.time.toFixed(2)} / ${playback.duration.toFixed(2)} s`;$('playBtn').textContent=playback.playing?'⏸ Pausa':'▶ Reproducir'}
function stopPlayback(){playback.playing=false;playback.lastWall=0;if(playback.raf)cancelAnimationFrame(playback.raf);playback.raf=0;updatePlaybackUI()}
function frame(ts){if(!playback.playing)return;if(!playback.lastWall)playback.lastWall=ts;const dt=(ts-playback.lastWall)/1000;playback.lastWall=ts;advanceTo(playback.time+dt*playback.speed);if(playback.time>=playback.duration){stopPlayback();return}playback.raf=requestAnimationFrame(frame)}
function togglePlayback(){if(!trace.length)return;if(playback.time>=playback.duration-1e-6)rebuildTo(0);playback.playing=!playback.playing;playback.lastWall=0;updatePlaybackUI();if(playback.playing)playback.raf=requestAnimationFrame(frame);else stopPlayback()}
function prepareTrace(d){
  stopPlayback();realizedGroundTruth=d.ground_truth||realizedGroundTruth;
  scientificTrace=(d.trace||[]).slice().sort((a,b)=>a.t-b.t);
  mobilityTrace=(d.mobility_trace||[]).slice().sort((a,b)=>a.t-b.t);
  packetTrace=(d.packet_trace||[]).slice().sort((a,b)=>a.t-b.t);
  // Mobility and packet playback are independent from the bounded scientific
  // trace. Remove legacy packet copies here to avoid drawing duplicates.
  const scientificPlayback=scientificTrace.filter(e=>e.kind!=='packet');
  trace=scientificPlayback.concat(mobilityTrace,packetTrace).sort((a,b)=>(a.t-b.t)||((a.kind==='move')?-1:1));
  traceMeta=d.trace_meta||null;buildEstimateHistory();
  playback.duration=Number(traceMeta?.duration_s??num('simTime'));playback.speed=Number($('playbackSpeed').value);
  $('timeSlider').max=playback.duration;$('timeSlider').disabled=!trace.length;$('playBtn').disabled=!trace.length;$('resetPlaybackBtn').disabled=!trace.length;
  const sci=`${scientificTrace.length.toLocaleString()} eventos`;
  const mob=mobilityTrace.length?` · movilidad ${mobilityTrace.length.toLocaleString()} muestras hasta ${Number(traceMeta?.mobility_last_time_s||0).toFixed(1)} s`:'';
  const pkt=packetTrace.length?` · paquetes playback ${packetTrace.length.toLocaleString()}/${Number(traceMeta?.packet_total_attempts||packetTrace.length).toLocaleString()}`:'';
  const pktLast=traceMeta?.packet_last_time_s!=null?` · último intento enlace ${Number(traceMeta.packet_last_time_s).toFixed(1)} s`:'';
  const limited=traceMeta?.truncated?' · traza científica limitada':'';
  const complete=mobilityTrace.length?(traceMeta?.mobility_complete?' · movilidad completa':' · movilidad incompleta'):'';
  const pktComplete=packetTrace.length?(traceMeta?.packet_playback_complete_coverage?' · cobertura paquetes completa':' · cobertura paquetes incompleta'):'';
  $('traceInfo').textContent=trace.length?`${sci}${limited}${mob}${complete}${pkt}${pktLast}${pktComplete}`:'Sin traza';rebuildTo(0)
}
function clearTrace(){stopPlayback();realizedGroundTruth=null;trace=[];scientificTrace=[];mobilityTrace=[];packetTrace=[];traceMeta=null;estimateHistory=[];playback.duration=num('simTime');playback.time=0;initLiveNodes();$('timeSlider').disabled=true;$('playBtn').disabled=true;$('resetPlaybackBtn').disabled=true;$('traceInfo').textContent='Sin traza';updatePlaybackUI();updateKnowledge()}

function buildEstimateHistory(){
  estimateHistory=[];const states=new Map();
  for(const e of scientificTrace){if(e.kind!=='decision'||!Array.isArray(e.est_origin)||!Number.isFinite(e.est_speed)||!Number.isFinite(e.est_t0))continue;
    states.set(e.node,{id:e.node,est_origin:e.est_origin,est_speed:Number(e.est_speed),est_t0:Number(e.est_t0),est_direction:e.est_direction,estimate_points:Number(e.estimate_points||0),confirmed:!!e.confirmed,belief:Number(e.belief||0),confidence:Number(e.confidence||0)});
    const c=[...states.values()].sort((a,b)=>(b.estimate_points-a.estimate_points)||((b.confirmed?1:0)-(a.confirmed?1:0))||(b.belief-a.belief)||(b.confidence-a.confidence))[0];
    if(c){const er=estimateErrors(c);if(er)estimateHistory.push({t:e.t,...c,errors:er})}
  }
}
function fitErrorCanvas(){const r=errorCanvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;errorCanvas.width=Math.max(1,Math.floor(r.width*dpr));errorCanvas.height=Math.max(1,Math.floor(r.height*dpr));errorCtx.setTransform(dpr,0,0,dpr,0,0)}
function drawErrorChart(){fitErrorCanvas();const r=errorCanvas.getBoundingClientRect(),w=r.width,h=r.height,pad=24;errorCtx.clearRect(0,0,w,h);errorCtx.strokeStyle='rgba(70,99,130,.45)';errorCtx.strokeRect(pad,8,w-pad-8,h-pad-4);const hist=estimateHistory.filter(x=>x.t<=playback.time);if(!hist.length){errorCtx.fillStyle='#71869c';errorCtx.font='11px system-ui';errorCtx.fillText('Sin estimación D-STEP disponible todavía',pad+8,h/2);return}const maxT=Math.max(playback.duration,1),maxE=Math.max(1,...estimateHistory.map(x=>x.errors.origin));errorCtx.strokeStyle='rgba(182,147,255,.95)';errorCtx.lineWidth=1.8;errorCtx.beginPath();hist.forEach((x,i)=>{const xx=pad+(w-pad-8)*(x.t/maxT),yy=8+(h-pad-4)*(1-x.errors.origin/maxE);if(i===0)errorCtx.moveTo(xx,yy);else errorCtx.lineTo(xx,yy)});errorCtx.stroke();errorCtx.fillStyle='#91a5bc';errorCtx.font='10px system-ui';errorCtx.fillText(`Error de origen (m) · máx ${maxE.toFixed(1)}`,pad, h-5)}
function updateKnowledge(){
  const box=$('knowledgeSummary');if(!box)return;const est=bestEstimate(), t=playback.time, affected=positions.filter((_,i)=>isPhysicallyAffected(i,t)).length, known=liveNodes.filter(n=>n&&(n.detected||n.confirmed)).length, unseen=positions.filter((_,i)=>isPhysicallyAffected(i,t)&&!(liveNodes[i]?.detected||liveNodes[i]?.confirmed)).length;
  if(!trace.length){box.innerHTML='<span class="muted">Ejecuta D-STEP para observar la estimación distribuida.</span>';drawErrorChart();return}
  const gt=currentGroundTruth();
  const truth=gt?`<div class="knowledge-card"><h3>Ground Truth · ${String(gt.model||'').replace('_',' ')}</h3><div class="row"><span>Origen</span><span>(${Number(gt.origin[0]).toFixed(1)}, ${Number(gt.origin[1]).toFixed(1)}) m</span></div><div class="row"><span>t₀</span><span>${Number(gt.start_time_s).toFixed(2)} s</span></div><div class="row"><span>Velocidad</span><span>${Number(gt.speed_m_s).toFixed(2)} m/s</span></div><div class="row"><span>Radio máximo físico del fenómeno</span><span>${Number(gt.radius_max_m).toFixed(1)} m</span></div><div class="row"><span>Alcanzados</span><span>${affected}/${positions.length}</span></div></div>`:`<div class="knowledge-card"><h3>Ground Truth</h3><span class="muted">Oculto hasta ejecutar el escenario estocástico.</span></div>`;
  let know='<div class="knowledge-card"><h3>Conocimiento distribuido</h3><div class="muted">Aún no hay suficientes evidencias para estimar origen/velocidad.</div></div>',err='<div class="knowledge-card"><h3>Error actual</h3><div class="muted">Esperando estimación.</div></div>';
  if(est){const er=estimateErrors(est);know=`<div class="knowledge-card"><h3>Mejor estimación D-STEP</h3><div class="row"><span>Nodo fuente</span><span>N${est.id}</span></div><div class="row"><span>Origen</span><span>(${est.est_origin[0].toFixed(1)}, ${est.est_origin[1].toFixed(1)}) m</span></div><div class="row"><span>t₀ estimado</span><span>${est.est_t0.toFixed(2)} s</span></div><div class="row"><span>Velocidad</span><span>${est.est_speed.toFixed(2)} m/s</span></div><div class="row"><span>Evidencias</span><span>${est.estimate_points}</span></div></div>`;err=`<div class="knowledge-card"><h3>Error actual</h3><div class="row"><span>Origen</span><span>${er.origin.toFixed(2)} m</span></div><div class="row"><span>Velocidad</span><span>${er.speed.toFixed(2)} m/s</span></div><div class="row"><span>t₀</span><span>${er.t0.toFixed(2)} s</span></div><div class="row"><span>Alcanzado/no detectado</span><span>${unseen}</span></div><div class="row"><span>Red conoce evento</span><span>${known}/${positions.length}</span></div></div>`}
  box.innerHTML=truth+know+err;drawErrorChart();
}
function applySelectedRadioProfile(){
  const name=$('radioProfile').value,p=radioProfiles[name];if(!p)return;const r=p.radio||{};
  const set=(id,key)=>{if(r[key]!==undefined)$(id).value=r[key]};
  set('txPower','tx_power_dbm');set('rxSensitivity','receiver_sensitivity_dbm');set('bitrate','bitrate_bps');set('payload','payload_bytes');
  set('channelModel','channel_model');set('plD0','pl_d0_db');set('d0','d0_m');set('pathLoss','path_loss_exponent');set('shadowSigma','shadow_sigma_db');
  if(r.use_hard_sensitivity_cutoff!==undefined)$('hardCutoff').checked=!!r.use_hard_sensitivity_cutoff;
  const ev=p.evidence||'user_defined',tech=p.technology||'generic';
  $('radioProfileInfo').innerHTML=`<b>${p.label}</b><br>Tecnología: ${tech} · Evidencia: ${ev}${p.source_note?`<br>${p.source_note}`:''}`;
  clearExperimentDownloads();if(positions.length)preview();
}

function renderPluginInfo(){
  const p=$('policy').value,box=$('pluginParams'),info=$('pluginInfo');box.innerHTML='';
  if(!p.startsWith('plugin:')){info.textContent='API de algoritmos v1.0 · selecciona un plugin o carga un archivo .py.';return}
  const m=pluginMeta[p];if(!m){info.textContent='Plugin no encontrado.';return}
  info.innerHTML=`<b>${m.name}</b> v${m.version||'0.1'} · ${m.description||''}<br>Arquitecturas: ${(m.compatible_architectures||[]).map(architectureLabel).join(', ')}`;
  Object.entries(m.parameters||{}).forEach(([name,spec])=>{const label=document.createElement('label');label.textContent=name.replaceAll('_',' ');const inp=document.createElement('input');inp.dataset.pluginParam=name;inp.dataset.type=spec.type||'float';if((spec.type||'')==='bool'){inp.type='checkbox';inp.checked=Boolean(spec.default)}else{inp.type=(spec.type==='string')?'text':'number';if(spec.default!==undefined)inp.value=spec.default;if(spec.min!==undefined)inp.min=spec.min;if(spec.max!==undefined)inp.max=spec.max;if(spec.type==='float')inp.step='any'}label.appendChild(inp);box.appendChild(label)});
}
async function loadPluginFile(){const f=$('pluginFile').files?.[0];if(!f)return toast('Selecciona un archivo .py');try{const source=await f.text();const d=await api('/api/plugins/upload',{filename:f.name,source});pluginMeta=d.plugins||{};for(const opt of Array.from($('policy').options)){if(opt.value.startsWith('plugin:'))opt.remove()}Object.values(pluginMeta).filter(x=>x.valid).forEach(m=>$('policy').add(new Option(`Plugin: ${m.name}`,m.id)));const match=Object.values(pluginMeta).find(m=>m.file===f.name&&m.valid);if(match)$('policy').value=match.id;renderPluginInfo();updateArchitectureInfo(true);toast(`Algoritmo cargado: ${match?.name||f.name}`);if(positions.length)preview()}catch(e){toast(e.message)}}

function architectureLabel(v){return ({distributed:'Distributed / peer-to-peer',direct_to_sink:'Direct-to-Sink',multi_hop_to_sink:'Multi-hop-to-Sink'})[v]||v}
function compatibleArchitectures(policy){if(policy.startsWith('plugin:'))return pluginMeta[policy]?.compatible_architectures||['distributed','direct_to_sink','multi_hop_to_sink'];if(policy==='dstep'||policy==='distributed_edge')return ['distributed'];if(policy==='central_edge')return ['direct_to_sink','multi_hop_to_sink'];return ['distributed','direct_to_sink','multi_hop_to_sink']}
function updateArchitectureInfo(autoAdjust=false){
  const p=$('policy').value,a=$('architecture').value,valid=compatibleArchitectures(p);
  if(autoAdjust&&!valid.includes(a)){$('architecture').value=p==='central_edge'?'direct_to_sink':'distributed'}
  const current=$('architecture').value;
  const text=current==='distributed'?'Intercambio local entre vecinos; no exige ruta al sink.':current==='direct_to_sink'?'Cada reporte intenta un único enlace físico nodo → sink.':'El reporte busca la ruta nominal de menor número de saltos y cada salto se somete al canal real.';
  const compat=compatibleArchitectures(p).includes(current);
  $('architectureInfo').innerHTML=`${text}<br><b>${compat?'Compatible':'No compatible'}</b> con ${p.replaceAll('_',' ')}.${compat?'':' Opciones válidas: '+compatibleArchitectures(p).map(architectureLabel).join(', ')}`;
  $('maxHops').disabled=current!=='multi_hop_to_sink';
}

function updateMobilityInfo(){
  const model=$('mobilityModel').value, speed=Math.max(0,num('mobilitySpeed'));
  const names={static:'Static',linear:'Linear',random_walk:'Random Walk',random_waypoint:'Random Waypoint'};
  $('mobilityDirectionLabel').style.display=model==='linear'?'':'none';
  $('mobilityChangeLabel').style.display=model==='random_walk'?'':'none';
  $('mobilitySpeed').disabled=model==='static';
  $('mobilityInterval').disabled=model==='static';
  $('mobilityFraction').disabled=model==='static';
  $('mobilityInfo').textContent=model==='static'||speed<=0?'Static: comportamiento idéntico al simulador actual.':`${names[model]} activo · ${speed.toFixed(2)} m/s · la geometría se recalcula durante la simulación.`;
}
['mobilityModel','mobilitySpeed','mobilityInterval','mobilityDirection','mobilityChange','mobilityFraction'].forEach(id=>$(id).addEventListener('change',()=>{updateMobilityInfo();clearExperimentDownloads()}));
updateMobilityInfo();


function updateBatteryInfo(){
  const mode=$('batteryMode').value, finite=mode==='battery';
  ['batteryCapacity','batteryVoltage','batterySoc'].forEach(id=>$(id).disabled=!finite);
  if(!finite){$('batteryInfo').textContent='Ideal: no se limita la vida útil de los nodos.';return}
  const mah=Math.max(.1,num('batteryCapacity')),v=Math.max(.1,num('batteryVoltage')),soc=Math.max(.01,Math.min(1,num('batterySoc')/100));
  const wh=v*(mah/1000)*soc, j=wh*3600;
  $('batteryInfo').textContent=`Batería inicial por nodo: ${wh.toFixed(3)} Wh = ${j.toFixed(1)} J. Los nodos se desactivan al agotar este presupuesto.`;
}
['batteryMode','batteryCapacity','batteryVoltage','batterySoc'].forEach(id=>$(id)?.addEventListener('change',()=>{updateBatteryInfo();clearExperimentDownloads()}));
updateBatteryInfo();


function updateEventModelInfo(){
  const model=$('eventModel').value;
  $('eventDeterministicFields').classList.toggle('hidden',model!=='deterministic');
  $('eventStochasticFields').classList.toggle('hidden',model==='deterministic');
  $('eventRiskFields').classList.toggle('hidden',model!=='spatial_risk');
  realizedGroundTruth=null;
  if(model==='deterministic'){
    $('eventGeneratorInfo') && ($('eventGeneratorInfo').textContent='Evento explícito para validación y pruebas controladas.');
  }else if(model==='spatial_risk'){
    $('eventGeneratorInfo').textContent='Origen muestreado alrededor de la zona de riesgo; t₀, velocidad y alcance también son aleatorios y reproducibles por seed.';
  }else{
    $('eventGeneratorInfo').textContent='Origen uniforme en el área; t₀, velocidad y alcance son aleatorios y reproducibles por seed.';
  }
  updateKnowledge();draw();clearExperimentDownloads();
}
$('eventModel')?.addEventListener('change',updateEventModelInfo);
['eventStartMin','eventStartMax','eventSpeedMin','eventSpeedMax','eventRadiusMin','eventRadiusMaxStochastic','eventOriginMargin','eventRiskX','eventRiskY','eventRiskSigma'].forEach(id=>$(id)?.addEventListener('change',()=>{realizedGroundTruth=null;clearExperimentDownloads();updateKnowledge();draw()}));

function configurationSnapshot(){
  return {ui:{placement:placement()},payload:payload()};
}
function setField(id,value){if(value!==undefined&&value!==null&&$(id))$(id).value=value}
function setChecked(id,value){if(value!==undefined&&value!==null&&$(id))$(id).checked=Boolean(value)}
function setRadioProfileInfo(){const p=radioProfiles[$('radioProfile').value];if(!p)return;$('radioProfileInfo').innerHTML=`<b>${p.label}</b><br>Tecnología: ${p.technology||'generic'} · Evidencia: ${p.evidence||'user_defined'}${p.source_note?`<br>${p.source_note}`:''}`}
async function refreshConfigurations(selectedId=''){
  try{
    const d=await api('/api/configurations'),sel=$('savedConfigurations');sel.innerHTML='<option value="">— Ninguna seleccionada —</option>';
    for(const c of d.configurations||[]){const o=new Option(c.name,c.id);o.dataset.updated=c.updated_utc||'';o.dataset.version=c.simulator_version||'';sel.add(o)}
    if(selectedId&&Array.from(sel.options).some(o=>o.value===selectedId))sel.value=selectedId;
    const n=(d.configurations||[]).length;$('configurationInfo').textContent=`Carpeta local: configurations/ · ${n} configuración${n===1?'':'es'} guardada${n===1?'':'s'}.`;
  }catch(e){toast(e.message)}
}
async function saveConfiguration(overwrite=false){
  const name=$('configurationName').value.trim();if(!name)return toast('Escribe un nombre para la configuración');
  try{const d=await api('/api/configurations/save',{name,snapshot:configurationSnapshot(),overwrite});await refreshConfigurations(d.configuration.id);toast(`Configuración guardada: ${d.configuration.name}`)}
  catch(e){if(!overwrite&&String(e.message).includes('Ya existe')&&confirm(`${e.message}. ¿Deseas reemplazarla?`))return saveConfiguration(true);toast(e.message)}
}
async function loadConfiguration(){
  const id=$('savedConfigurations').value;if(!id)return toast('Selecciona una configuración guardada');
  try{
    const d=await api('/api/configurations/load',{id}),rec=d.record||{},snap=rec.snapshot||{},p=snap.payload||{},c=p.config||{},r=c.radio||{},ev=c.event||{},comm=c.communication||{},mob=c.mobility||{},bat=c.battery||{};
    setField('nodeCount',p.node_count);setField('seed',p.seed);
    if(Array.isArray(c.area_m)){setField('areaW',c.area_m[0]);setField('areaH',c.area_m[1])}if(Array.isArray(c.sink_position)){setField('sinkX',c.sink_position[0]);setField('sinkY',c.sink_position[1])}
    setField('simTime',c.simulation_time_s);setField('period',c.period_s);setField('deadline',c.deadline_s);
    setField('eventModel',ev.model||'deterministic');if(Array.isArray(ev.origin)){setField('eventX',ev.origin[0]);setField('eventY',ev.origin[1])}setField('eventStart',ev.start_time_s);setField('eventSpeed',ev.speed_m_s);setField('eventRadius',ev.radius_max_m);setField('eventStartMin',ev.start_min_s);setField('eventStartMax',ev.start_max_s);setField('eventSpeedMin',ev.speed_min_m_s);setField('eventSpeedMax',ev.speed_max_m_s);setField('eventRadiusMin',ev.radius_min_m);setField('eventRadiusMaxStochastic',ev.radius_max_m_stochastic);setField('eventOriginMargin',ev.origin_margin_m);if(Array.isArray(ev.risk_center)){setField('eventRiskX',ev.risk_center[0]);setField('eventRiskY',ev.risk_center[1])}setField('eventRiskSigma',ev.risk_sigma_m);
    setField('radioProfile',r.radio_profile);setField('txPower',r.tx_power_dbm);setField('rxSensitivity',r.receiver_sensitivity_dbm);setField('bitrate',r.bitrate_bps);setField('payload',r.payload_bytes);setField('neighborRadius',r.neighbor_radius_m);setField('connectivity',r.connectivity_mode);setChecked('hardCutoff',r.use_hard_sensitivity_cutoff);setField('channelModel',r.channel_model);setField('plD0',r.pl_d0_db);setField('d0',r.d0_m);setField('pathLoss',r.path_loss_exponent);setField('shadowSigma',r.shadow_sigma_db);setField('txHeight',r.tx_height_m);setField('rxHeight',r.rx_height_m);setField('wavelength',r.wavelength_m);setField('ricianK',r.rician_k_db);setField('nakagamiM',r.nakagami_m);setRadioProfileInfo();
    setField('environment',c.environment?.profile);setField('architecture',comm.architecture);setField('maxHops',comm.routing?.max_hops);
    if(p.policy&&Array.from($('policy').options).some(o=>o.value===p.policy)){$('policy').value=p.policy}renderPluginInfo();const pp=c.plugin_parameters||{};if(p.policy?.startsWith('plugin:')){const slug=p.policy.split(':',2)[1],vals=pp[slug]||{};document.querySelectorAll('#pluginParams [data-plugin-param]').forEach(el=>{if(vals[el.dataset.pluginParam]===undefined)return;if(el.type==='checkbox')el.checked=Boolean(vals[el.dataset.pluginParam]);else el.value=vals[el.dataset.pluginParam]})}
    setField('mobilityModel',mob.model);setField('mobilitySpeed',mob.speed_m_s);setField('mobilityInterval',mob.update_interval_s);setField('mobilityDirection',mob.direction_deg);setField('mobilityChange',mob.direction_change_interval_s);if(mob.mobile_fraction!==undefined)setField('mobilityFraction',Number(mob.mobile_fraction)*100);
    setField('batteryMode',bat.mode||'ideal');setField('batteryCapacity',bat.capacity_mah);setField('batteryVoltage',bat.voltage_v);if(bat.initial_soc!==undefined)setField('batterySoc',Number(bat.initial_soc)*100);
    const plc=snap.ui?.placement||'random',radio=document.querySelector(`input[name=placement][value="${plc}"]`);if(radio)radio.checked=true;
    positions=Array.isArray(p.positions)?p.positions.map(x=>[Number(x[0]),Number(x[1])]):[];initialPositions=positions.map(x=>[x[0],x[1]]);selected=-1;nodeResults=[];lastRun=false;clearTrace();clearExperimentDownloads();
    updateMobilityInfo();updateBatteryInfo();updateEventModelInfo();updateArchitectureInfo(false);playback.duration=num('simTime');draw();updateNodeInfo();renderMetrics(null);renderAlgorithmDiagnostic(null);$('configurationName').value=rec.name||id;
    if(positions.length)await preview();else draw();
    toast(`Configuración cargada: ${rec.name||id} · simulación no ejecutada`);
  }catch(e){toast(e.message)}
}
async function deleteConfiguration(){const id=$('savedConfigurations').value;if(!id)return toast('Selecciona una configuración guardada');const name=$('savedConfigurations').selectedOptions[0]?.textContent||id;if(!confirm(`¿Eliminar la configuración "${name}"?`))return;try{await api('/api/configurations/delete',{id});$('configurationName').value='';await refreshConfigurations();toast(`Configuración eliminada: ${name}`)}catch(e){toast(e.message)}}
$('saveConfigurationBtn')?.addEventListener('click',()=>saveConfiguration(false));$('refreshConfigurationsBtn')?.addEventListener('click',()=>refreshConfigurations());$('loadConfigurationBtn')?.addEventListener('click',loadConfiguration);$('deleteConfigurationBtn')?.addEventListener('click',deleteConfiguration);$('savedConfigurations')?.addEventListener('change',()=>{const o=$('savedConfigurations').selectedOptions[0];if(o?.value){$('configurationName').value=o.textContent;const dt=o.dataset.updated?new Date(o.dataset.updated).toLocaleString():'';$('configurationInfo').textContent=`${o.textContent} · ${o.dataset.version?'v'+o.dataset.version+' · ':''}${dt||'sin fecha'}`}});

async function generate(){clearExperimentDownloads();try{const p=payload();p.positions=null;const d=await api('/api/generate',p);positions=d.positions;initialPositions=positions.map(p=>[p[0],p[1]]);edges=d.edges||[];geometricEdges=d.geometric_edges||[];radioEdges=d.radio_edges||[];simulationEdges=d.simulation_edges||d.edges||[];routingEdges=d.routing_edges||[];nodeResults=[];selected=-1;lastRun=false;clearTrace();draw();updateNodeInfo();renderMetrics(null);renderAlgorithmDiagnostic(null);renderHealth(d.scenario_health);toast(`Topología generada: ${positions.length} nodos`)}catch(e){toast(e.message)}}
async function preview(){clearExperimentDownloads();if(!positions.length)return generate();try{const d=await api('/api/preview',payload());edges=d.edges||[];geometricEdges=d.geometric_edges||[];radioEdges=d.radio_edges||[];simulationEdges=d.simulation_edges||d.edges||[];routingEdges=d.routing_edges||[];nodeResults=[];lastRun=false;clearTrace();draw();renderMetrics(null);renderAlgorithmDiagnostic(null);renderHealth(d.scenario_health);toast(`${edges.length} enlaces nominales`)}catch(e){toast(e.message)}}
async function run(){if(!positions.length)await generate();try{$('runBtn').disabled=true;$('runBtn').textContent='Ejecutando…';const d=await api('/api/simulate',payload());edges=d.edges||[];geometricEdges=d.geometric_edges||[];radioEdges=d.radio_edges||[];simulationEdges=d.simulation_edges||d.edges||[];routingEdges=d.routing_edges||[];nodeResults=d.nodes||[];realizedGroundTruth=d.ground_truth||null;lastRun=true;renderMetrics(d.metrics);updateNodeInfo();renderHealth(d.scenario_health);renderAlgorithmDiagnostic(d.algorithm_diagnostic);prepareTrace(d);showExperimentDownloads(d.experiment);toast(`Simulación completada · ${(d.trace||[]).length.toLocaleString()} eventos · dataset exportado`);togglePlayback()}catch(e){toast(e.message)}finally{$('runBtn').disabled=false;$('runBtn').textContent='▶ Ejecutar simulación'}}
async function exportCfg(){try{const d=await api('/api/export-config',payload());const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='config_v0_37_gui.json';a.click();URL.revokeObjectURL(a.href);toast('config.json exportado')}catch(e){toast(e.message)}}
function clearForManual(){positions=[];initialPositions=[];edges=[];nodeResults=[];selected=-1;clearTrace();draw();updateNodeInfo()}

canvas.addEventListener('mousedown',e=>{if(trace.length)return;const r=canvas.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;const hit=findNode(x,y);if(hit>=0){selected=hit;dragging=hit;updateNodeInfo();draw();return}if(placement()==='manual'&&positions.length<Math.floor(num('nodeCount'))){positions.push(toWorld(x,y));selected=positions.length-1;initLiveNodes();updateNodeInfo();draw();if(positions.length===Math.floor(num('nodeCount')))preview()}});
canvas.addEventListener('mousemove',e=>{if(dragging<0||placement()==='random'||trace.length)return;const r=canvas.getBoundingClientRect();positions[dragging]=toWorld(e.clientX-r.left,e.clientY-r.top);edges=[];updateNodeInfo();draw()});
window.addEventListener('mouseup',()=>{if(dragging>=0){dragging=-1;if(placement()!=='random'&&!trace.length)preview()}});
canvas.addEventListener('click',e=>{if(!trace.length)return;const r=canvas.getBoundingClientRect(),hit=findNode(e.clientX-r.left,e.clientY-r.top);if(hit>=0){selected=hit;updateNodeInfo();draw()}});
canvas.addEventListener('dblclick',e=>{if(placement()==='random'||trace.length)return;const r=canvas.getBoundingClientRect(),hit=findNode(e.clientX-r.left,e.clientY-r.top);if(hit>=0){positions.splice(hit,1);selected=-1;$('nodeCount').value=positions.length;edges=[];initLiveNodes();preview();updateNodeInfo();draw()}});

$('generateBtn').onclick=generate;$('previewBtn').onclick=preview;$('runBtn').onclick=run;$('exportBtn').onclick=exportCfg;$('newSeedBtn').onclick=()=>{$('seed').value=Math.floor(Math.random()*1e9);generate()};
['showLinks','showLabels','showPackets','showEventFront','showKnowledge','showAffected'].forEach(id=>$(id).onchange=draw);
$('playBtn').onclick=togglePlayback;$('resetPlaybackBtn').onclick=()=>{stopPlayback();rebuildTo(0)};
$('timeSlider').addEventListener('input',()=>{stopPlayback();rebuildTo(Number($('timeSlider').value))});
$('playbackSpeed').addEventListener('change',()=>playback.speed=Number($('playbackSpeed').value));
document.querySelectorAll('input[name=placement]').forEach(r=>r.addEventListener('change',()=>{if(placement()==='manual')clearForManual()}));
['areaW','areaH','sinkX','sinkY'].forEach(id=>$(id).addEventListener('change',draw));['eventX','eventY','eventStart','eventSpeed','eventRadius'].forEach(id=>$(id)?.addEventListener('change',()=>{realizedGroundTruth=null;draw();updateKnowledge();clearExperimentDownloads()}));
window.addEventListener('resize',fitCanvas);

(async()=>{try{const d=await api('/api/config');cfgBase=d.config;$('serverStatus').textContent='Motor D-STEP · v0.41 · canal ESP32 TEST002 calibrado con hardware real';$('serverStatus').classList.add('ok');d.policies.forEach(x=>$('policy').add(new Option(x.replaceAll('_',' '),x)));pluginMeta=d.plugins||{};Object.values(pluginMeta).filter(x=>x.valid).forEach(m=>$('policy').add(new Option(`Plugin: ${m.name}`,m.id)));$('policy').value='dstep';renderPluginInfo();$('architecture').value=d.config.communication?.architecture||'distributed';$('maxHops').value=d.config.communication?.routing?.max_hops||32;updateArchitectureInfo(true);d.channel_models.forEach(x=>$('channelModel').add(new Option(x.replaceAll('_',' '),x)));$('channelModel').value=d.config.radio.channel_model;$('neighborRadius').value=d.config.radio.neighbor_radius_m||38;const ev=d.config.event||{};$('eventModel').value=ev.model||'deterministic';if(Array.isArray(ev.origin)){setField('eventX',ev.origin[0]);setField('eventY',ev.origin[1])}setField('eventStart',ev.start_time_s);setField('eventSpeed',ev.speed_m_s);setField('eventRadius',ev.radius_max_m);setField('eventStartMin',ev.start_min_s);setField('eventStartMax',ev.start_max_s);setField('eventSpeedMin',ev.speed_min_m_s);setField('eventSpeedMax',ev.speed_max_m_s);setField('eventRadiusMin',ev.radius_min_m);setField('eventRadiusMaxStochastic',ev.radius_max_m_stochastic);setField('eventOriginMargin',ev.origin_margin_m);if(Array.isArray(ev.risk_center)){setField('eventRiskX',ev.risk_center[0]);setField('eventRiskY',ev.risk_center[1])}setField('eventRiskSigma',ev.risk_sigma_m);updateEventModelInfo();const mob=d.config.mobility||{};$('mobilityModel').value=mob.model||'static';$('mobilitySpeed').value=mob.speed_m_s??0;$('mobilityInterval').value=mob.update_interval_s??0.5;$('mobilityDirection').value=mob.direction_deg??0;$('mobilityChange').value=mob.direction_change_interval_s??5;$('mobilityFraction').value=(mob.mobile_fraction??1)*100;updateMobilityInfo();d.environment_profiles.forEach(x=>$('environment').add(new Option(x.replaceAll('_',' '),x)));$('environment').value=d.config.environment?.profile||'custom';radioProfiles=d.radio_profiles||{};Object.entries(radioProfiles).forEach(([k,p])=>$('radioProfile').add(new Option(p.label||k,k)));buildBatchSelectors(d.channel_models,radioProfiles);if($('batchCpuInfo'))$('batchCpuInfo').textContent=`CPU detectada: ${d.logical_cpus||'?'} procesadores lógicos · Auto usará ${d.auto_workers||'?'} workers`;if($('batchWorkers')&&d.logical_cpus){Array.from($('batchWorkers').options).forEach(o=>{if(o.value!=='auto'&&Number(o.value)>Number(d.logical_cpus))o.remove()})}$('radioProfile').value=d.config.radio.radio_profile||'esp_now_test002_real';$('radioProfile').addEventListener('change',applySelectedRadioProfile);applySelectedRadioProfile();playback.duration=num('simTime');fitCanvas();await generate();await refreshConfigurations()}catch(e){$('serverStatus').textContent='Sin conexión';toast(e.message);fitCanvas()}})();

$('policy').addEventListener('change',()=>{renderPluginInfo();updateArchitectureInfo(true);clearExperimentDownloads();if(positions.length)preview()});
$('loadPluginBtn').addEventListener('click',loadPluginFile);
$('architecture').addEventListener('change',()=>{updateArchitectureInfo(false);clearExperimentDownloads();if(positions.length)preview()});
$('maxHops').addEventListener('change',()=>{clearExperimentDownloads();if(positions.length)preview()});
$('linkView')?.addEventListener('change',()=>{draw();toast(`${currentLinkEdges().length} enlaces en vista ${$('linkView').selectedOptions[0].text}`)});

// v0.26 Asynchronous Experiment Manager -------------------------------------------------
function parseNumberList(text){return [...new Set(String(text).split(',').map(x=>Number(x.trim())).filter(x=>Number.isFinite(x)&&x>0).map(x=>Math.floor(x)))]}
function parseAreas(text){const out=[];for(const part of String(text).split(',')){const m=part.trim().match(/^([0-9.]+)\s*[xX×]\s*([0-9.]+)$/);if(m){const w=Number(m[1]),h=Number(m[2]);if(w>0&&h>0)out.push([w,h])}}return out}
function selectedBatch(group){return Array.from(document.querySelectorAll(`#${group} input[type=checkbox]:checked`)).map(x=>x.value)}
function addBatchCheck(container,id,label,checked=false){const l=document.createElement('label'),i=document.createElement('input');i.type='checkbox';i.value=id;i.checked=checked;i.addEventListener('change',updateBatchCount);l.append(i,document.createTextNode(label));container.appendChild(l)}
function buildBatchSelectors(channelModels,profiles){
  const pc=$('batchPolicies'),cc=$('batchChannels'),rc=$('batchRadios');pc.innerHTML='';cc.innerHTML='';rc.innerHTML='';
  Array.from($('policy').options).forEach(o=>addBatchCheck(pc,o.value,o.text,['periodic','event_driven','distributed_edge','dstep'].includes(o.value)));
  channelModels.forEach(ch=>addBatchCheck(cc,ch,ch.replaceAll('_',' '),['log_normal','rician'].includes(ch)));
  Object.entries(profiles).forEach(([id,p])=>addBatchCheck(rc,id,p.label||id,id==='esp_now_experimental'));
  updateBatchCount();
}
function updateBatchCount(){
  const n=parseNumberList($('batchNodes')?.value||''),a=parseAreas($('batchAreas')?.value||''),p=selectedBatch('batchPolicies'),c=selectedBatch('batchChannels'),r=selectedBatch('batchRadios'),runs=Math.max(0,Math.floor(num('batchRuns')||0));
  const total=n.length*a.length*p.length*c.length*r.length*runs;
  if($('batchCount'))$('batchCount').textContent=`${total.toLocaleString()} simulaciones · ${n.length} tamaños × ${a.length} áreas × ${p.length} algoritmos × ${c.length} canales × ${r.length} radios × ${runs} rep.`;
  return total;
}

let resourceTimer=null;
function renderResourceGuard(pf){
  if(!pf)return;const s=pf.snapshot||{},badge=$('resourceBadge');
  badge.textContent=pf.status==='good'?'GOOD':pf.status==='warning'?'LIMITADO':'BLOQUEADO';badge.className=`resource-badge ${pf.status}`;
  const cpu=s.cpu_percent==null?'—':`${Number(s.cpu_percent).toFixed(0)}%`;const ram=s.ram_available_gb==null?'—':`${s.ram_available_gb} GB (${s.ram_available_pct}%)`;
  $('resourceMetrics').innerHTML=`<span>CPU actual: <b>${cpu}</b></span><span>RAM libre: <b>${ram}</b></span><span>Disco libre: <b>${s.disk_free_gb??'—'} GB</b></span><span>Workers seguros: <b>${pf.safe_workers}</b></span>`;
  $('resourceMessage').textContent=(pf.reasons||[]).join(' ') + ` · Reserva RAM: ${pf.reserve_ram_gb} GB.`;
}
async function refreshResourceGuard(){
  try{const nodes=parseNumberList($('batchNodes')?.value||'20');const d=await api('/api/resource-preflight',{matrix:{node_counts:nodes.length?nodes:[20],workers:$('batchWorkers')?.value||'auto',execution_mode:$('batchExecutionMode')?.value||'parallel_cpu'}});renderResourceGuard(d.preflight);return d.preflight}catch(e){$('resourceMessage').textContent=`No se pudo evaluar recursos: ${e.message}`;return null}
}

let activeCampaignId=null,batchPollTimer=null;
function fmtDuration(sec){if(sec==null||!Number.isFinite(sec))return '—';sec=Math.max(0,Math.round(sec));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),ss=sec%60;return h?`${h}h ${m}m ${ss}s`:m?`${m}m ${ss}s`:`${ss}s`}
function showBatchDownloads(d){const f=d.files||{};setDownload('batchZip',d.zip_url);setDownload('batchResults',f['campaign_results.csv']);setDownload('batchAggregate',f['aggregate_summary.csv']);setDownload('batchMatrix',f['experiment_matrix.csv']);setDownload('batchFailures',f['failures.csv']);setDownload('batchConfig',f['campaign_config.json']);$('batchDownloads').classList.remove('hidden')}
function renderCampaignStatus(d){
  const done=(d.completed_runs||0)+(d.failed_runs||0),total=d.requested_runs||0,pct=total?100*done/total:0;
  $('batchProgressWrap').classList.remove('hidden');$('batchProgressBar').style.width=`${Math.min(100,pct)}%`;$('batchProgressText').textContent=`${done.toLocaleString()} / ${total.toLocaleString()} · ${pct.toFixed(1)}% · transcurrido ${fmtDuration(d.elapsed_s)} · ETA ${fmtDuration(d.eta_s)}`;
  const c=d.current_case;const caseText=c?` · actual: ${c.nodes} nodos, ${c.policy}, ${c.channel}, ${c.radio}, rep. ${c.replicate}`:'';
  const adaptive=d.active_worker_limit!=null?` · activos ${d.active_worker_limit}/${d.workers||1}`:'';
  const perf=d.execution_mode?` · ${d.execution_mode==='parallel_cpu'?'CPU paralela':'CPU secuencial'} · ${d.workers||1} worker(s) / ${d.logical_cpus||'?'} lógicos${adaptive}`:'';
  if(d.resource_state)renderResourceGuard(d.resource_state);
  $('batchStatus').innerHTML=`Campaña <b>${d.id}</b> · ${d.status}${perf}${caseText}<br>${d.completed_runs||0} completadas · ${d.failed_runs||0} fallos${d.message?` · ${d.message}`:''}`;
  const running=['starting','running','paused','cancelling'].includes(d.status);$('batchRunBtn').disabled=running;$('batchRunBtn').textContent=running?'Campaña en ejecución…':'▶ Ejecutar campaña';
  $('batchPauseBtn').disabled=!['running','paused'].includes(d.status);$('batchPauseBtn').textContent=d.status==='paused'?'▶ Continuar':'⏸ Pausar';$('batchCancelBtn').disabled=!['starting','running','paused'].includes(d.status);
  $('batchResumeBtn').classList.toggle('hidden',!(d.recoverable&&!running)||!['cancelled','error','interrupted'].includes(d.status));
  if(['completed','cancelled','error'].includes(d.status)){if(batchPollTimer){clearInterval(batchPollTimer);batchPollTimer=null}if(d.completed_runs||d.failed_runs)showBatchDownloads(d);}
  if(d.status==='completed'){toast(`Campaña completada: ${d.completed_runs} corridas`);localStorage.removeItem('wsnActiveCampaign')}
}
async function pollCampaign(){if(!activeCampaignId)return;try{const d=await api(`/api/campaign-status/${activeCampaignId}`);renderCampaignStatus(d)}catch(e){$('batchStatus').textContent=`No se pudo consultar la campaña: ${e.message}`}}
function beginCampaignPolling(id){activeCampaignId=id;localStorage.setItem('wsnActiveCampaign',id);if(batchPollTimer)clearInterval(batchPollTimer);pollCampaign();batchPollTimer=setInterval(pollCampaign,1000)}
async function runCampaign(){
  const nodes=parseNumberList($('batchNodes').value),areas=parseAreas($('batchAreas').value),policies=selectedBatch('batchPolicies'),channels=selectedBatch('batchChannels'),radios=selectedBatch('batchRadios'),repetitions=Math.max(1,Math.floor(num('batchRuns'))),seedBase=Math.floor(num('batchSeed'));
  const total=updateBatchCount();if(!nodes.length||!areas.length||!policies.length||!channels.length||!radios.length)return toast('Completa todos los ejes de la campaña');if(total>10000)return toast('La campaña supera el límite GUI de 10.000 corridas');
  const matrix={node_counts:nodes,areas,policies,channels,radios,repetitions,seed_base:seedBase,architecture_mode:$('batchArchitectureMode').value,execution_mode:$('batchExecutionMode').value,workers:$('batchWorkers').value};
  $('batchDownloads').classList.add('hidden');$('batchRunBtn').disabled=true;$('batchStatus').textContent='Comprobando recursos del sistema...';
  try{const pre=await api('/api/resource-preflight',{matrix});renderResourceGuard(pre.preflight);if(pre.preflight.status==='blocked'){throw new Error((pre.preflight.reasons||['Recursos insuficientes']).join(' '))}
    $('batchStatus').textContent='Iniciando campaña en segundo plano...';const base=payload();base.positions=null;const d=await api('/api/campaign-run',{base_payload:base,matrix});renderCampaignStatus(d);beginCampaignPolling(d.id)}catch(e){$('batchStatus').textContent=`Error: ${e.message}`;$('batchRunBtn').disabled=false;toast(e.message)}
}
async function campaignControl(action){if(!activeCampaignId)return;try{const d=await api(`/api/campaign-control/${activeCampaignId}`,{action});renderCampaignStatus(d);if(action==='resume')beginCampaignPolling(activeCampaignId)}catch(e){toast(e.message)}}
$('batchPauseBtn')?.addEventListener('click',()=>campaignControl($('batchPauseBtn').textContent.includes('Continuar')?'resume':'pause'));
$('batchCancelBtn')?.addEventListener('click',()=>campaignControl('cancel'));
$('batchResumeBtn')?.addEventListener('click',()=>campaignControl('resume'));
['batchNodes','batchAreas','batchRuns','batchSeed','batchExecutionMode','batchWorkers'].forEach(id=>$(id)?.addEventListener('input',()=>{updateBatchCount();refreshResourceGuard()}));$('batchArchitectureMode')?.addEventListener('change',updateBatchCount);$('batchRunBtn')?.addEventListener('click',runCampaign);
setTimeout(()=>{const last=localStorage.getItem('wsnActiveCampaign');if(last){activeCampaignId=last;api(`/api/campaign-status/${last}`).then(d=>{renderCampaignStatus(d);if(['starting','running','paused','cancelling'].includes(d.status))beginCampaignPolling(last)}).catch(()=>{})}},1200);

$('batchExecutionMode')?.addEventListener('change',()=>{$('batchWorkers').disabled=$('batchExecutionMode').value==='sequential';updateBatchCount()});

setTimeout(()=>{refreshResourceGuard();if(resourceTimer)clearInterval(resourceTimer);resourceTimer=setInterval(()=>{if(!activeCampaignId)refreshResourceGuard()},3000)},1400);
