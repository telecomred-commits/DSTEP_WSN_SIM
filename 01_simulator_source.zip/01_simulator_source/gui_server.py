#!/usr/bin/env python3
"""WSN Edge-AI Simulator v0.42 algorithm diagnostics + stochastic events + mobility + resource-aware parallel experiment manager + algorithm plugins + scenario-health + multi-radio playback.

Runs a dependency-free local HTTP server and reuses the v0.16 simulation engine.
"""
from __future__ import annotations

import argparse
import copy
import os
import csv
import io
import json
import math
import mimetypes
import multiprocessing as mp
import random
import re
import unicodedata
import threading
import time
import webbrowser
import zipfile
import shutil
import platform
import ctypes
import subprocess
import sys
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from wsn_sim.simulator import Simulator
from wsn_sim.radio.profiles import RADIO_PROFILES
from wsn_sim.metrics.collector import summarize
from wsn_sim.plugins.loader import discover_plugins, plugin_metadata, validate_plugin_file, USER_PLUGIN_DIR

ROOT = Path(__file__).resolve().parent
GUI_ROOT = ROOT / "gui"
BASE_CONFIG_PATH = ROOT / "config.json"
EXPERIMENTS_ROOT = ROOT / "results" / "gui_experiments"
CAMPAIGNS_ROOT = ROOT / "results" / "gui_campaigns"
CONFIGURATIONS_ROOT = ROOT / "configurations"
EXPERIMENTS_ROOT.mkdir(parents=True, exist_ok=True)
CAMPAIGNS_ROOT.mkdir(parents=True, exist_ok=True)
CONFIGURATIONS_ROOT.mkdir(parents=True, exist_ok=True)

CAMPAIGN_JOBS = {}
CAMPAIGN_LOCK = threading.RLock()


def load_base_config():
    with BASE_CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def _configuration_slug(name):
    display = str(name or "").strip()
    if not display:
        raise ValueError("Escribe un nombre para la configuración")
    if len(display) > 120:
        raise ValueError("El nombre de la configuración es demasiado largo")
    normalized = unicodedata.normalize("NFKD", display).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", normalized).strip("._-")
    if not slug:
        raise ValueError("El nombre de la configuración no contiene caracteres válidos")
    return display, slug[:100]


def list_saved_configurations():
    items = []
    for fp in sorted(CONFIGURATIONS_ROOT.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            items.append({
                "id": fp.stem,
                "name": data.get("name", fp.stem),
                "created_utc": data.get("created_utc"),
                "updated_utc": data.get("updated_utc"),
                "simulator_version": data.get("simulator_version"),
            })
        except Exception:
            continue
    return items


def save_named_configuration(name, snapshot, overwrite=False):
    display, slug = _configuration_slug(name)
    target = CONFIGURATIONS_ROOT / f"{slug}.json"
    if target.exists() and not overwrite:
        raise FileExistsError(f"Ya existe una configuración llamada '{display}'")
    now = datetime.now(timezone.utc).isoformat()
    created = now
    if target.exists():
        try:
            created = json.loads(target.read_text(encoding="utf-8")).get("created_utc") or now
        except Exception:
            pass
    record = {
        "schema_version": 1,
        "simulator_version": "0.42",
        "name": display,
        "id": slug,
        "created_utc": created,
        "updated_utc": now,
        "snapshot": snapshot,
    }
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(target)
    return {"ok": True, "configuration": {k: record.get(k) for k in ("id","name","created_utc","updated_utc","simulator_version")}}


def load_named_configuration(config_id):
    _, slug = _configuration_slug(config_id)
    target = CONFIGURATIONS_ROOT / f"{slug}.json"
    if not target.exists():
        raise FileNotFoundError("Configuración no encontrada")
    return json.loads(target.read_text(encoding="utf-8"))


def delete_named_configuration(config_id):
    _, slug = _configuration_slug(config_id)
    target = CONFIGURATIONS_ROOT / f"{slug}.json"
    if not target.exists():
        raise FileNotFoundError("Configuración no encontrada")
    target.unlink()
    return {"ok": True, "id": slug}


def deep_update(target, patch):
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            deep_update(target[key], value)
        else:
            target[key] = value
    return target


def build_config(payload):
    cfg = copy.deepcopy(load_base_config())
    patch = payload.get("config", {})
    # If a caller selects a non-default radio profile, apply the profile first
    # and then apply explicit request fields. This keeps profile defaults coherent
    # while preserving user overrides supplied in the same request.
    requested_profile = (patch.get("radio") or {}).get("radio_profile") if isinstance(patch, dict) else None
    if requested_profile and requested_profile != cfg.get("radio", {}).get("radio_profile"):
        _apply_radio_profile(cfg, str(requested_profile))
    deep_update(cfg, patch)

    node_count = int(payload.get("node_count", cfg.get("node_counts", [20])[0]))
    policy = str(payload.get("policy", "dstep"))
    seed = int(payload.get("seed", cfg.get("seed", 1234)))
    positions = payload.get("positions")

    plugins = discover_plugins()
    if policy not in cfg.get("policies", []) and policy not in plugins:
        raise ValueError(f"Unknown policy: {policy}")
    if policy.startswith("plugin:") and not plugins.get(policy, {}).get("valid", False):
        raise ValueError(f"Invalid algorithm plugin: {plugins.get(policy, {}).get('error', policy)}")

    architecture = cfg.get("communication", {}).get("architecture", "distributed")
    allowed_architectures = {"distributed", "direct_to_sink", "multi_hop_to_sink"}
    if architecture not in allowed_architectures:
        raise ValueError(f"Unknown communication architecture: {architecture}")
    compatible = {
        "periodic": allowed_architectures,
        "event_driven": allowed_architectures,
        "central_edge": {"direct_to_sink", "multi_hop_to_sink"},
        "distributed_edge": {"distributed"},
        "dstep": {"distributed"},
        "dstep_payoff": {"distributed"},
        "send_on_delta": set(allowed_architectures),
        "teen_like": set(allowed_architectures),
        "voi_baseline": set(allowed_architectures),
    }
    if policy.startswith("plugin:"):
        compatible[policy] = set(plugins[policy].get("compatible_architectures", list(allowed_architectures)))
    if architecture not in compatible.get(policy, allowed_architectures):
        labels = {
            "distributed":"Distributed / peer-to-peer",
            "direct_to_sink":"Direct-to-Sink",
            "multi_hop_to_sink":"Multi-hop-to-Sink",
        }
        valid = ", ".join(labels[x] for x in sorted(compatible[policy]))
        raise ValueError(f"{policy} is not compatible with {labels[architecture]}. Use: {valid}.")

    if node_count < 1 or node_count > 1000:
        raise ValueError("node_count must be between 1 and 1000")

    mobility = dict(cfg.get("mobility") or {})
    mobility_model = str(mobility.get("model", "static")).strip().lower()
    allowed_mobility = {"static", "linear", "random_walk", "random_waypoint"}
    if mobility_model not in allowed_mobility:
        raise ValueError(f"Unknown mobility model: {mobility_model}")
    if float(mobility.get("speed_m_s", 0.0)) < 0:
        raise ValueError("mobility.speed_m_s must be >= 0")
    if float(mobility.get("update_interval_s", 0.5)) <= 0:
        raise ValueError("mobility.update_interval_s must be > 0")
    if float(mobility.get("direction_change_interval_s", 5.0)) <= 0:
        raise ValueError("mobility.direction_change_interval_s must be > 0")
    mobile_fraction = float(mobility.get("mobile_fraction", 1.0))
    if not 0.0 <= mobile_fraction <= 1.0:
        raise ValueError("mobility.mobile_fraction must be between 0 and 1")

    event_cfg = dict(cfg.get("event") or {})
    event_model = str(event_cfg.get("model", "deterministic")).strip().lower()
    if event_model not in {"deterministic", "stochastic", "spatial_risk"}:
        raise ValueError("event.model must be deterministic, stochastic or spatial_risk")
    if event_model == "deterministic":
        if float(event_cfg.get("speed_m_s", 0)) <= 0:
            raise ValueError("event.speed_m_s must be > 0")
        if float(event_cfg.get("start_time_s", 0)) < 0:
            raise ValueError("event.start_time_s must be >= 0")
    else:
        if float(event_cfg.get("speed_min_m_s", 0)) <= 0 or float(event_cfg.get("speed_max_m_s", 0)) <= 0:
            raise ValueError("stochastic event speeds must be > 0")
        if float(event_cfg.get("start_min_s", 0)) < 0 or float(event_cfg.get("start_max_s", 0)) < 0:
            raise ValueError("stochastic event start range must be >= 0")
        if float(event_cfg.get("radius_min_m", 0)) < 0 or float(event_cfg.get("radius_max_m_stochastic", 0)) < 0:
            raise ValueError("stochastic event radius range must be >= 0")
        if event_model == "spatial_risk" and float(event_cfg.get("risk_sigma_m", 0)) <= 0:
            raise ValueError("event.risk_sigma_m must be > 0")

    battery = dict(cfg.get("battery") or {})
    battery_mode = str(battery.get("mode", "ideal")).strip().lower()
    if battery_mode not in {"ideal", "battery"}:
        raise ValueError("battery.mode must be ideal or battery")
    if battery_mode == "battery":
        if float(battery.get("capacity_mah", 0)) <= 0:
            raise ValueError("battery.capacity_mah must be > 0")
        if float(battery.get("voltage_v", 0)) <= 0:
            raise ValueError("battery.voltage_v must be > 0")
        soc = float(battery.get("initial_soc", 1.0))
        if not 0 < soc <= 1:
            raise ValueError("battery.initial_soc must be > 0 and <= 1")

    mac = dict(cfg.get("mac") or {})
    if int(mac.get("queue_capacity", 16)) < 0:
        raise ValueError("mac.queue_capacity must be >= 0")
    rel = dict(mac.get("reliability") or {})
    if int(rel.get("max_retries", 3)) < 0:
        raise ValueError("mac.reliability.max_retries must be >= 0")
    if int(rel.get("ack_bytes", 14)) <= 0:
        raise ValueError("mac.reliability.ack_bytes must be > 0")
    for key in ("sifs_s", "ack_timeout_s", "retry_backoff_s"):
        if float(rel.get(key, 0.0)) < 0:
            raise ValueError(f"mac.reliability.{key} must be >= 0")

    area = cfg.get("area_m", [100.0, 100.0])
    if len(area) != 2 or float(area[0]) <= 0 or float(area[1]) <= 0:
        raise ValueError("area_m must contain two positive values")
    w, h = map(float, area)

    if positions is not None:
        if len(positions) != node_count:
            raise ValueError("positions must contain exactly node_count points")
        clean = []
        for i, p in enumerate(positions):
            if not isinstance(p, (list, tuple)) or len(p) != 2:
                raise ValueError(f"Invalid position for node {i}")
            x, y = float(p[0]), float(p[1])
            if not (0.0 <= x <= w and 0.0 <= y <= h):
                raise ValueError(f"Node {i} lies outside the configured area")
            clean.append([x, y])
        cfg.setdefault("topology", {})["placement"] = "manual"
        cfg["topology"]["manual_positions"] = clean

    cfg["node_counts"] = [node_count]
    cfg["policies"] = [policy]
    cfg["seed"] = seed
    return cfg, node_count, policy, seed



def _safe_cell(value):
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if value is None:
        return ""
    return value


def write_csv(path, rows, preferred_fields=None):
    rows = list(rows)
    fields = list(preferred_fields or [])
    seen = set(fields)
    for row in rows:
        for key in row:
            if key not in seen:
                fields.append(key); seen.add(key)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields or ["empty"])
        writer.writeheader()
        for row in rows:
            writer.writerow({k: _safe_cell(row.get(k)) for k in fields})


def export_experiment(result, cfg, node_count, policy, seed):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_policy = "".join(ch if ch.isalnum() or ch in "_-" else "-" for ch in policy)
    base_id = f"{stamp}_{safe_policy}_n{node_count}_seed{seed}"
    experiment_id = base_id
    idx = 2
    while (EXPERIMENTS_ROOT / experiment_id).exists():
        experiment_id = f"{base_id}_{idx}"; idx += 1
    folder = EXPERIMENTS_ROOT / experiment_id
    folder.mkdir(parents=True)

    (folder / "config.json").write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    metadata = {
        "simulator_version": "0.42",
        "engine_lineage": "v0.42 externally calibrated ESP32 TEST002 channel + v0.40.1 packet-level airtime/SINR/CSMA-lite/ACK engine",
        "experiment_id": experiment_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "policy": policy, "node_count": node_count, "seed": seed,
        "algorithm_plugin": plugin_metadata(policy) if policy.startswith("plugin:") else None,
        "communication_architecture": cfg.get("communication", {}).get("architecture", "distributed"),
        "routing_strategy": cfg.get("communication", {}).get("routing", {}).get("strategy", "shortest_hop"),
        "radio_profile": cfg.get("radio", {}).get("radio_profile", "custom"),
        "radio_profile_evidence": RADIO_PROFILES.get(cfg.get("radio", {}).get("radio_profile", "custom"), {}).get("evidence", "user_defined"),
        "trace_events": len(result.get("trace", [])),
        "trace_truncated": bool(result.get("trace_meta", {}).get("truncated", False)),
        "mobility_trace_events": len(result.get("mobility_trace", [])),
        "mobility_trace_complete": bool(result.get("trace_meta", {}).get("mobility_complete", True)),
        "mobility_trace_interval_s": result.get("trace_meta", {}).get("mobility_trace_interval_s"),
        "packet_playback_events": len(result.get("packet_trace", [])),
        "packet_total_attempts": result.get("trace_meta", {}).get("packet_total_attempts", 0),
        "packet_playback_dropped": result.get("trace_meta", {}).get("packet_playback_dropped", 0),
        "packet_playback_complete_coverage": bool(result.get("trace_meta", {}).get("packet_playback_complete_coverage", True)),
        "packet_last_time_s": result.get("trace_meta", {}).get("packet_last_time_s"),
        "event_model": (result.get("ground_truth") or {}).get("model", cfg.get("event", {}).get("model", "deterministic")),
        "event_ground_truth": result.get("ground_truth"),
    }
    (folder / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    (folder / "ground_truth.json").write_text(json.dumps(result.get("ground_truth") or {}, indent=2, ensure_ascii=False), encoding="utf-8")
    (folder / "algorithm_diagnostic.json").write_text(json.dumps(result.get("algorithm_diagnostic") or {}, indent=2, ensure_ascii=False), encoding="utf-8")

    metrics = result.get("metrics") or {}
    write_csv(folder / "summary.csv", [{"experiment_id": experiment_id, "policy": policy, "node_count": node_count, "seed": seed, **metrics}])
    write_csv(folder / "nodes_final.csv", result.get("nodes", []), ["id","x","y","tx_power_dbm","detected","confirmed","tx_count","rx_count","energy_mj","alive","death_time_s","battery_remaining_mj","battery_remaining_pct","estimated_lifetime_s","first_detection_time","first_alert_time"])

    trace = result.get("trace", [])
    mobility_trace = result.get("mobility_trace", [])
    packet_trace = result.get("packet_trace", [])
    write_csv(folder / "event_trace.csv", trace, ["t","kind","node","source","target","message_type","success","reason","rssi_dbm","state","confidence","belief","energy_mj"])
    write_csv(folder / "mobility_trace.csv", mobility_trace, ["t","kind","node","x","y","old_x","old_y","distance_m","final_snapshot"])
    write_csv(folder / "packet_playback_trace.csv", packet_trace, ["t","kind","source","target","message_type","success","delay_s","rssi_dbm","reason","confidence"])
    packets = [e for e in trace if e.get("kind") == "packet"]
    write_csv(folder / "packets.csv", packets, ["t","source","target","message_type","success","delay_s","rssi_dbm","reason","confidence"])
    states = [e for e in trace if e.get("kind") in {"decision", "receive", "sample"}]
    write_csv(folder / "node_states.csv", states, ["t","kind","node","state","previous_state","value","signal","confidence","belief","detected","confirmed","energy_mj","tx_count","rx_count","tx_power_dbm"])
    estimates = []
    # Use the realized hidden Ground Truth, not the configured deterministic
    # defaults. This is essential for stochastic/spatial-risk experiments.
    gt = dict(result.get("ground_truth") or {})
    ox, oy = map(float, gt.get("origin", cfg.get("event", {}).get("origin", [0,0])))
    true_t0 = float(gt.get("start_time_s", cfg.get("event", {}).get("start_time_s", 0.0)))
    true_speed = float(gt.get("speed_m_s", cfg.get("event", {}).get("speed_m_s", 0.0)))
    for e in trace:
        if e.get("kind") != "decision" or not isinstance(e.get("est_origin"), list) or e.get("est_speed") is None or e.get("est_t0") is None:
            continue
        ex, ey = map(float, e["est_origin"])
        row = dict(e)
        row.update({
            "est_origin_x": ex, "est_origin_y": ey,
            "true_origin_x": ox, "true_origin_y": oy,
            "origin_error_m": math.hypot(ex-ox, ey-oy),
            "true_speed_m_s": true_speed, "speed_error_m_s": abs(float(e["est_speed"])-true_speed),
            "true_t0_s": true_t0, "t0_error_s": abs(float(e["est_t0"])-true_t0),
        })
        estimates.append(row)
    write_csv(folder / "estimates.csv", estimates, ["t","node","state","confirmed","confidence","belief","estimate_points","est_origin_x","est_origin_y","origin_error_m","est_speed","true_speed_m_s","speed_error_m_s","est_t0","true_t0_s","t0_error_s","est_eta"])

    zip_path = EXPERIMENTS_ROOT / f"{experiment_id}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fp in sorted(folder.iterdir()):
            if fp.is_file(): zf.write(fp, arcname=f"{experiment_id}/{fp.name}")
    return experiment_id, folder, zip_path



def _apply_radio_profile(cfg, profile_id):
    profile = RADIO_PROFILES.get(profile_id)
    if profile is None:
        raise ValueError(f"Unknown radio profile: {profile_id}")
    cfg.setdefault("radio", {})["radio_profile"] = profile_id
    # Custom deliberately preserves the values already entered in the base scenario.
    if profile_id != "custom":
        deep_update(cfg["radio"], copy.deepcopy(profile.get("radio", {})))
    return cfg


def _compatible_architectures_for(policy, plugins=None):
    allowed = {"distributed", "direct_to_sink", "multi_hop_to_sink"}
    base = {
        "periodic": allowed,
        "event_driven": allowed,
        "central_edge": {"direct_to_sink", "multi_hop_to_sink"},
        "distributed_edge": {"distributed"},
        "dstep": {"distributed"},
        "dstep_payoff": {"distributed"},
        "send_on_delta": set(allowed),
        "teen_like": set(allowed),
        "voi_baseline": set(allowed),
    }
    if policy.startswith("plugin:"):
        plugins = plugins or discover_plugins()
        meta = plugins.get(policy, {})
        return set(meta.get("compatible_architectures", list(allowed)))
    return set(base.get(policy, allowed))


def _campaign_architecture(policy, requested, mode, plugins=None):
    valid = _compatible_architectures_for(policy, plugins)
    if mode == "force":
        if requested not in valid:
            raise ValueError(f"{policy} is incompatible with forced architecture {requested}")
        return requested
    # Auto mode preserves each algorithm's natural architecture while allowing
    # Periodic/Event Driven to use the currently selected architecture when valid.
    if policy == "central_edge":
        return requested if requested in valid else "direct_to_sink"
    if policy in {"dstep", "dstep_payoff", "distributed_edge"}:
        return "distributed"
    if policy.startswith("plugin:"):
        if requested in valid:
            return requested
        for candidate in ("distributed", "direct_to_sink", "multi_hop_to_sink"):
            if candidate in valid:
                return candidate
    return requested if requested in valid else "distributed"


def _campaign_id():
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    base = f"campaign_{stamp}"
    cid = base; idx = 2
    while (CAMPAIGNS_ROOT / cid).exists() or (CAMPAIGNS_ROOT / f"{cid}.zip").exists():
        cid = f"{base}_{idx}"; idx += 1
    return cid


def _mean_std(values):
    vals = [float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(float(v))]
    if not vals:
        return None, None
    m = sum(vals) / len(vals)
    var = sum((x-m)**2 for x in vals) / len(vals)
    return m, math.sqrt(var)



_RESOURCE_CPU_LOCK = threading.Lock()
_RESOURCE_CPU_PREV = None

def _memory_snapshot():
    """Return total/available physical RAM using stdlib only."""
    try:
        if os.name == "nt":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            st = MEMORYSTATUSEX(); st.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
                return int(st.ullTotalPhys), int(st.ullAvailPhys)
        if sys.platform.startswith("linux"):
            vals={}
            for line in Path('/proc/meminfo').read_text().splitlines():
                if ':' in line:
                    k,v=line.split(':',1); vals[k]=int(v.strip().split()[0])*1024
            return int(vals.get('MemTotal',0)), int(vals.get('MemAvailable',vals.get('MemFree',0)))
        if sys.platform == 'darwin':
            total=int(subprocess.check_output(['sysctl','-n','hw.memsize'], text=True).strip())
            # vm_stat values are pages; available ~= free + inactive + speculative
            out=subprocess.check_output(['vm_stat'], text=True)
            page=4096
            import re
            m=re.search(r'page size of (\\d+) bytes',out)
            if m: page=int(m.group(1))
            vals={}
            for line in out.splitlines():
                if ':' in line:
                    k,v=line.split(':',1); vals[k.strip()]=int(v.strip().strip('.').replace('.','') or 0)
            avail=page*sum(vals.get(k,0) for k in ['Pages free','Pages inactive','Pages speculative','Pages purgeable'])
            return total,int(avail)
    except Exception:
        pass
    return 0,0

def _cpu_percent_snapshot():
    """Best-effort whole-system CPU usage. Returns None when unavailable."""
    global _RESOURCE_CPU_PREV
    try:
        if os.name == 'nt':
            class FILETIME(ctypes.Structure):
                _fields_=[('low',ctypes.c_ulong),('high',ctypes.c_ulong)]
            idle,kernel,user=FILETIME(),FILETIME(),FILETIME()
            if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):
                return None
            cv=lambda x:(int(x.high)<<32)+int(x.low)
            now=(cv(idle),cv(kernel),cv(user))
            with _RESOURCE_CPU_LOCK:
                prev=_RESOURCE_CPU_PREV; _RESOURCE_CPU_PREV=now
            if not prev: return None
            idle_d=now[0]-prev[0]; total_d=(now[1]-prev[1])+(now[2]-prev[2])
            return round(max(0.0,min(100.0,100.0*(1.0-idle_d/total_d))),1) if total_d>0 else None
        if hasattr(os,'getloadavg'):
            one=os.getloadavg()[0]; cpus=max(1,int(os.cpu_count() or 1))
            return round(max(0.0,min(100.0,100.0*one/cpus)),1)
    except Exception:
        pass
    return None

def resource_snapshot():
    logical=max(1,int(os.cpu_count() or 1))
    total,avail=_memory_snapshot()
    disk=shutil.disk_usage(str(ROOT))
    cpu=_cpu_percent_snapshot()
    gib=1024**3
    return {
        'logical_cpus':logical,'cpu_percent':cpu,
        'ram_total_bytes':total,'ram_available_bytes':avail,
        'ram_total_gb':round(total/gib,2) if total else None,
        'ram_available_gb':round(avail/gib,2) if avail else None,
        'ram_available_pct':round(100*avail/total,1) if total else None,
        'disk_free_bytes':int(disk.free),'disk_free_gb':round(disk.free/gib,2),
        'platform':platform.system(),'platform_release':platform.release(),
    }

def resource_preflight(max_nodes=100, requested_workers='auto', execution_mode='parallel_cpu'):
    snap=resource_snapshot(); logical=snap['logical_cpus']
    # Conservative memory budget. This is deliberately an upper planning estimate,
    # not a scientific model of simulator memory consumption.
    worker_mb=max(192.0, 192.0 + 0.35*max(1,int(max_nodes)))
    total=snap.get('ram_total_bytes') or 0; avail=snap.get('ram_available_bytes') or 0
    reserve=max(1024**3, int(total*0.15)) if total else 1024**3
    mem_safe=max(1, int(max(0,avail-reserve)//int(worker_mb*1024**2))) if avail else max(1,min(8,logical-2 if logical>2 else 1))
    cpu_safe=max(1,min(8,logical-2 if logical>2 else 1))
    cpu=snap.get('cpu_percent')
    if cpu is not None and cpu>=85: cpu_safe=max(1,min(cpu_safe,2))
    elif cpu is not None and cpu>=70: cpu_safe=max(1,min(cpu_safe,4))
    safe=max(1,min(cpu_safe,mem_safe))
    disk_ok=snap['disk_free_bytes'] >= 512*1024**2
    memory_hard_ok=(not total) or (avail >= max(512*1024**2,int(total*0.07)))
    if execution_mode=='sequential': safe=1
    if requested_workers in (None,'','auto'):
        effective=safe; manual_unsafe=False
    else:
        req=max(1,int(requested_workers)); effective=req; manual_unsafe=req>safe
    status='good'; reasons=[]
    if not disk_ok:
        status='blocked'; reasons.append('Menos de 512 MB libres en disco.')
    if not memory_hard_ok:
        status='blocked'; reasons.append('Memoria RAM disponible por debajo del margen mínimo de seguridad.')
    if manual_unsafe and status!='blocked':
        status='blocked'; reasons.append(f'{requested_workers} workers exceden la recomendación segura actual ({safe}).')
    elif cpu is not None and cpu>=70 and status=='good':
        status='warning'; reasons.append('La CPU ya tiene una carga elevada; Auto reducirá la concurrencia.')
    elif snap.get('ram_available_pct') is not None and snap['ram_available_pct']<20 and status=='good':
        status='warning'; reasons.append('RAM disponible limitada; Auto reducirá la concurrencia.')
    if not reasons and status=='good': reasons.append('Recursos suficientes con margen de seguridad.')
    return {'status':status,'safe_workers':safe,'effective_workers':effective,'estimated_worker_mb':round(worker_mb,1),
            'reserve_ram_gb':round(reserve/1024**3,2),'reasons':reasons,'snapshot':snap}

def _campaign_validate(payload):
    base_payload = copy.deepcopy(payload.get("base_payload") or {})
    matrix = copy.deepcopy(payload.get("matrix") or {})
    node_counts = [int(x) for x in matrix.get("node_counts", [])]
    areas = matrix.get("areas", [])
    policies = [str(x) for x in matrix.get("policies", [])]
    channels = [str(x) for x in matrix.get("channels", [])]
    radios = [str(x) for x in matrix.get("radios", [])]
    repetitions = int(matrix.get("repetitions", 1))
    seed_base = int(matrix.get("seed_base", base_payload.get("seed", 1234)))
    architecture_mode = str(matrix.get("architecture_mode", "auto"))
    execution_mode = str(matrix.get("execution_mode", "parallel_cpu"))
    workers_raw = matrix.get("workers", "auto")
    logical_cpus = max(1, int(os.cpu_count() or 1))
    max_nodes_for_resources = max(node_counts) if node_counts else int(base_payload.get("node_count",20) or 20)
    preflight = resource_preflight(max_nodes_for_resources, workers_raw, execution_mode)
    if preflight["status"] == "blocked":
        raise ValueError("Resource check blocked campaign: " + " ".join(preflight["reasons"]))
    if workers_raw in (None, "", "auto"):
        workers = int(preflight["effective_workers"]); workers_setting = "auto"
    else:
        workers = int(workers_raw)
        if workers < 1 or workers > logical_cpus:
            raise ValueError(f"workers must be between 1 and {logical_cpus}")
        workers_setting = workers
    if execution_mode not in {"sequential", "parallel_cpu"}:
        raise ValueError("execution_mode must be sequential or parallel_cpu")
    if execution_mode == "sequential":
        workers = 1
    if not node_counts or not areas or not policies or not channels or not radios:
        raise ValueError("Campaign matrix must include nodes, areas, algorithms, channels, and radios")
    if repetitions < 1 or repetitions > 1000:
        raise ValueError("repetitions must be between 1 and 1000")
    if architecture_mode not in {"auto", "force"}:
        raise ValueError("architecture_mode must be auto or force")
    total = len(node_counts)*len(areas)*len(policies)*len(channels)*len(radios)*repetitions
    if total > 10000:
        raise ValueError(f"Campaign has {total} runs; maximum through the GUI is 10000")
    plugins = discover_plugins()
    known_channels = {"free_space","log_distance","log_normal","two_ray","rayleigh","rician","nakagami"}
    if any(ch not in known_channels for ch in channels):
        raise ValueError("Campaign contains an unknown channel model")
    if any(r not in RADIO_PROFILES for r in radios):
        raise ValueError("Campaign contains an unknown radio profile")
    for p in policies:
        if p not in load_base_config().get("policies", []) and p not in plugins:
            raise ValueError(f"Unknown campaign policy: {p}")
    for n in node_counts:
        if n < 1 or n > 1000:
            raise ValueError("campaign node counts must be between 1 and 1000")
    for ar in areas:
        if not isinstance(ar, (list, tuple)) or len(ar)!=2 or float(ar[0])<=0 or float(ar[1])<=0:
            raise ValueError("Each campaign area must be [width,height] with positive values")
    return base_payload, matrix, node_counts, areas, policies, channels, radios, repetitions, seed_base, architecture_mode, plugins, total, execution_mode, workers_setting, workers, logical_cpus


def _campaign_paths(campaign_id):
    folder = CAMPAIGNS_ROOT / campaign_id
    return folder, folder / "campaign_state.json"


def _atomic_json(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def _campaign_public(job):
    with CAMPAIGN_LOCK:
        d = {k:v for k,v in job.items() if k not in {"thread", "cancel_event", "pause_event", "payload", "run_rows", "failures", "completed_indices", "folder_abs"}}
    elapsed = max(0.0, time.time() - float(d.get("started_epoch", time.time()))) if d.get("started_epoch") else 0.0
    completed = int(d.get("completed_runs", 0)) + int(d.get("failed_runs", 0))
    total = max(1, int(d.get("requested_runs", 1)))
    rate = completed / elapsed if elapsed > 0 and completed else 0.0
    remaining = max(0, total - completed)
    d["elapsed_s"] = elapsed
    d["rate_runs_s"] = rate
    d["eta_s"] = remaining / rate if rate > 0 and d.get("status") in {"running","paused","cancelling"} else None
    d["progress_pct"] = 100.0 * completed / total
    return d


def _write_campaign_outputs(job, final=False):
    folder = Path(job["folder_abs"])
    run_rows = sorted(list(job.get("run_rows", [])), key=lambda r: int(r.get("run", 0))); failures = sorted(list(job.get("failures", [])), key=lambda r: int(r.get("run", 0)))
    write_csv(folder/"campaign_results.csv", run_rows)
    write_csv(folder/"failures.csv", failures,["run","replicate","seed","nodes","area_width_m","area_height_m","policy","communication_architecture","channel_model","radio_profile","error","type"])
    if final:
        group_keys=["nodes","area_width_m","area_height_m","policy","communication_architecture","channel_model","radio_profile","event_model"]
        groups={}
        for row in run_rows:
            key=tuple(row.get(k) for k in group_keys);groups.setdefault(key,[]).append(row)
        aggregate=[]
        preferred_metrics=["tx_packets","rx_packets","energy_mj","energy_jain_fairness","link_pdr","collision_loss_rate","channel_loss_rate","sensitivity_loss_rate","f1","dcr","mean_detection_delay_s","mean_alert_delay_s","mean_lead_time_s","mean_origin_error_m","mean_speed_error_m_s","mean_eta_error_s","node_density_per_km2","mean_nearest_neighbor_m","geometric_mean_degree","geometric_min_degree","geometric_link_density","geometric_largest_component_fraction","radio_configured_mean_degree","radio_configured_min_degree","radio_configured_link_density","radio_configured_largest_component_fraction","radio_mean_degree","radio_min_degree","radio_link_density","radio_largest_component_fraction","sink_reachability_fraction","functional_at_end","collisions","channel_losses","below_sensitivity","routing_delivered","routing_no_route","mean_route_hops_delivered"]
        for key, rows in groups.items():
            out={k:v for k,v in zip(group_keys,key)};out["runs"]=len(rows)
            for metric in preferred_metrics:
                values=[r.get(metric) for r in rows]
                if metric == "functional_at_end":
                    # Boolean scientific outcome -> success fraction in aggregate.
                    values=[1.0 if v is True else 0.0 if v is False else v for v in values]
                m,sd=_mean_std(values);out[f"{metric}_mean"]=m;out[f"{metric}_std"]=sd
            if out.get("functional_at_end_mean") is not None:
                out["functional_success_rate"] = out["functional_at_end_mean"]
            aggregate.append(out)
        write_csv(folder/"aggregate_summary.csv",aggregate)
        job["aggregate"] = aggregate[:200]

        # Observed operating thresholds across the campaign matrix. This does
        # not extrapolate beyond tested densities; it reports the lowest tested
        # density that still satisfies each criterion.
        bp=[]
        base_keys=["policy","communication_architecture","channel_model","radio_profile","event_model"]
        bybase={}
        for row in aggregate:
            key=tuple(row.get(k) for k in base_keys);bybase.setdefault(key,[]).append(row)
        dcfg=load_base_config().get("diagnostics",{})
        criteria=[("f1",float(dcfg.get("f1_min",0.90))), ("link_pdr",float(dcfg.get("link_pdr_min",0.80))), ("sink_reachability_fraction",float(dcfg.get("sink_reach_min",0.90)))]
        for key,rows in bybase.items():
            out={k:v for k,v in zip(base_keys,key)}
            for metric,thr in criteria:
                qualified=[]
                for r in rows:
                    value=r.get(f"{metric}_mean"); dens=r.get("node_density_per_km2_mean")
                    try:
                        if value is not None and dens is not None and float(value)>=thr: qualified.append((float(dens),float(value),r))
                    except (TypeError,ValueError): pass
                if qualified:
                    dens,val,rr=min(qualified,key=lambda x:x[0])
                    out[f"{metric}_threshold"]=thr;out[f"{metric}_min_tested_density_pass_per_km2"]=dens;out[f"{metric}_value_at_min_density"]=val
                    out[f"{metric}_nodes_at_min_density"]=rr.get("nodes");out[f"{metric}_area_at_min_density"]=f"{rr.get('area_width_m')}x{rr.get('area_height_m')}"
                else:
                    out[f"{metric}_threshold"]=thr;out[f"{metric}_min_tested_density_pass_per_km2"]=None
            bp.append(out)
        write_csv(folder/"diagnostic_breakpoints.csv",bp)
        # Persist the final public campaign state before creating the ZIP so
        # campaign_state.json inside the archive reflects completed/cancelled
        # status and finished_utc, rather than the last incremental "running" state.
        _persist_campaign_state(job)
        zip_path=CAMPAIGNS_ROOT/f"{job['id']}.zip"
        with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as zf:
            for fp in sorted(folder.iterdir()):
                if fp.is_file(): zf.write(fp,arcname=f"{job['id']}/{fp.name}")
        job["zip_url"] = f"/api/campaign-download/{job['id']}/zip"


def _persist_campaign_state(job):
    folder, state_path = _campaign_paths(job["id"])
    public = _campaign_public(job)
    public["saved_utc"] = datetime.now(timezone.utc).isoformat()
    _atomic_json(state_path, public)


def _campaign_cases(payload):
    """Build deterministic numbered work items for sequential or parallel execution."""
    (base_payload, matrix, node_counts, areas, policies, channels, radios,
     repetitions, seed_base, architecture_mode, plugins, total,
     execution_mode, workers_setting, workers, logical_cpus) = _campaign_validate(payload)
    requested_arch = str((base_payload.get("config") or {}).get("communication", {}).get("architecture", "distributed"))
    cases = []
    run_index = 0
    for n in node_counts:
        for ar in areas:
            for policy in policies:
                arch = _campaign_architecture(policy, requested_arch, architecture_mode, plugins)
                for channel in channels:
                    for radio_profile in radios:
                        for rep in range(repetitions):
                            run_index += 1
                            cases.append({
                                "run": run_index, "replicate": rep + 1,
                                "seed": seed_base + run_index - 1,
                                "nodes": n, "area": [float(ar[0]), float(ar[1])],
                                "policy": policy, "communication_architecture": arch,
                                "channel_model": channel, "radio_profile": radio_profile,
                                "base_payload": base_payload,
                            })
    return cases, {
        "requested_runs": total, "execution_mode": execution_mode,
        "workers_setting": workers_setting, "workers": workers,
        "logical_cpus": logical_cpus,
    }


def _run_campaign_case(case):
    """Process-safe execution of one deterministic campaign run."""
    run_index = int(case["run"]); rep = int(case["replicate"]); seed = int(case["seed"])
    n = int(case["nodes"]); ar = case["area"]; policy = str(case["policy"])
    arch = str(case["communication_architecture"]); channel = str(case["channel_model"])
    radio_profile = str(case["radio_profile"])
    try:
        pld = copy.deepcopy(case["base_payload"])
        pld["node_count"] = n; pld["policy"] = policy; pld["seed"] = seed; pld["positions"] = None
        pld.setdefault("config", {})["area_m"] = [float(ar[0]), float(ar[1])]
        pld["config"].setdefault("topology", {})["placement"] = "uniform_random"
        pld["config"]["topology"].pop("manual_positions", None)
        pld["config"].setdefault("radio", {})["channel_model"] = channel
        pld["config"].setdefault("environment", {})["channel_model"] = channel
        pld["config"].setdefault("communication", {})["architecture"] = arch
        cfg, _, _, _ = build_config(pld)
        _apply_radio_profile(cfg, radio_profile)
        cfg["radio"]["channel_model"] = channel
        cfg.setdefault("environment", {})["channel_model"] = channel
        sim = Simulator(cfg, n, policy, seed); sim.run(); metrics = summarize(sim)
        health = scenario_health(sim); diagnostic = algorithm_diagnostic(sim, metrics, health)
        gt = dict(getattr(sim, "event_ground_truth", {}) or {})
        row = {"run":run_index,"replicate":rep,"seed":seed,"nodes":n,
               "area_width_m":float(ar[0]),"area_height_m":float(ar[1]),"policy":policy,
               "communication_architecture":arch,"channel_model":channel,
               "radio_profile":radio_profile,
               "event_model":gt.get("model"),
               "event_origin_x_m":(gt.get("origin") or [None,None])[0],
               "event_origin_y_m":(gt.get("origin") or [None,None])[1],
               "event_start_time_s":gt.get("start_time_s"),
               "event_speed_m_s":gt.get("speed_m_s"),
               "event_radius_max_m":gt.get("radius_max_m"),
               "node_density_per_km2":health.get("node_density_per_km2"),
               "mean_nearest_neighbor_m":health.get("mean_nearest_neighbor_m"),
               "geometric_mean_degree":(health.get("geometric") or {}).get("mean_degree"),
               "geometric_min_degree":(health.get("geometric") or {}).get("min_degree"),
               "geometric_link_density":(health.get("geometric") or {}).get("link_density"),
               "geometric_largest_component_fraction":(health.get("geometric") or {}).get("largest_component_fraction"),
               "radio_configured_mean_degree":(health.get("radio_configured") or {}).get("mean_degree"),
               "radio_configured_min_degree":(health.get("radio_configured") or {}).get("min_degree"),
               "radio_configured_link_density":(health.get("radio_configured") or {}).get("link_density"),
               "radio_configured_largest_component_fraction":(health.get("radio_configured") or {}).get("largest_component_fraction"),
               "radio_mean_degree":(health.get("radio") or {}).get("mean_degree"),
               "radio_min_degree":(health.get("radio") or {}).get("min_degree"),
               "radio_link_density":(health.get("radio") or {}).get("link_density"),
               "radio_largest_component_fraction":(health.get("radio") or {}).get("largest_component_fraction"),
               "radio_degree_basis":health.get("radio_degree_basis"),
               "sink_reachability_fraction":health.get("sink_reachability_fraction"),
               "functional_at_end":diagnostic.get("functional_at_end"),
               **metrics}
        return {"ok": True, "row": row, "run": run_index}
    except Exception as exc:
        failure={"run":run_index,"replicate":rep,"seed":seed,"nodes":n,
                 "area_width_m":ar[0],"area_height_m":ar[1],"policy":policy,
                 "communication_architecture":arch,"channel_model":channel,
                 "radio_profile":radio_profile,"error":str(exc),"type":exc.__class__.__name__}
        return {"ok": False, "failure": failure, "run": run_index}


def _record_campaign_case(job, result):
    """Record a completed worker result and persist it incrementally."""
    with CAMPAIGN_LOCK:
        if result.get("ok"):
            row = dict(result["row"]); row["campaign_id"] = job["id"]
            job["run_rows"].append(row); job["completed_runs"] += 1
        else:
            job["failures"].append(dict(result["failure"])); job["failed_runs"] += 1
        job["completed_indices"].add(int(result["run"]))
    _write_campaign_outputs(job, final=False)
    _persist_campaign_state(job)


def _campaign_worker_sequential(job, cases):
    completed_indices = set(job.get("completed_indices", []))
    for case in cases:
        run_index = int(case["run"])
        if run_index in completed_indices:
            continue
        if job["cancel_event"].is_set():
            return "cancelled"
        while job["pause_event"].is_set():
            job["status"] = "paused"; _persist_campaign_state(job)
            if job["cancel_event"].wait(0.25):
                return "cancelled"
        job["status"] = "running"; job["current_run"] = run_index
        job["current_case"] = {k:case[k] for k in ("nodes","policy","channel_model","radio_profile","replicate","seed")}
        job["current_case"].update({"area": case["area"], "channel": case["channel_model"], "radio": case["radio_profile"]})
        _record_campaign_case(job, _run_campaign_case(case))
    return "completed"


def _campaign_worker_parallel(job, cases, workers):
    """Bounded process pool with adaptive submission pressure.

    Pool capacity is fixed, but the number of in-flight runs is adjusted from
    0..workers according to current RAM/CPU headroom. Existing runs are never
    killed; throttling only stops/reduces submission of new work.
    """
    pending_cases = [c for c in cases if int(c["run"]) not in set(job.get("completed_indices", []))]
    case_iter = iter(pending_cases); exhausted=False; futures={}; last_resource_check=0.0
    target=max(1,int(workers))
    with ProcessPoolExecutor(max_workers=int(workers), mp_context=mp.get_context("spawn")) as pool:
        def refresh_resources(force=False):
            nonlocal target,last_resource_check
            now=time.time()
            if not force and now-last_resource_check<1.0: return
            last_resource_check=now
            pf=resource_preflight(max_nodes=max([int(c.get('nodes',1)) for c in pending_cases] or [1]),requested_workers='auto',execution_mode='parallel_cpu')
            snap=pf['snapshot']; safe=max(1,min(int(workers),int(pf['safe_workers'])))
            # Hard runtime pressure: pause NEW submissions until resources recover.
            ram_pct=snap.get('ram_available_pct'); cpu=snap.get('cpu_percent')
            hard_ram=(ram_pct is not None and ram_pct<7) or (snap.get('ram_available_bytes') and snap['ram_available_bytes']<512*1024**2)
            if hard_ram: new_target=0
            elif ram_pct is not None and ram_pct<12: new_target=max(1,min(safe,2))
            elif cpu is not None and cpu>=92: new_target=max(1,min(safe,2))
            elif cpu is not None and cpu>=85: new_target=max(1,min(safe,4))
            else: new_target=safe
            if new_target!=target:
                job.setdefault('resource_adjustments',[]).append({'utc':datetime.now(timezone.utc).isoformat(),'from':target,'to':new_target,'cpu_percent':cpu,'ram_available_pct':ram_pct})
                job['resource_adjustments']=job['resource_adjustments'][-100:]
            target=new_target; job['active_worker_limit']=target; job['resource_state']=pf
            if target==0:
                job['message']='Esperando recursos del sistema antes de iniciar nuevas corridas.'
            else:
                job['message']=f'Ejecución adaptativa: hasta {target}/{workers} workers activos.'
            _persist_campaign_state(job)
        def submit_until_target():
            nonlocal exhausted
            refresh_resources()
            while target>0 and len(futures)<target and not exhausted and not job["pause_event"].is_set() and not job["cancel_event"].is_set():
                try: case=next(case_iter)
                except StopIteration: exhausted=True; break
                futures[pool.submit(_run_campaign_case,case)]=case
        refresh_resources(True); submit_until_target()
        while futures or not exhausted:
            refresh_resources()
            if job["cancel_event"].is_set():
                for fut in futures: fut.cancel()
            while job["pause_event"].is_set() and not job["cancel_event"].is_set():
                job["status"]="paused"; _persist_campaign_state(job); time.sleep(0.25); refresh_resources()
            if not futures:
                if exhausted or job['cancel_event'].is_set(): break
                submit_until_target(); time.sleep(0.15); continue
            done,_=wait(tuple(futures),timeout=0.25,return_when=FIRST_COMPLETED)
            for fut in done:
                case=futures.pop(fut)
                if fut.cancelled(): continue
                try: result=fut.result()
                except Exception as exc:
                    result={"ok":False,"run":int(case["run"]),"failure":{
                        "run":case["run"],"replicate":case["replicate"],"seed":case["seed"],"nodes":case["nodes"],
                        "area_width_m":case["area"][0],"area_height_m":case["area"][1],"policy":case["policy"],
                        "communication_architecture":case["communication_architecture"],"channel_model":case["channel_model"],
                        "radio_profile":case["radio_profile"],"error":str(exc),"type":exc.__class__.__name__}}
                job["status"]="running" if not job["pause_event"].is_set() else "paused"
                job["current_run"]=int(case["run"]); job["current_case"]={"nodes":case["nodes"],"area":case["area"],"policy":case["policy"],"channel":case["channel_model"],"radio":case["radio_profile"],"replicate":case["replicate"],"seed":case["seed"]}
                _record_campaign_case(job,result)
            if job["cancel_event"].is_set(): continue
            submit_until_target()
        if job["cancel_event"].is_set(): return "cancelled"
    return "completed"

def _campaign_worker(job):
    try:
        cases, perf = _campaign_cases(job["payload"])
        job["execution_mode"] = perf["execution_mode"]
        job["workers_setting"] = perf["workers_setting"]
        job["workers"] = perf["workers"]
        job["logical_cpus"] = perf["logical_cpus"]
        job["message"] = (f"Ejecutando en {perf['workers']} worker(s) CPU."
                          if perf["execution_mode"] == "parallel_cpu" else "Ejecución secuencial.")
        _persist_campaign_state(job)
        if perf["execution_mode"] == "parallel_cpu" and perf["workers"] > 1:
            outcome = _campaign_worker_parallel(job, cases, perf["workers"])
        else:
            outcome = _campaign_worker_sequential(job, cases)
        if outcome == "cancelled":
            job["status"] = "cancelled"; job["finished_utc"] = datetime.now(timezone.utc).isoformat()
            job["message"] = "Campaña cancelada por el usuario. Los resultados terminados quedaron guardados."
        else:
            job["status"] = "completed"; job["finished_utc"] = datetime.now(timezone.utc).isoformat()
            job["message"] = "Campaña completada."
        _write_campaign_outputs(job, final=True); _persist_campaign_state(job)
    except Exception as exc:
        job["status"]="error"; job["finished_utc"] = datetime.now(timezone.utc).isoformat()
        job["message"]=str(exc); job["error_type"]=exc.__class__.__name__
        try: _write_campaign_outputs(job, final=True); _persist_campaign_state(job)
        except Exception: pass

def start_campaign(payload, campaign_id=None, resume=False):
    (base_payload, matrix, node_counts, areas, policies, channels, radios, repetitions, seed_base, architecture_mode, plugins, total, execution_mode, workers_setting, workers, logical_cpus) = _campaign_validate(payload)
    campaign_id = campaign_id or _campaign_id()
    folder = CAMPAIGNS_ROOT / campaign_id; folder.mkdir(parents=True, exist_ok=True)
    existing_rows=[]; existing_failures=[]; completed_indices=set()
    if resume:
        def read_csv_rows(path):
            if not path.exists(): return []
            with path.open("r", newline="", encoding="utf-8-sig") as f: return list(csv.DictReader(f))
        existing_rows=read_csv_rows(folder/"campaign_results.csv"); existing_failures=read_csv_rows(folder/"failures.csv")
        for row in existing_rows+existing_failures:
            try: completed_indices.add(int(row.get("run",0)))
            except Exception: pass
    matrix_rows=[]
    for n in node_counts:
      for ar in areas:
       for policy in policies:
        for channel in channels:
         for radio_profile in radios:
          matrix_rows.append({"nodes":n,"area_width_m":ar[0],"area_height_m":ar[1],"policy":policy,"channel_model":channel,"radio_profile":radio_profile,"repetitions":repetitions})
    write_csv(folder/"experiment_matrix.csv",matrix_rows)
    campaign_config={"simulator_version":"0.42","created_utc":datetime.now(timezone.utc).isoformat(),"campaign_id":campaign_id,"matrix":matrix,"base_payload":base_payload,"total_requested_runs":total,"execution":{"mode":execution_mode,"workers_setting":workers_setting,"workers_effective":workers,"logical_cpus":logical_cpus,"resource_policy":"adaptive_safe_v1"}}
    _atomic_json(folder/"campaign_config.json",campaign_config)
    
    try:
        folder_display = str(folder.relative_to(ROOT))
    except ValueError:
        folder_display = str(folder)
    job={"id":campaign_id,"folder":folder_display,"folder_abs":str(folder),"status":"starting","message":"Preparando campaña...","requested_runs":total,"completed_runs":len(existing_rows),"failed_runs":len(existing_failures),"current_run":0,"current_case":None,"started_utc":datetime.now(timezone.utc).isoformat(),"started_epoch":time.time(),"finished_utc":None,"execution_mode":execution_mode,"workers_setting":workers_setting,"workers":workers,"logical_cpus":logical_cpus,"resource_state":resource_preflight(max(node_counts),workers,execution_mode),"active_worker_limit":workers,"resource_adjustments":[],"payload":payload,"run_rows":existing_rows,"failures":existing_failures,"completed_indices":completed_indices,"cancel_event":threading.Event(),"pause_event":threading.Event(),"files":{name:f"/api/campaign-download/{campaign_id}/{name}" for name in ["campaign_results.csv","aggregate_summary.csv","diagnostic_breakpoints.csv","experiment_matrix.csv","failures.csv","campaign_config.json"]},"zip_url":f"/api/campaign-download/{campaign_id}/zip"}
    with CAMPAIGN_LOCK: CAMPAIGN_JOBS[campaign_id]=job
    _persist_campaign_state(job)
    th=threading.Thread(target=_campaign_worker,args=(job,),daemon=True,name=f"campaign-{campaign_id}");job["thread"]=th;th.start()
    return _campaign_public(job)


def run_campaign(payload):
    """Backward-compatible synchronous helper used by tests/CLI code.

    The GUI uses start_campaign() asynchronously.
    """
    d = start_campaign(payload)
    with CAMPAIGN_LOCK:
        job = CAMPAIGN_JOBS.get(d["id"])
    if job and job.get("thread"):
        job["thread"].join()
    return campaign_status(d["id"])


def campaign_status(campaign_id):
    with CAMPAIGN_LOCK: job=CAMPAIGN_JOBS.get(campaign_id)
    if job: return _campaign_public(job)
    folder,state_path=_campaign_paths(campaign_id)
    if state_path.exists():
        d=json.loads(state_path.read_text(encoding="utf-8"))
        if d.get("status") in {"starting","running","paused","cancelling"}:
            d["status"]="interrupted"; d["message"]="La campaña fue interrumpida; puede reanudarse desde los resultados guardados."
        d["recoverable"] = d.get("status") not in {"completed"}
        return d
    raise ValueError("Unknown campaign id")


def control_campaign(campaign_id, action):
    with CAMPAIGN_LOCK: job=CAMPAIGN_JOBS.get(campaign_id)
    if action == "resume" and not job:
        folder,state_path=_campaign_paths(campaign_id)
        cfg_path=folder/"campaign_config.json"
        if not cfg_path.exists(): raise ValueError("Campaign cannot be resumed: configuration not found")
        cfg=json.loads(cfg_path.read_text(encoding="utf-8"))
        return start_campaign({"base_payload":cfg["base_payload"],"matrix":cfg["matrix"]}, campaign_id=campaign_id, resume=True)
    if not job: raise ValueError("Campaign is not active")
    if action=="cancel": job["cancel_event"].set(); job["status"]="cancelling"; job["message"]="Cancelación solicitada..."
    elif action=="pause": job["pause_event"].set(); job["status"]="paused"; job["message"]="Campaña pausada."
    elif action=="resume": job["pause_event"].clear(); job["status"]="running"; job["message"]="Campaña reanudada."
    else: raise ValueError("Unknown campaign action")
    _persist_campaign_state(job); return _campaign_public(job)

def generate_positions(node_count, area, seed):
    """Match Simulator's topology RNG exactly, then freeze positions as manual."""
    w, h = map(float, area)
    rng = random.Random(int(seed) + 100003)
    return [[rng.uniform(0, w), rng.uniform(0, h)] for _ in range(int(node_count))]




def _graph_summary(vertices, link_predicate):
    """Deterministic undirected graph diagnostics for a node set."""
    n = len(vertices)
    if n == 0:
        return {"mean_degree": 0.0, "min_degree": 0, "max_degree": 0, "link_density": 0.0, "edge_count": 0, "isolated_nodes": 0, "isolated_ids": [], "connected_components": 0, "largest_component_fraction": 0.0}
    adjacency = {i: [] for i in range(n)}
    for i in range(n):
        for j in range(i + 1, n):
            if bool(link_predicate(vertices[i], vertices[j])):
                adjacency[i].append(j); adjacency[j].append(i)
    degrees = [len(adjacency[i]) for i in range(n)]
    seen=set(); comps=[]
    for i in range(n):
        if i in seen: continue
        stack=[i]; comp=[]
        while stack:
            u=stack.pop()
            if u in seen: continue
            seen.add(u); comp.append(u); stack.extend(adjacency[u])
        comps.append(comp)
    edges = sum(degrees) / 2.0
    possible = n*(n-1)/2.0
    return {
        "mean_degree": sum(degrees)/n,
        "min_degree": min(degrees) if degrees else 0,
        "max_degree": max(degrees) if degrees else 0,
        "link_density": edges/possible if possible > 0 else 0.0,
        "edge_count": int(edges),
        "isolated_nodes": sum(d == 0 for d in degrees),
        "isolated_ids": [int(getattr(vertices[i], "node_id", i)) for i,d in enumerate(degrees) if d == 0],
        "connected_components": len(comps),
        "largest_component_fraction": max((len(c) for c in comps), default=0)/n,
    }


def scenario_health(sim):
    """Compare pure geometric topology with deterministic mean link-budget connectivity.

    This is observation only: it never changes the simulator connectivity mode.
    Geometric connectivity uses neighbor_radius_m. Radio connectivity uses mean
    RSSI >= receiver sensitivity (plus optional max_geometric_range_m).
    """
    nodes = sim.nodes
    radius = float(sim.radio_cfg.get("neighbor_radius_m", 38.0))
    cap = sim.radio_cfg.get("max_geometric_range_m")
    sensitivity = float(sim.radio.receiver_sensitivity_dbm())

    def geo(a,b):
        return math.dist(a.position,b.position) <= radius

    def radio(a,b):
        # Post-run nominal radio graph: uses each sender's CURRENT TX power.
        # This is intentionally sensitive to adaptive power-control decisions.
        d = math.dist(a.position,b.position)
        if cap is not None and d > float(cap):
            return False
        return sim.radio.link_margin_db(a,b) >= 0.0

    configured_tx_power_dbm = float(sim.radio_cfg.get("tx_power_dbm", 0.0))
    def radio_configured(a,b):
        # Baseline link-budget graph at the CONFIGURED TX power, independent of
        # any adaptive power changes that occurred during this simulation.
        d = math.dist(a.position,b.position)
        if cap is not None and d > float(cap):
            return False
        mean_rssi = configured_tx_power_dbm - sim.radio.channel.path_loss_db(a,b)
        return mean_rssi - sensitivity >= 0.0

    geo_s = _graph_summary(nodes, geo)
    radio_configured_s = _graph_summary(nodes, radio_configured)
    radio_s = _graph_summary(nodes, radio)

    # Sink reachability is multi-hop and uses deterministic link-budget links.
    all_vertices = list(nodes) + [sim.sink]
    sink_idx = len(nodes)
    adjacency = {i: [] for i in range(len(all_vertices))}
    for i in range(len(all_vertices)):
        for j in range(i+1, len(all_vertices)):
            if radio(all_vertices[i], all_vertices[j]):
                adjacency[i].append(j); adjacency[j].append(i)
    seen=set(); stack=[sink_idx]
    while stack:
        u=stack.pop()
        if u in seen: continue
        seen.add(u); stack.extend(adjacency[u])
    sink_ids = [int(nodes[i].node_id) for i in range(len(nodes)) if i in seen]
    sink_fraction = len(sink_ids)/len(nodes) if nodes else 0.0

    pair_dist=[]
    nearest=[]
    for i,a in enumerate(nodes):
        local=[]
        for j,b in enumerate(nodes):
            if i==j: continue
            d=math.dist(a.position,b.position); local.append(d)
            if j>i: pair_dist.append(d)
        if local: nearest.append(min(local))
    area_w, area_h = map(float, sim.cfg.get("area_m", [1.0,1.0]))
    area_m2=max(area_w*area_h,1e-12)
    node_density_m2=len(nodes)/area_m2

    warnings=[]
    if radio_s["isolated_nodes"]:
        warnings.append(f'{radio_s["isolated_nodes"]} nodo(s) aislado(s) según el link budget.')
    if radio_s["connected_components"] > 1:
        warnings.append(f'La red de radio está fragmentada en {radio_s["connected_components"]} componentes.')
    if sink_fraction < 1.0:
        warnings.append(f'Solo {len(sink_ids)}/{len(nodes)} nodos tienen una ruta nominal hacia el sink.')
    if geo_s["largest_component_fraction"] >= 0.9 and radio_s["largest_component_fraction"] < 0.6:
        warnings.append('La geometría es razonablemente conectada, pero el canal/link budget degrada fuertemente la conectividad.')
    if geo_s["largest_component_fraction"] < 0.5:
        warnings.append('La topología está muy dispersa para el radio geométrico seleccionado.')
    if not warnings:
        warnings.append('No se detectaron problemas estructurales importantes en el escenario nominal.')

    return {
        "geometric_radius_m": radius,
        "geometric": geo_s,
        "radio_configured": radio_configured_s,
        "radio": radio_s,
        "radio_degree_basis": "post_run_current_tx_power_link_budget",
        "radio_configured_degree_basis": "configured_tx_power_link_budget",
        "configured_tx_power_dbm": configured_tx_power_dbm,
        "sink_reachable_nodes": len(sink_ids),
        "sink_reachability_fraction": sink_fraction,
        "sink_unreachable_ids": [int(n.node_id) for n in nodes if int(n.node_id) not in set(sink_ids)],
        "area_m2": area_m2,
        "node_density_per_m2": node_density_m2,
        "node_density_per_km2": node_density_m2*1_000_000.0,
        "mean_nearest_neighbor_m": sum(nearest)/len(nearest) if nearest else None,
        "min_nearest_neighbor_m": min(nearest) if nearest else None,
        "max_nearest_neighbor_m": max(nearest) if nearest else None,
        "mean_pair_distance_m": sum(pair_dist)/len(pair_dist) if pair_dist else 0.0,
        "max_pair_distance_m": max(pair_dist) if pair_dist else 0.0,
        "receiver_sensitivity_dbm": sensitivity,
        "warnings": warnings,
    }



def algorithm_diagnostic(sim, metrics, health):
    """Heuristic interpretation layer; scientific metrics remain unchanged.

    Thresholds are configurable. The diagnostic helps locate weaknesses, but it
    is deliberately labeled heuristic and should not replace statistical tests.
    """
    dc=dict(sim.cfg.get("diagnostics") or {})
    f1_min=float(dc.get("f1_min",0.90)); dcr_min=float(dc.get("dcr_min",0.90))
    pdr_min=float(dc.get("link_pdr_min",0.80)); sink_min=float(dc.get("sink_reach_min",0.90))
    comp_min=float(dc.get("largest_component_min",0.90)); alive_min=float(dc.get("alive_fraction_min",0.90))
    fair_min=float(dc.get("energy_fairness_min",0.95))
    n=max(1,len(sim.nodes)); alive=float(metrics.get("battery_alive_nodes",n))/n
    radio=health.get("radio") or {}; sink=float(health.get("sink_reachability_fraction",0.0))
    comp=float(radio.get("largest_component_fraction",0.0)); pdr=metrics.get("link_pdr")
    fairness=metrics.get("energy_jain_fairness")
    diag=math.hypot(*map(float,sim.cfg.get("area_m",[1,1])))
    oe=metrics.get("mean_origin_error_m"); oe_frac=(float(oe)/diag) if oe is not None and diag>0 else None
    good_oe=float(dc.get("origin_error_fraction_good",0.05)); mod_oe=float(dc.get("origin_error_fraction_moderate",0.15))
    def grade(v,good,moderate=None,higher=True):
        if v is None: return "N/A"
        moderate = moderate if moderate is not None else good*0.8
        if higher:
            return "GOOD" if v>=good else ("MODERATE" if v>=moderate else "WEAK")
        return "GOOD" if v<=good else ("MODERATE" if v<=moderate else "WEAK")
    dimensions={
      "detection":grade(metrics.get("f1"),f1_min,max(0,f1_min-0.15)),
      "deadline_reliability":grade(metrics.get("dcr"),dcr_min,max(0,dcr_min-0.15)),
      "link_delivery":grade(pdr,pdr_min,max(0,pdr_min-0.15)),
      "connectivity":grade(min(sink,comp),min(sink_min,comp_min),max(0,min(sink_min,comp_min)-0.2)),
      "energy_fairness":grade(fairness,fair_min,max(0,fair_min-0.10)),
      "event_estimation":grade(oe_frac,good_oe,mod_oe,False) if sim.policy_name in ("dstep","dstep_payoff") else "N/A",
      "node_survival":grade(alive,alive_min,max(0,alive_min-0.2)),
    }
    strengths=[k for k,v in dimensions.items() if v=="GOOD"]
    weaknesses=[k for k,v in dimensions.items() if v=="WEAK"]
    functional=(float(metrics.get("f1",0))>=f1_min and sink>=sink_min and alive>=alive_min)
    return {
      "type":"heuristic", "dimensions":dimensions, "strengths":strengths, "weaknesses":weaknesses,
      "functional_at_end":functional,
      "functional_lifetime_observed_lower_bound_s":float(sim.duration) if functional else None,
      "functional_failure_present_by_end":not functional,
      "thresholds":dc,
      "origin_error_fraction_of_area_diagonal":oe_frac,
    }

def routing_snapshot(sim):
    """Deterministic shortest-hop routes from every node to the sink.

    This is a diagnostic view. Actual hop delivery remains stochastic.
    """
    edges = {}
    hop_counts = []
    unreachable = []
    direct = 0
    for node in sim.nodes:
        route = sim.nominal_route_to_sink(node)
        if not route:
            unreachable.append(int(node.node_id)); continue
        hops = len(route)-1
        hop_counts.append(hops)
        if hops == 1: direct += 1
        for a,b in zip(route, route[1:]):
            key=(int(a.node_id),int(b.node_id))
            if key not in edges:
                edges[key]={
                    "source":int(a.node_id), "target":int(b.node_id),
                    "distance_m":float(math.dist(a.position,b.position)),
                    "margin_db":float(sim.radio.link_margin_db(a,b)),
                }
    n=len(sim.nodes)
    return {
        "edges":list(edges.values()),
        "reachable_nodes":len(hop_counts),
        "unreachable_nodes":len(unreachable),
        "unreachable_ids":unreachable,
        "sink_reach_fraction":len(hop_counts)/n if n else 0.0,
        "direct_sink_fraction":direct/n if n else 0.0,
        "mean_hops_to_sink":sum(hop_counts)/len(hop_counts) if hop_counts else None,
        "max_hops_to_sink":max(hop_counts) if hop_counts else None,
    }


def simulation_payload(cfg, node_count, policy, seed, run_simulation=True):
    sim = TraceSimulator(cfg, node_count, policy, seed) if run_simulation else Simulator(cfg, node_count, policy, seed)
    # Build three explicit link views for the GUI.  This prevents the visual
    # graph from ambiguously mixing pure geometry with the selected radio mode.
    # Sink links use target=-1 so the browser can draw them separately.
    geometric_edges = []
    radio_edges = []
    simulation_edges = []
    radius = float(sim.radio_cfg.get("neighbor_radius_m", 38.0))
    vertices = list(sim.nodes) + [sim.sink]
    for i, a in enumerate(vertices):
        for j in range(i + 1, len(vertices)):
            b = vertices[j]
            source = int(a.node_id) if a is not sim.sink else -1
            target = int(b.node_id) if b is not sim.sink else -1
            d = math.dist(a.position, b.position)
            margin = float(sim.radio.link_margin_db(a, b))
            item = {
                "source": source, "target": target,
                "margin_db": round(margin, 3),
                "distance_m": round(d, 3),
            }
            if d <= radius:
                geometric_edges.append(dict(item))
            cap = sim.radio_cfg.get("max_geometric_range_m")
            radio_ok = (cap is None or d <= float(cap)) and margin >= 0.0
            if radio_ok:
                radio_edges.append(dict(item))
            if sim.radio.nominal_link_available(a, b):
                simulation_edges.append(dict(item))

    initial_edges = simulation_edges

    topology = sim.topology_snapshot()
    if run_simulation:
        sim.run()
        if isinstance(sim, TraceSimulator):
            sim.finalize_mobility_trace()
        metrics = summarize(sim)
    else:
        metrics = None

    nodes = []
    for n in sim.nodes:
        item = {
            "id": n.node_id,
            "x": round(float(n.position[0]), 6),
            "y": round(float(n.position[1]), 6),
            "tx_power_dbm": round(float(n.tx_power_dbm), 3),
        }
        if run_simulation:
            item.update({
                "detected": bool(n.detected),
                "confirmed": bool(getattr(n, "confirmed", False)),
                "tx_count": int(n.tx_count),
                "rx_count": int(n.rx_count),
                "energy_mj": round(float(n.total_energy), 6),
                "alive": bool(getattr(n, "alive", True)),
                "death_time_s": getattr(n, "death_time_s", None),
                "battery_remaining_mj": round(float(sim.battery.remaining_mj(n)), 6) if sim.battery.remaining_mj(n) is not None else None,
                "battery_remaining_pct": round(float(sim.battery.remaining_pct(n)), 6) if sim.battery.remaining_pct(n) is not None else None,
                "estimated_lifetime_s": round(float(sim.battery.estimated_lifetime_s(n, sim.duration)), 6) if sim.battery.estimated_lifetime_s(n, sim.duration) is not None else None,
                "first_detection_time": n.first_detection_time,
                "first_alert_time": n.first_alert_time,
            })
        nodes.append(item)

    route_info = routing_snapshot(sim)
    health = scenario_health(sim)
    health["routing"] = {k:v for k,v in route_info.items() if k != "edges"}
    health["communication_architecture"] = sim.communication_architecture
    diagnostic = algorithm_diagnostic(sim, metrics, health) if run_simulation else None
    result = {
        "metrics": metrics,
        "topology": topology,
        "nodes": nodes,
        "edges": initial_edges,
        "geometric_edges": geometric_edges,
        "radio_edges": radio_edges,
        "simulation_edges": simulation_edges,
        "routing_edges": route_info["edges"],
        "routing_summary": {k:v for k,v in route_info.items() if k != "edges"},
        "sink": {"x": sim.sink.position[0], "y": sim.sink.position[1]},
        "effective_radio": sim.radio_cfg,
        "scenario_health": health,
        "algorithm_diagnostic": diagnostic,
        "mobility": sim.mobility.summary(),
        "battery": sim.battery.summary(sim.duration),
        "ground_truth": dict(getattr(sim, "event_ground_truth", {})),
    }
    if run_simulation:
        result["trace"] = sim.trace
        result["mobility_trace"] = sim.mobility_trace
        result["packet_trace"] = sim.packet_trace
        last_mobility_t = max((float(e.get("t", 0.0)) for e in sim.mobility_trace), default=0.0)
        last_packet_t = max((float(e.get("t", 0.0)) for e in sim.packet_trace), default=None)
        result["trace_meta"] = {
            "events": len(sim.trace),
            "truncated": len(sim.trace) >= TraceSimulator.TRACE_LIMIT,
            "duration_s": float(sim.duration),
            "mobility_events": len(sim.mobility_trace),
            "mobility_last_time_s": last_mobility_t,
            "mobility_complete": (
                str((sim.cfg.get("mobility") or {}).get("model", "static")).lower() == "static"
                or last_mobility_t >= float(sim.duration) - 1e-9
            ),
            "mobility_trace_interval_s": float(sim.mobility_trace_interval_s),
            "packet_playback_events": len(sim.packet_trace),
            "packet_total_attempts": int(sim.packet_trace_total_attempts),
            "packet_playback_dropped": int(sim.packet_trace_dropped),
            "packet_playback_bucket_s": float(sim.packet_trace_bucket_s),
            "packet_playback_complete_coverage": True,
            "packet_last_time_s": last_packet_t,
        }
    return result


class TraceSimulator(Simulator):
    """Observation-only simulator wrapper used by the GUI playback.

    Observation-only wrapper. We record resolved packet receptions and public
    simulator callbacks without changing the scientific decisions or metrics.
    """
    TRACE_LIMIT = 60000

    MOBILITY_TRACE_TARGET = 120000
    PACKET_TRACE_TARGET = 120000
    PACKET_TRACE_BUCKETS = 6000

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.trace = []
        self.mobility_trace = []
        self.packet_trace = []
        self.packet_trace_total_attempts = 0
        self.packet_trace_dropped = 0
        self._packet_bucket_counts = {}
        self._mobility_last_t = {}
        mcfg = self.cfg.get("mobility", {}) or {}
        base_interval = max(0.01, float(mcfg.get("update_interval_s", 1.0)))
        mobile_fraction = max(0.0, min(1.0, float(mcfg.get("mobile_fraction", 1.0))))
        mobile_nodes = max(1, int(math.ceil(len(self.nodes) * mobile_fraction)))
        # Keep the playback complete without allowing very long runs to create
        # unbounded browser payloads. At normal 50-node/600-s/0.5-s settings,
        # no decimation occurs (60,000 movement samples).
        budget_interval = (float(self.duration) * mobile_nodes / self.MOBILITY_TRACE_TARGET)
        self.mobility_trace_interval_s = max(base_interval, budget_interval)
        # Packet playback is sampled independently of the bounded scientific
        # trace. Time buckets guarantee temporal coverage through the entire run
        # instead of filling a global list early in event-heavy scenarios.
        self.packet_trace_bucket_s = max(0.05, float(self.duration) / self.PACKET_TRACE_BUCKETS)
        self.packet_trace_per_bucket = max(1, int(math.ceil(self.PACKET_TRACE_TARGET / self.PACKET_TRACE_BUCKETS)))
        original_resolve = self.radio.resolve_receive

        def traced_resolve(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
            result = original_resolve(
                tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=commit_payload
            )
            success, delay, rssi, reason = result
            meta = self.radio.last_resolution_meta.get((tx.tx_id, receiver.node_id), {})
            packet_item = {
                "t": round(float(self.engine.time), 6), "kind": "packet",
                "source": int(tx.sender.node_id), "target": int(receiver.node_id),
                "success": bool(success), "delay_s": float(delay), "rssi_dbm": float(rssi),
                "reason": str(reason), "message_type": str(payload.get("type", "data")),
                "confidence": float(payload.get("confidence", 0.0)),
                "sinr_db": meta.get("sinr_db"), "interferers": int(meta.get("interferers", 0)),
            }
            self._trace_packet_playback(packet_item)
            self._trace(
                "packet", source=packet_item["source"], target=packet_item["target"],
                success=packet_item["success"], delay_s=packet_item["delay_s"],
                rssi_dbm=packet_item["rssi_dbm"], reason=packet_item["reason"],
                message_type=packet_item["message_type"], confidence=packet_item["confidence"],
                sinr_db=packet_item["sinr_db"], interferers=packet_item["interferers"],
            )
            return result

        self.radio.resolve_receive = traced_resolve

    def _trace_packet_playback(self, item):
        self.packet_trace_total_attempts += 1
        bucket = int(float(item.get("t", 0.0)) / self.packet_trace_bucket_s)
        used = self._packet_bucket_counts.get(bucket, 0)
        if used < self.packet_trace_per_bucket:
            self.packet_trace.append(item)
            self._packet_bucket_counts[bucket] = used + 1
        else:
            self.packet_trace_dropped += 1

    def _trace(self, kind, **data):
        if len(self.trace) >= self.TRACE_LIMIT:
            return
        item = {"t": round(float(self.engine.time), 6), "kind": kind}
        item.update(data)
        self.trace.append(item)

    def sensor_value(self, node):
        value = super().sensor_value(node)
        signal = self.world.intensity(node.position, self.engine.time)
        self._trace("sample", node=int(node.node_id), value=round(float(value), 6), signal=round(float(signal), 6))
        return value

    def process_policy(self, node, value, confidence):
        old_state = str(node.state)
        super().process_policy(node, value, confidence)
        self._trace(
            "decision", node=int(node.node_id), state=str(node.state), previous_state=old_state,
            confidence=round(float(getattr(node, "local_confidence", confidence)), 6),
            belief=round(float(getattr(node, "global_belief", 0.0)), 6),
            detected=bool(node.detected), confirmed=bool(getattr(node, "confirmed", False)),
            energy_mj=round(float(node.total_energy), 6), tx_count=int(node.tx_count), rx_count=int(node.rx_count),
            tx_power_dbm=round(float(node.tx_power_dbm), 3),
            first_detection_time=node.first_detection_time,
            first_confirmation_time=node.first_confirmation_time,
            est_origin=list(node.est_origin) if node.est_origin is not None else None,
            est_t0=node.est_t0,
            est_speed=node.est_speed,
            est_direction=list(node.est_direction) if node.est_direction is not None else None,
            est_eta=node.est_eta,
            estimate_points=int(node.estimate_points),
        )

    def on_node_moved(self, node, old_position, new_position, distance_m):
        # Mobility playback is stored separately from the bounded scientific
        # event trace. This prevents packet/sample traffic from freezing node
        # motion in the GUI when TRACE_LIMIT is reached.
        nid = int(node.node_id)
        now = float(self.engine.time)
        last = self._mobility_last_t.get(nid)
        if last is None or now - last + 1e-9 >= self.mobility_trace_interval_s:
            self.mobility_trace.append({
                "t": round(now, 6), "kind": "move", "node": nid,
                "x": round(float(new_position[0]), 6), "y": round(float(new_position[1]), 6),
                "old_x": round(float(old_position[0]), 6), "old_y": round(float(old_position[1]), 6),
                "distance_m": round(float(distance_m), 6),
            })
            self._mobility_last_t[nid] = now

    def finalize_mobility_trace(self):
        """Ensure every mobile node has a final playback point at simulation end."""
        if str((self.cfg.get("mobility") or {}).get("model", "static")).lower() == "static":
            return
        t = round(float(self.duration), 6)
        last_by_node = {int(e["node"]): e for e in self.mobility_trace}
        for node in self.nodes:
            nid = int(node.node_id)
            last = last_by_node.get(nid)
            x, y = map(float, node.position)
            if last is None or float(last.get("t", -1)) < float(self.duration) - 1e-9:
                self.mobility_trace.append({
                    "t": t, "kind": "move", "node": nid,
                    "x": round(x, 6), "y": round(y, 6),
                    "old_x": round(x, 6), "old_y": round(y, 6),
                    "distance_m": 0.0, "final_snapshot": True,
                })
        self.mobility_trace.sort(key=lambda e: (float(e.get("t", 0)), int(e.get("node", -1))))

    def receive(self, receiver, payload):
        super().receive(receiver, payload)
        self._trace(
            "receive", node=int(receiver.node_id), message_type=str(payload.get("type", "data")),
            state=str(receiver.state), rx_count=int(receiver.rx_count), energy_mj=round(float(receiver.total_energy), 6),
        )

    def sink_receive(self, sender, payload):
        super().sink_receive(sender, payload)
        self._trace(
            "sink_receive", source=int(sender.node_id), message_type=str(payload.get("type", "data")),
            confidence=round(float(payload.get("confidence", 0.0)), 6),
        )


class Handler(BaseHTTPRequestHandler):
    server_version = "WSNEdgeAISim/0.42"

    def log_message(self, fmt, *args):
        print(f"[GUI] {self.address_string()} - {fmt % args}")

    def _json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/config":
            cfg = load_base_config()
            return self._json({
                "config": cfg,
                "channel_models": ["free_space", "log_distance", "log_normal", "two_ray", "rayleigh", "rician", "nakagami", "esp32_test002"],
                "environment_profiles": ["custom", "open_field", "forest", "urban", "industrial", "open_water"],
                "radio_profiles": RADIO_PROFILES,
                "policies": cfg.get("policies", []),
                "plugins": discover_plugins(),
                "algorithm_api_version": "1.0",
                "version": "0.42",
                "logical_cpus": max(1, int(os.cpu_count() or 1)),
                "auto_workers": max(1, min(8, (int(os.cpu_count() or 1) - 2) if int(os.cpu_count() or 1) > 2 else 1)),
            })
        if parsed.path == "/api/configurations":
            return self._json({"ok": True, "configurations": list_saved_configurations()})
        if parsed.path == "/api/resources":
            return self._json({"ok": True, "resources": resource_snapshot()})
        if parsed.path == "/api/health":
            return self._json({"ok": True, "version": "0.42", "algorithm_api_version": "1.0", "logical_cpus": max(1, int(os.cpu_count() or 1))})
        if parsed.path.startswith("/api/campaign-status/"):
            campaign_id = parsed.path.rsplit("/",1)[-1]
            try: return self._json(campaign_status(campaign_id))
            except Exception as exc: return self._json({"error":str(exc),"type":exc.__class__.__name__},status=404)
        if parsed.path.startswith("/api/campaign-download/"):
            parts = [x for x in parsed.path.split("/") if x]
            if len(parts) not in (3,4): self.send_error(404); return
            campaign_id = parts[2]
            if not campaign_id.replace("_", "").replace("-", "").isalnum(): self.send_error(400); return
            if len(parts) == 3 or parts[3] == "zip":
                fp = CAMPAIGNS_ROOT / f"{campaign_id}.zip"; download_name = fp.name
            else:
                allowed = {"campaign_results.csv","aggregate_summary.csv","diagnostic_breakpoints.csv","experiment_matrix.csv","failures.csv","campaign_config.json"}
                name = parts[3]
                if name not in allowed: self.send_error(404); return
                fp = CAMPAIGNS_ROOT / campaign_id / name; download_name = name
            if not fp.exists(): self.send_error(404); return
            data = fp.read_bytes(); mime, _ = mimetypes.guess_type(str(fp))
            self.send_response(200); self.send_header("Content-Type", mime or "application/octet-stream")
            self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
            self.send_header("Content-Length", str(len(data))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data); return
        if parsed.path.startswith("/api/download/"):
            parts = [x for x in parsed.path.split("/") if x]
            if len(parts) not in (3,4): self.send_error(404); return
            experiment_id = parts[2]
            if not experiment_id.replace("_", "").replace("-", "").isalnum(): self.send_error(400); return
            if len(parts) == 3 or parts[3] == "zip":
                fp = EXPERIMENTS_ROOT / f"{experiment_id}.zip"
                download_name = fp.name
            else:
                allowed = {"summary.csv","event_trace.csv","packets.csv","node_states.csv","estimates.csv","nodes_final.csv","config.json","metadata.json"}
                name = parts[3]
                if name not in allowed: self.send_error(404); return
                fp = EXPERIMENTS_ROOT / experiment_id / name; download_name = name
            if not fp.exists(): self.send_error(404); return
            data = fp.read_bytes(); mime, _ = mimetypes.guess_type(str(fp))
            self.send_response(200); self.send_header("Content-Type", mime or "application/octet-stream")
            self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
            self.send_header("Content-Length", str(len(data))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data); return

        path = unquote(parsed.path)
        if path == "/":
            path = "/index.html"
        file_path = (GUI_ROOT / path.lstrip("/")).resolve()
        if GUI_ROOT not in file_path.parents and file_path != GUI_ROOT:
            self.send_error(403)
            return
        if not file_path.exists() or not file_path.is_file():
            self.send_error(404)
            return
        mime, _ = mimetypes.guess_type(str(file_path))
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", (mime or "application/octet-stream") + ("; charset=utf-8" if (mime or "").startswith("text/") else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        try:
            payload = self._read_json()
            if self.path == "/api/configurations/save":
                snapshot = payload.get("snapshot")
                if not isinstance(snapshot, dict):
                    raise ValueError("La configuración a guardar no es válida")
                return self._json(save_named_configuration(payload.get("name"), snapshot, bool(payload.get("overwrite", False))))
            if self.path == "/api/configurations/load":
                return self._json({"ok": True, "record": load_named_configuration(payload.get("id"))})
            if self.path == "/api/configurations/delete":
                return self._json(delete_named_configuration(payload.get("id")))
            if self.path == "/api/plugins/upload":
                filename = str(payload.get("filename", "")).strip()
                source = str(payload.get("source", ""))
                if not filename.lower().endswith(".py"):
                    raise ValueError("The algorithm file must have .py extension")
                safe_name = Path(filename).name
                if safe_name != filename or safe_name.startswith("_"):
                    raise ValueError("Invalid plugin filename")
                if not source.strip():
                    raise ValueError("Plugin source is empty")
                USER_PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
                target = USER_PLUGIN_DIR / safe_name
                target.write_text(source, encoding="utf-8")
                try:
                    validate_plugin_file(target)
                except Exception:
                    target.unlink(missing_ok=True)
                    raise
                return self._json({"ok": True, "plugins": discover_plugins()})
            if self.path == "/api/generate":
                cfg, node_count, policy, seed = build_config(payload)
                positions = generate_positions(node_count, cfg["area_m"], seed)
                cfg.setdefault("topology", {})["placement"] = "manual"
                cfg["topology"]["manual_positions"] = positions
                result = simulation_payload(cfg, node_count, policy, seed, run_simulation=False)
                result["positions"] = positions
                return self._json(result)
            if self.path == "/api/preview":
                cfg, node_count, policy, seed = build_config(payload)
                return self._json(simulation_payload(cfg, node_count, policy, seed, run_simulation=False))
            if self.path == "/api/simulate":
                cfg, node_count, policy, seed = build_config(payload)
                result = simulation_payload(cfg, node_count, policy, seed, run_simulation=True)
                result["effective_config"] = cfg
                experiment_id, folder, zip_path = export_experiment(result, cfg, node_count, policy, seed)
                result["experiment"] = {
                    "id": experiment_id,
                    "folder": str(folder.relative_to(ROOT)),
                    "zip_url": f"/api/download/{experiment_id}/zip",
                    "files": {name: f"/api/download/{experiment_id}/{name}" for name in ["summary.csv","event_trace.csv","packets.csv","node_states.csv","estimates.csv","nodes_final.csv","config.json","metadata.json","ground_truth.json","algorithm_diagnostic.json"]},
                }
                return self._json(result)
            if self.path == "/api/resource-preflight":
                matrix=payload.get("matrix") or {}
                nodes=[int(x) for x in (matrix.get("node_counts") or [20])]
                pf=resource_preflight(max(nodes), matrix.get("workers","auto"), matrix.get("execution_mode","parallel_cpu"))
                return self._json({"ok":True,"preflight":pf})
            if self.path == "/api/campaign-run":
                return self._json(start_campaign(payload), status=202)
            if self.path.startswith("/api/campaign-control/"):
                campaign_id = self.path.rsplit("/",1)[-1]
                return self._json(control_campaign(campaign_id, str(payload.get("action",""))))
            if self.path == "/api/export-config":
                cfg, node_count, policy, seed = build_config(payload)
                return self._json(cfg)
            self.send_error(404)
        except Exception as exc:
            self._json({"error": str(exc), "type": exc.__class__.__name__}, status=400)


def main():
    parser = argparse.ArgumentParser(description="WSN Edge-AI Simulator v0.42 GUI")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    # A previous GUI instance may still be using the default port.
    # Instead of crashing (which leaves the browser talking to the stale server),
    # automatically try the next local ports.
    server = None
    chosen_port = args.port
    last_error = None
    for candidate in range(args.port, args.port + 50):
        try:
            server = ThreadingHTTPServer((args.host, candidate), Handler)
            chosen_port = candidate
            break
        except OSError as exc:
            last_error = exc
    if server is None:
        raise RuntimeError(f"Could not find a free local port starting at {args.port}: {last_error}")

    url = f"http://{args.host}:{chosen_port}/"
    print(f"WSN Edge-AI Simulator v0.42 GUI: {url}")
    if chosen_port != args.port:
        print(f"Port {args.port} was already in use; switched automatically to {chosen_port}.")
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
