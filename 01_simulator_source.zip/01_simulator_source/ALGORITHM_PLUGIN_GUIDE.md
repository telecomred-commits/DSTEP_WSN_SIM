# Algorithm Plugin API v1.0

The simulator can load researcher-provided Python algorithms without editing the engine.

## Minimal plugin

```python
from wsn_sim.plugins.api import AlgorithmPlugin

class MyAlgorithm(AlgorithmPlugin):
    INFO = {
        "name": "My Algorithm",
        "version": "1.0",
        "api_version": "1.0",
        "compatible_architectures": ["distributed", "direct_to_sink", "multi_hop_to_sink"],
    }
    uses_local_inference = False

    def on_sample(self, ctx, value, confidence):
        if value >= 0.6:
            ctx.send({"type": "my_event", "confidence": confidence, "time": ctx.time})

ALGORITHM_CLASS = MyAlgorithm
```

Load the `.py` file from **Algoritmo y arquitectura → Algoritmo Python del usuario → Cargar .py**.
The file is validated and stored locally in `wsn_sim/plugins/user/`.

## Stable context API

- `ctx.time`
- `ctx.node_id`
- `ctx.position`
- `ctx.energy_mj`
- `ctx.tx_count`, `ctx.rx_count`
- `ctx.neighbors()`
- `ctx.send(message)` — uses the selected communication architecture
- `ctx.broadcast(message)`
- `ctx.send_to_sink(message)`
- `ctx.route_to_sink(message)`
- `ctx.set_tx_power(dbm)`
- `ctx.mark_detected()` — declares the plugin's own detection
- `ctx.mark_alert()` — declares that the plugin raised/acted on an alert

Optional callback:

```python
def on_receive(self, ctx, message):
    ...
```

## Parameters

A plugin can publish GUI parameters:

```python
PARAMETERS = {
    "threshold": {"type": "float", "default": 0.55, "min": 0, "max": 1},
    "confirmations": {"type": "int", "default": 2}
}
```

Their values are available in `self.parameters` and are exported with the experiment configuration.

## Included example

`wsn_sim/plugins/user/delta_event.py` is intentionally short. It reports an event only when the sample is above a threshold and differs by at least `min_delta` from the last value sent by that node.
