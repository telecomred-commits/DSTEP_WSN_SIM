import argparse,copy,csv,json,os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize
ROOT=Path(__file__).parent;BASE=json.loads((ROOT/'config.json').read_text());OUT=ROOT/'results_v050_full_holdout';OUT.mkdir(exist_ok=True)
POL=['periodic','event_driven','send_on_delta','teen_like','distributed_edge','voi_baseline','dstep','dstep_payoff'];NS=[20,50,100];BS=5000000
EV_INDEX={'deterministic':0,'physical_pulse':1,'absent':2}
def w(t):
 event,p,n,r,seed=t;c=copy.deepcopy(BASE);c['event']['model']=event;s=Simulator(c,n,p,seed);s.run();m=summarize(s);m.update({'event_model':event,'run':r,'seed':seed});return m
def write(path,rows):
 keys=[];seen=set()
 for x in rows:
  for k in x:
   if k not in seen:seen.add(k);keys.append(k)
 with open(path,'w',newline='',encoding='utf-8') as f:ww=csv.DictWriter(f,fieldnames=keys);ww.writeheader();ww.writerows(rows)
ap=argparse.ArgumentParser();ap.add_argument('--event',required=True,choices=list(EV_INDEX));ap.add_argument('--start',type=int,required=True);ap.add_argument('--stop',type=int,required=True);a=ap.parse_args()
tasks=[(a.event,p,n,r,BS+EV_INDEX[a.event]*100000+n*1000+r) for p in POL for n in NS for r in range(a.start,a.stop)]
with ProcessPoolExecutor(max_workers=min(5,os.cpu_count() or 1)) as ex:rows=list(ex.map(w,tasks,chunksize=1))
path=OUT/f'{a.event}_raw_{a.start:02d}_{a.stop-1:02d}.csv';write(path,rows);print(path)
