"""Held-out validation for the ESP32 TEST002 calibrated DATA channel (v0.41).

Runs 1-2 at each distance were used for calibration.  Run 3 is held out.
This script exercises the *implemented* calibrated channel and logistic decoder
without MAC contention so it tests the external DATA RSSI/PDR layer only.

It intentionally does not claim that the simulator's ACK/retry timing is a
complete ESP-NOW/802.11 implementation.  The real TEST002 ACK statistics remain
in calibration/esp32_test002/esp32_test002_runs.csv for separate analysis.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path

from wsn_sim.radio.model import RadioModel
from wsn_sim.radio.profiles import RADIO_PROFILES

ROOT = Path(__file__).resolve().parent
CAL = ROOT / "calibration" / "esp32_test002"
OUT = ROOT / "results_esp32_test002_validation"


class Node:
    def __init__(self, node_id: int, x: float, tx_power_dbm: float = 20.0):
        self.node_id = int(node_id)
        self.position = (float(x), 0.0)
        self.tx_power_dbm = float(tx_power_dbm)


def percentile(values, q):
    xs = sorted(float(v) for v in values)
    if not xs:
        return None
    if len(xs) == 1:
        return xs[0]
    pos = (len(xs) - 1) * float(q)
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return xs[lo]
    f = pos - lo
    return xs[lo] * (1.0 - f) + xs[hi] * f


def heldout_rows():
    out = {}
    with (CAL / "esp32_test002_runs.csv").open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if int(row["run"]) == 3:
                out[int(float(row["distance_m"]))] = row
    return out


def simulate_realization(distance_m: float, packets: int, seed: int):
    cfg = dict(RADIO_PROFILES["esp_now_test002_real"]["radio"])
    radio = RadioModel(cfg, random.Random(seed))
    tx = Node(0, 0.0, cfg["tx_power_dbm"])
    rx = Node(1, distance_m, cfg["tx_power_dbm"])
    success_rssi = []
    for _ in range(int(packets)):
        rssi = radio.instantaneous_rssi(tx, rx)
        ok = radio.rng.random() < radio.success_probability(rssi)
        if ok:
            success_rssi.append(rssi)
    return len(success_rssi) / float(packets), (sum(success_rssi) / len(success_rssi) if success_rssi else None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--realizations", type=int, default=500)
    ap.add_argument("--packets", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=20260921)
    args = ap.parse_args()

    if args.realizations < 50:
        raise SystemExit("Use at least 50 realizations for a meaningful predictive interval.")
    if args.packets < 1:
        raise SystemExit("packets must be >= 1")

    held = heldout_rows()
    rows = []
    for d in (1, 10, 20, 25, 30):
        pdrs, rssis = [], []
        for rep in range(args.realizations):
            pdr, rssi = simulate_realization(d, args.packets, args.seed + d * 100_000 + rep)
            pdrs.append(pdr)
            if rssi is not None:
                rssis.append(rssi)
        obs = held[d]
        p_lo, p_hi = percentile(pdrs, 0.025), percentile(pdrs, 0.975)
        r_lo, r_hi = percentile(rssis, 0.025), percentile(rssis, 0.975)
        obs_p = float(obs["data_pdr"])
        obs_r = float(obs["rssi_data_mean_dbm"])
        rows.append({
            "distance_m": d,
            "heldout_run": 3,
            "observed_data_pdr": obs_p,
            "predictive_pdr_median": percentile(pdrs, 0.5),
            "predictive_pdr_2p5": p_lo,
            "predictive_pdr_97p5": p_hi,
            "pdr_within_95pi": p_lo <= obs_p <= p_hi,
            "observed_success_rssi_mean_dbm": obs_r,
            "predictive_success_rssi_median_dbm": percentile(rssis, 0.5),
            "predictive_success_rssi_2p5_dbm": r_lo,
            "predictive_success_rssi_97p5_dbm": r_hi,
            "rssi_mean_within_95pi": r_lo <= obs_r <= r_hi,
        })

    OUT.mkdir(exist_ok=True)
    csv_path = OUT / "heldout_validation_simulated.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)

    all_pdr = all(r["pdr_within_95pi"] for r in rows)
    all_rssi = all(r["rssi_mean_within_95pi"] for r in rows)
    report = [
        "ESP32 TEST002 v0.41 HELD-OUT VALIDATION",
        f"realizations_per_distance={args.realizations}",
        f"packets_per_realization={args.packets}",
        "calibration_split=Runs 1-2",
        "heldout_split=Run 3",
        f"all_heldout_PDR_inside_95PI={all_pdr}",
        f"all_heldout_success_RSSI_means_inside_95PI={all_rssi}",
        "",
    ]
    for r in rows:
        report.append(
            f"d={r['distance_m']:>2}m  PDR obs={r['observed_data_pdr']:.3f} "
            f"PI95=[{r['predictive_pdr_2p5']:.3f},{r['predictive_pdr_97p5']:.3f}]  "
            f"RSSI obs={r['observed_success_rssi_mean_dbm']:.2f} dBm "
            f"PI95=[{r['predictive_success_rssi_2p5_dbm']:.2f},{r['predictive_success_rssi_97p5_dbm']:.2f}]"
        )
    report += [
        "",
        "Scope: DATA RSSI/PDR only. The simulator MAC/ACK engine remains a compact abstraction,",
        "and TEST002 application-ACK timing is not represented as an exact ESP-NOW/802.11 MAC model.",
    ]
    (OUT / "V041_ESP32_TEST002_VALIDATION_REPORT.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    (OUT / "validation_metadata.json").write_text(json.dumps({
        "simulator_version": "0.41.0",
        "profile": "esp_now_test002_real",
        "realizations_per_distance": args.realizations,
        "packets_per_realization": args.packets,
        "seed": args.seed,
        "all_pdr_inside_95pi": all_pdr,
        "all_rssi_means_inside_95pi": all_rssi,
    }, indent=2), encoding="utf-8")

    print("\n".join(report))
    if not (all_pdr and all_rssi):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
