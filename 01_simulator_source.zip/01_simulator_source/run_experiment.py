import csv
import json
from pathlib import Path
from statistics import mean

from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize

ROOT = Path(__file__).parent

with open(ROOT / "config.json", "r", encoding="utf-8") as f:
    cfg = json.load(f)

raw_rows = []

for n_nodes in cfg["node_counts"]:
    for policy in cfg["policies"]:
        for run in range(cfg.get("monte_carlo_runs", 1)):
            # SAME topology / stochastic scenario for every policy at fixed N and run.
            seed = cfg["seed"] + n_nodes * 1000 + run
            sim = Simulator(cfg, n_nodes, policy, seed)
            sim.run()
            row = summarize(sim)
            row["run"] = run
            row["seed"] = seed
            raw_rows.append(row)

out_dir = ROOT / "results"
out_dir.mkdir(exist_ok=True)

raw_file = out_dir / "monte_carlo_raw.csv"
with open(raw_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=raw_rows[0].keys())
    writer.writeheader()
    writer.writerows(raw_rows)

groups = {}
for row in raw_rows:
    groups.setdefault((row["policy"], row["nodes"]), []).append(row)

numeric_fields = [
    "tx_packets", "rx_packets", "bytes_tx", "energy_mj",
    "energy_sense_mj", "energy_preprocess_mj", "energy_infer_mj",
    "energy_consensus_mj", "energy_estimate_mj", "energy_prediction_mj",
    "energy_tx_mj", "energy_rx_mj", "energy_idle_mj",
    "precision", "recall", "f1", "dcr",
    "mean_detection_delay_s", "pre_event_local_detections",
    "mean_confirmation_delay_s", "mean_alert_delay_s", "mean_lead_time_s",
    "mean_origin_error_m", "mean_speed_error_m_s", "mean_eta_error_s",
    "collisions", "channel_losses", "suppressed_tx",
    "mac_cca_busy", "mac_backoff_events", "mac_access_drops", "mac_queue_drops", "mean_mac_queue_delay_s", "mac_max_queue_depth", "mac_retry_tx_frames", "mac_ack_tx_frames", "mac_ack_rx_frames", "mac_retry_exhausted", "mac_unicast_delivery_ratio", "mac_reliable_delivery_ratio", "physical_tx_frames", "interfered_receptions", "mean_sinr_db"
]

summary_rows = []
for (policy, nodes), rows in groups.items():
    out = {"policy": policy, "nodes": nodes, "runs": len(rows)}
    for field in numeric_fields:
        vals = [r[field] for r in rows if r[field] is not None]
        out[field] = round(mean(vals), 4) if vals else None
    summary_rows.append(out)

# Comparative metrics using event_driven as communication baseline.
by_key = {(r["policy"], r["nodes"]): r for r in summary_rows}
for row in summary_rows:
    baseline = by_key.get(("event_driven", row["nodes"]))
    if baseline:
        row["tx_reduction_vs_event"] = round(
            1.0 - row["tx_packets"] / baseline["tx_packets"], 4
        ) if baseline["tx_packets"] else None

        row["energy_reduction_vs_event"] = round(
            1.0 - row["energy_mj"] / baseline["energy_mj"], 4
        ) if baseline["energy_mj"] else None

    if row["policy"] in ("dstep", "dstep_payoff") and baseline:
        ai_extra = (
            row["energy_infer_mj"]
            + row["energy_consensus_mj"]
            + row["energy_estimate_mj"]
            + row["energy_prediction_mj"]
        ) - (
            baseline["energy_infer_mj"]
            + baseline["energy_consensus_mj"]
            + baseline["energy_estimate_mj"]
            + baseline["energy_prediction_mj"]
        )

        comm_avoided = (
            baseline["energy_tx_mj"] + baseline["energy_rx_mj"]
        ) - (
            row["energy_tx_mj"] + row["energy_rx_mj"]
        )

        row["ai_extra_energy_mj"] = round(ai_extra, 4)
        row["communication_energy_avoided_mj"] = round(comm_avoided, 4)
        row["delta_e_ai_mj"] = round(ai_extra - comm_avoided, 4)
    else:
        row["ai_extra_energy_mj"] = None
        row["communication_energy_avoided_mj"] = None
        row["delta_e_ai_mj"] = None

summary_rows.sort(key=lambda r: (r["nodes"], r["policy"]))

summary_file = out_dir / "summary.csv"
all_fields = list(summary_rows[0].keys())
with open(summary_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=all_fields)
    writer.writeheader()
    writer.writerows(summary_rows)

for row in summary_rows:
    print(row)

print(f"\nResumen: {summary_file}")
print(f"Corridas Monte Carlo: {raw_file}")
