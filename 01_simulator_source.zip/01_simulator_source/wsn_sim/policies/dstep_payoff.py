import math
from .dstep import DStepPolicy


class DStepPayoffPolicy(DStepPolicy):
    """Payoff-aware D-STEP policy.

    This policy preserves the D-STEP evidence/consensus/estimation machinery but
    adds an explicit node-local computation-vs-communication decision.  The
    decision uses only information locally available to the node: belief, VoI,
    recent link feedback, local degree/congestion, ETA/deadline state, and
    residual energy.  Ground-truth event parameters are never consulted.
    """

    name = "dstep_payoff"
    uses_local_inference = True

    def __init__(self, sim):
        super().__init__(sim)
        self.paycfg = sim.cfg.get("dstep_payoff", {})
        self._risk_quorum_cache = {}

    @staticmethod
    def _clamp(x, lo=0.0, hi=1.0):
        return max(lo, min(hi, float(x)))

    def _charge_payoff_decision(self, node):
        e = float(self.paycfg.get("decision_energy_mj", 0.0))
        node.energy_payoff += e
        node.payoff_decisions += 1

    def _residual_energy_fraction(self, node):
        try:
            pct = self.sim.battery.remaining_pct(node)
            if pct is not None:
                return self._clamp(float(pct) / 100.0)
        except Exception:
            pass
        return 1.0

    def _link_quality(self, node):
        if node.last_feedback_success_rate is not None:
            return self._clamp(node.last_feedback_success_rate)
        if node.last_feedback_rssi_dbm is not None:
            midpoint = float(self.sim.radio_cfg.get("rssi_midpoint_dbm", self.sim.radio.receiver_sensitivity_dbm()))
            slope = max(1e-6, float(self.sim.radio_cfg.get("rssi_slope", 1.0)))
            z = (float(node.last_feedback_rssi_dbm) - midpoint) / slope
            if z >= 0:
                return 1.0 / (1.0 + math.exp(-min(z, 60.0)))
            ez = math.exp(max(z, -60.0))
            return ez / (1.0 + ez)
        return float(self.paycfg.get("default_link_success", 0.90))

    def _congestion(self, node):
        obs = max(1, int(node.radio_tx_observations))
        local = float(node.radio_congestion_events) / obs
        return self._clamp(local)

    def _deadline_state(self, node, eta=None):
        deadline = max(float(self.sim.deadline_s), 1e-9)
        if eta is not None:
            remaining = float(eta)
        elif node.first_detection_time is not None:
            remaining = deadline - max(0.0, self.sim.engine.time - float(node.first_detection_time))
        else:
            remaining = deadline
        normalized_remaining = self._clamp(remaining / deadline)
        urgency = 1.0 - normalized_remaining
        if remaining <= 0.0:
            urgency = 1.0
        return remaining, self._clamp(urgency)

    def _verification_messages(self, node):
        """Evidence eligible for confirmation, distinct from estimator memory.

        The estimator intentionally retains a longer history, but confirmation
        must use only evidence inside the configured verification window.
        """
        if not bool(self.paycfg.get("verification_window_guard", {}).get("enabled", True)):
            return self._recent_messages(node)
        now = self.sim.engine.time
        window = max(0.0, float(self.cfg.get("verify_window_s", 2.0)))
        out = []
        for m in node.messages_received[-self.cfg["message_memory"]:]:
            if m.get("type") not in ("evidence", "confirmed"):
                continue
            t_ref = m.get("detection_time")
            if t_ref is None:
                t_ref = m.get("time", now)
            if t_ref is None:
                t_ref = now
            age = now - float(t_ref)
            if -1e-9 <= age <= window + 1e-9:
                out.append(m)
        return out

    def _independent_verification_messages(self, node):
        msgs = self._verification_messages(node)
        if not bool(self.paycfg.get("unique_source_quorum", {}).get("enabled", True)):
            return msgs
        by_source = {}
        for m in msgs:
            sid = m.get("source")
            if sid is None:
                continue
            prev = by_source.get(sid)
            # Retain the strongest evidence from each independent source.
            if prev is None or float(m.get("confidence", 0.0)) > float(prev.get("confidence", 0.0)):
                by_source[sid] = m
        return list(by_source.values())

    def _neighbor_evidence(self, node):
        msgs = self._independent_verification_messages(node)
        vals = [m.get("confidence", 0.0) for m in msgs if m.get("confidence", 0.0) >= self.cfg["neighbor_threshold"]]
        return (sum(vals) / len(vals)) if vals else 0.0, len(vals)

    def _spatial_score(self, node):
        msgs = self._independent_verification_messages(node)
        scores = []
        for m in msgs:
            pos = m.get("position")
            if pos is None:
                continue
            d = math.dist(node.position, tuple(pos))
            scores.append(math.exp(-d / max(self.cfg["spatial_lambda_m"], 1e-9)))
        return sum(scores) / len(scores) if scores else 0.0

    def _novelty(self, node, confidence):
        msgs = self._recent_messages(node)
        if not msgs:
            return self._clamp(confidence)
        prev = sum(float(m.get("confidence", 0.0)) for m in msgs) / len(msgs)
        return self._clamp(abs(float(confidence) - prev))

    def _tx_energy_estimate_mj(self, node):
        return float(self.sim.radio.tx_energy_for_power(
            node,
            float(self.sim.cfg["energy_mj"]["tx_base"]),
            int(self.sim.radio_cfg.get("payload_bytes", 48)),
        ))

    def _estimate_evidence_count(self, node):
        count = 1 if node.first_detection_time is not None else 0
        seen = {node.node_id} if count else set()
        for m in self._recent_messages(node):
            sid = m.get("source")
            if sid in seen or m.get("position") is None or m.get("detection_time") is None:
                continue
            seen.add(sid)
            count += 1
        return count

    def _current_estimate(self, node):
        if node.est_origin is None or node.est_speed is None or node.est_t0 is None:
            return None
        return {
            "origin": node.est_origin,
            "speed": node.est_speed,
            "t0": node.est_t0,
            "direction": node.est_direction,
            "points": node.estimate_points,
            "reused": True,
        }


    @staticmethod
    def _binomial_tail(n, p, q):
        if q <= 0:
            return 1.0
        if q > n:
            return 0.0
        return sum(math.comb(n, k) * (p ** k) * ((1.0 - p) ** (n - k)) for k in range(q, n + 1))

    def _effective_false_evidence_probability(self):
        rcfg = self.paycfg.get("risk_adaptive_quorum", {})
        p_injected = self._clamp(self.sim.cfg.get("sensor", {}).get("false_positive_prob", 0.0))
        p_noise = 0.0
        if bool(rcfg.get("include_gaussian_tail", True)):
            scfg = self.sim.cfg.get("sensor", {})
            sigma = math.sqrt(float(scfg.get("noise_std", 0.0)) ** 2 + float(scfg.get("bias_std", 0.0)) ** 2)
            threshold = float(self.cfg.get("neighbor_threshold", 0.48))
            if sigma > 1e-12:
                p_noise = 0.5 * math.erfc(threshold / (sigma * math.sqrt(2.0)))
        p_single = 1.0 - (1.0 - p_injected) * (1.0 - p_noise)
        samples = max(1, int(math.floor(float(self.cfg.get("verify_window_s", 2.0)) / max(float(self.sim.period_s), 1e-9))) + 1)
        return self._clamp(1.0 - (1.0 - p_single) ** samples)

    def _confirmation_rule(self, node, confidence):
        qcfg = self.paycfg.get("adaptive_quorum", {})
        base_q = max(0, int(self.cfg.get("min_confirmations", 2)))
        base_tau = float(self.cfg.get("confirm_threshold", 0.62))
        if not bool(qcfg.get("enabled", True)):
            return base_q, base_tau, False

        degree = max(0, int(self._degree(node)))
        if degree <= 0:
            local_tau = float(qcfg.get("local_only_confidence_threshold", 0.80))
            return 0, self._clamp(local_tau), True

        rcfg = self.paycfg.get("risk_adaptive_quorum", {})
        if bool(rcfg.get("enabled", True)):
            target = max(1e-12, min(1.0, float(rcfg.get("false_consensus_target", 0.01))))
            cache_key = (degree, target)
            q_risk = self._risk_quorum_cache.get(cache_key)
            if q_risk is None:
                p_window = self._effective_false_evidence_probability()
                q_risk = degree
                for candidate in range(1, degree + 1):
                    if self._binomial_tail(degree, p_window, candidate) <= target:
                        q_risk = candidate
                        break
                self._risk_quorum_cache[cache_key] = q_risk
            legacy_floor = min(base_q, degree) if base_q > 0 else 1
            q = max(legacy_floor, q_risk)
        else:
            frac = max(0.0, float(qcfg.get("degree_fraction", 0.50)))
            q = int(math.ceil(frac * degree))
            q = max(int(qcfg.get("min_nonisolated_confirmations", 1)), q)
            q = min(base_q, degree, q)

        penalty = max(0.0, float(qcfg.get("belief_penalty_per_missing_confirmation", 0.05)))
        tau = base_tau + penalty * max(0, base_q - q)
        return int(q), self._clamp(tau), False

    def _apply_persistent_local_evidence(self, node, confidence, confirmations, required_confirmations, confirm_threshold, local_only_fallback):
        """Relax at most one missing spatial confirmation after persistent local evidence.

        A one-sample spike is not sufficient.  Relaxation is allowed only after
        local evidence remains above a stricter threshold for approximately one
        sampling interval.  This provides a topology-aware fallback for sparse
        networks without treating a single local excursion as distributed
        consensus.
        """
        qcfg = self.paycfg.get("adaptive_quorum", {})
        if not bool(qcfg.get("persistent_local_relaxation", True)):
            return required_confirmations, confirm_threshold, local_only_fallback
        if node.first_detection_time is None:
            return required_confirmations, confirm_threshold, local_only_fallback
        elapsed = max(0.0, self.sim.engine.time - float(node.first_detection_time))
        persistence_s = max(0.0, float(qcfg.get("persistence_s", 0.8)))
        conf_min = float(qcfg.get("persistent_local_confidence_threshold", 0.60))
        if elapsed < persistence_s or float(confidence) < conf_min:
            return required_confirmations, confirm_threshold, local_only_fallback
        if confirmations >= required_confirmations:
            return required_confirmations, confirm_threshold, local_only_fallback

        relax = max(0, int(qcfg.get("max_quorum_relaxation", 1)))
        q_eff = max(0, int(required_confirmations) - relax)
        # If persistence removes the last required neighbor, confirmation is
        # explicitly local/persistent and uses confidence rather than the
        # consensus-weighted belief, which would be structurally depressed by
        # missing neighbor terms.
        if q_eff == 0:
            tau = max(float(self.cfg.get("local_threshold", 0.5)), conf_min)
            return 0, tau, True
        return q_eff, confirm_threshold, local_only_fallback

    def _state_vector(self, node, belief, voi, eta=None):
        remaining, urgency = self._deadline_state(node, eta)
        return {
            "belief": self._clamp(belief),
            "voi": self._clamp(voi),
            "link_quality": self._link_quality(node),
            "density": self._clamp(self._degree(node) / max(float(self.paycfg.get("degree_scale", 8.0)), 1e-9)),
            "congestion": self._congestion(node),
            "eta_s": None if eta is None else float(eta),
            "deadline_remaining_s": float(remaining),
            "urgency": urgency,
            "residual_energy": self._residual_energy_fraction(node),
        }

    def _compute_payoff(self, node, confidence, belief, cheap_voi):
        """Return payoff for spending extra compute on estimation + ETA.

        Positive values mean that the expected communication/risk reduction is
        larger than the normalized local-computation and delay costs.
        """
        self._charge_payoff_decision(node)
        state = self._state_vector(node, belief, cheap_voi, None)
        novelty = self._novelty(node, confidence)
        redundancy = self._clamp(1.0 - max(cheap_voi, novelty))
        uncertainty = self._clamp(1.0 - abs(0.5 - float(belief)) * 2.0)
        link_risk = 1.0 - state["link_quality"]

        tx_e = max(self._tx_energy_estimate_mj(node), 1e-9)
        ref_tx = max(float(self.paycfg.get("reference_tx_energy_mj", tx_e)), 1e-9)
        comm_pressure = (tx_e / ref_tx) * (
            1.0
            + float(self.paycfg.get("congestion_weight", 0.75)) * state["congestion"]
            + float(self.paycfg.get("link_risk_weight", 0.55)) * link_risk
        )

        comp_e = float(self.sim.cfg["energy_mj"].get("estimate", 0.0)) + float(self.sim.cfg["energy_mj"].get("prediction", 0.0))
        comp_norm = (comp_e / ref_tx) * float(self.paycfg.get("compute_cost_scale", 1.0))
        expected_savings = (
            float(self.paycfg.get("redundancy_compute_gain", 0.85)) * redundancy * comm_pressure
            + float(self.paycfg.get("uncertainty_compute_gain", 0.30)) * uncertainty
            + float(self.paycfg.get("congestion_compute_gain", 0.25)) * state["congestion"]
        )
        delay_penalty = float(self.paycfg.get("compute_delay_penalty", 0.08)) * state["urgency"]
        low_energy_penalty = float(self.paycfg.get("low_energy_penalty", 0.10)) * (1.0 - state["residual_energy"])
        payoff = expected_savings - comp_norm - delay_penalty - low_energy_penalty
        node.payoff_last_compute = payoff
        node.payoff_sum += payoff
        node.payoff_min = payoff if node.payoff_min is None else min(node.payoff_min, payoff)
        node.payoff_max = payoff if node.payoff_max is None else max(node.payoff_max, payoff)
        return payoff, state

    def _transmit_payoff(self, node, confidence, belief, voi, eta=None, confirmed=False):
        self._charge_payoff_decision(node)
        state = self._state_vector(node, belief, voi, eta)
        novelty = self._novelty(node, confidence)
        redundancy = self._clamp(1.0 - max(voi, novelty))
        useful = self._clamp(
            float(self.paycfg.get("belief_utility_weight", 0.35)) * self._clamp(belief)
            + float(self.paycfg.get("voi_utility_weight", 0.35)) * self._clamp(voi)
            + float(self.paycfg.get("urgency_utility_weight", 0.20)) * state["urgency"]
            + float(self.paycfg.get("novelty_utility_weight", 0.10)) * novelty
        )
        if confirmed:
            useful = self._clamp(useful + float(self.paycfg.get("confirmed_bonus", 0.20)))

        tx_e = max(self._tx_energy_estimate_mj(node), 1e-9)
        ref_tx = max(float(self.paycfg.get("reference_tx_energy_mj", tx_e)), 1e-9)
        comm_cost = float(self.paycfg.get("tx_cost_weight", 0.22)) * (tx_e / ref_tx)
        comm_cost *= 1.0 + float(self.paycfg.get("congestion_tx_penalty", 0.55)) * state["congestion"]
        reliability_value = useful * state["link_quality"]
        redundancy_penalty = float(self.paycfg.get("redundancy_penalty", 0.24)) * redundancy
        low_energy_penalty = float(self.paycfg.get("tx_low_energy_penalty", 0.08)) * (1.0 - state["residual_energy"])
        payoff = reliability_value - comm_cost - redundancy_penalty - low_energy_penalty
        node.payoff_last_transmit = payoff
        node.payoff_sum += payoff
        node.payoff_min = payoff if node.payoff_min is None else min(node.payoff_min, payoff)
        node.payoff_max = payoff if node.payoff_max is None else max(node.payoff_max, payoff)
        return payoff, state

    def _should_deep_compute(self, node, confidence, belief, cheap_voi):
        evidence_count = self._estimate_evidence_count(node)
        min_points = int(self.cfg.get("min_points_estimate", 3))
        # Structural guard: do not pay estimation/prediction energy when the
        # estimator cannot yet be identified from the available evidence.
        if evidence_count < min_points:
            self._charge_payoff_decision(node)
            payoff = -float(self.paycfg.get("insufficient_evidence_penalty", 0.05))
            node.payoff_last_compute = payoff
            node.payoff_sum += payoff
            node.payoff_min = payoff if node.payoff_min is None else min(node.payoff_min, payoff)
            node.payoff_max = payoff if node.payoff_max is None else max(node.payoff_max, payoff)
            node.payoff_compute_rejected += 1
            return False, payoff

        # Reuse an existing estimate until new independent evidence arrives.
        # This turns repeated estimation into an explicit compute-saving action.
        if (node.est_origin is not None
                and evidence_count == node.payoff_last_estimate_evidence_count
                and not bool(self.paycfg.get("recompute_without_new_evidence", False))):
            self._charge_payoff_decision(node)
            payoff = -float(self.paycfg.get("reuse_estimate_penalty", 0.01))
            node.payoff_last_compute = payoff
            node.payoff_sum += payoff
            node.payoff_min = payoff if node.payoff_min is None else min(node.payoff_min, payoff)
            node.payoff_max = payoff if node.payoff_max is None else max(node.payoff_max, payoff)
            node.payoff_compute_rejected += 1
            return False, payoff

        payoff, _ = self._compute_payoff(node, confidence, belief, cheap_voi)
        accept = payoff > float(self.paycfg.get("compute_threshold", 0.0))
        if accept:
            node.payoff_compute_accepted += 1
            node.payoff_last_estimate_evidence_count = evidence_count
        else:
            node.payoff_compute_rejected += 1
        return accept, payoff

    def _should_transmit(self, node, confidence, belief, voi, eta=None, confirmed=False, force_reliability=False):
        payoff, state = self._transmit_payoff(node, confidence, belief, voi, eta, confirmed)
        threshold = float(self.paycfg.get("transmit_threshold", 0.0))
        emergency = confirmed and state["urgency"] >= float(self.paycfg.get("confirmed_urgency_override", 0.85))
        reliability_guard = confirmed and bool(self.paycfg.get("confirmed_delivery_guard", True))
        if force_reliability:
            reliability_guard = True
        accept = payoff > threshold or emergency or reliability_guard
        if reliability_guard and payoff <= threshold:
            node.payoff_reliability_overrides += 1
        if accept:
            node.payoff_transmit_accepted += 1
        else:
            node.payoff_transmit_rejected += 1
            node.suppressed_tx_count += 1
            node.payoff_estimated_tx_energy_saved_mj += self._tx_energy_estimate_mj(node)
        return accept, payoff

    def on_sample(self, node, value, confidence):
        node.local_confidence = confidence
        if node.state == "NORMAL" and confidence >= self.cfg["local_threshold"]:
            node.state = "SUSPECT"

        belief = self._belief(node, confidence)
        node.global_belief = belief
        _, confirmations = self._neighbor_evidence(node)

        cheap_voi = self._voi(node, confidence, belief, None)
        estimate = self._current_estimate(node)
        eta = node.est_eta
        if self.ablation.get("use_estimation", True) or self.ablation.get("use_prediction", True):
            do_compute, _ = self._should_deep_compute(node, confidence, belief, cheap_voi)
            if do_compute:
                estimate = self._estimate_event(node)
                eta = self._predict_eta(node, estimate)
            else:
                node.payoff_optional_compute_skipped += 1

        voi = self._voi(node, confidence, belief, eta)

        required_confirmations, confirm_threshold, local_only_fallback = self._confirmation_rule(node, confidence)
        # Risk-calibrated quorums must not be relaxed below their probabilistic
        # false-consensus bound. Legacy/topology-only mode retains v0.44 persistence.
        if not bool(self.paycfg.get("risk_adaptive_quorum", {}).get("enabled", True)):
            required_confirmations, confirm_threshold, local_only_fallback = self._apply_persistent_local_evidence(
                node, confidence, confirmations, required_confirmations, confirm_threshold, local_only_fallback
            )

        if node.state == "SUSPECT":
            node.state = "VERIFY"
            force_verify = confirmations < required_confirmations and confidence >= self.cfg["local_threshold"]
            if self._should_transmit(node, confidence, belief, voi, eta, confirmed=False, force_reliability=force_verify)[0]:
                self._send(node, confidence, belief, estimate)

        if node.state == "VERIFY":
            fast_cfg = self.paycfg.get("local_fast_path", {})
            fast_local = bool(fast_cfg.get("enabled", True)) and float(confidence) >= float(fast_cfg.get("confidence_threshold", 0.90))
            confirmation_score = confidence if local_only_fallback else belief
            distributed_confirm = confirmation_score >= confirm_threshold and confirmations >= required_confirmations
            if distributed_confirm or fast_local:
                node.state = "CONFIRMED"
                node.confirmed = True
                if node.first_confirmation_time is None:
                    node.first_confirmation_time = self.sim.engine.time
                if node.first_alert_time is None:
                    node.first_alert_time = self.sim.engine.time
                if self._should_transmit(node, confidence, belief, voi, eta, confirmed=True)[0]:
                    self._send(node, confidence, belief, estimate, msg_type="confirmed")
                node.state = "PROPAGATE"

        if confidence < self.cfg["local_threshold"] * 0.65 and node.state in ("SUSPECT", "VERIFY"):
            node.state = "NORMAL"

    def on_receive(self, node, message):
        msg_id = message.get("msg_id")
        if msg_id and msg_id in node.seen_messages:
            return
        if msg_id:
            node.seen_messages.add(msg_id)
        if message.get("ttl", 0) <= 0:
            return

        if self._equivalent_seen(node, message):
            node.pending_forward_token += 1
        self._remember_equivalent(node, message)

        conf = max(node.local_confidence, float(message.get("confidence", 0.0)))
        belief = max(node.global_belief, float(message.get("belief", 0.0)))
        cheap_voi = self._voi(node, conf, belief, None)

        estimate = self._current_estimate(node)
        eta = node.est_eta
        do_compute, _ = self._should_deep_compute(node, conf, belief, cheap_voi)
        if do_compute:
            estimate = self._estimate_event(node)
            if estimate is None and message.get("estimate"):
                estimate = message["estimate"]
                if estimate.get("origin") is not None:
                    node.est_origin = tuple(estimate["origin"])
                node.est_speed = estimate.get("speed")
                node.est_t0 = estimate.get("t0")
                if estimate.get("direction") is not None:
                    node.est_direction = tuple(estimate["direction"])
            eta = self._predict_eta(node, estimate)
        else:
            node.payoff_optional_compute_skipped += 1

        voi = self._voi(node, conf, belief, eta)
        directional = self._directional_score(node, message)
        score = self.cfg["voi_weight"] * voi + self.cfg["directional_weight"] * directional

        if message.get("type") == "confirmed" and node.first_alert_time is None:
            node.first_alert_time = self.sim.engine.time

        confirmed = message.get("type") == "confirmed"
        if self._should_transmit(node, conf, belief, voi, eta, confirmed=confirmed)[0]:
            self._schedule_forward(node, message, score, estimate)
