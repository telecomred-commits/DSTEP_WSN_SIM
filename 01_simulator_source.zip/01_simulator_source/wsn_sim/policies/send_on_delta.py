from .base import Policy


class SendOnDeltaPolicy(Policy):
    """Classical Send-on-Delta style baseline.

    Reports when the sensor value changes by at least ``delta`` relative to the
    last report.  A maximum silence interval prevents a node from remaining
    silent indefinitely while an event is present.
    """
    name = "send_on_delta"
    uses_local_inference = False

    def __init__(self, sim):
        super().__init__(sim)
        cfg = sim.cfg.get("send_on_delta", {})
        self.delta = float(cfg.get("delta", 0.12))
        self.threshold = float(cfg.get("threshold", sim.sensor_threshold))
        self.max_silence_s = float(cfg.get("max_silence_s", 5.0))
        self.last_value = {}
        self.last_time = {}

    def on_sample(self, node, value, confidence):
        now = self.sim.engine.time
        prev = self.last_value.get(node.node_id)
        last_t = self.last_time.get(node.node_id, -1e30)
        changed = prev is None or abs(float(value) - float(prev)) >= self.delta
        due = (now - last_t) >= self.max_silence_s
        if value >= self.threshold and (changed or due):
            self.sim.send_application(node, {
                "type": "send_on_delta",
                "source": node.node_id,
                "value": float(value),
                "confidence": float(confidence),
                "time": now,
            })
            self.last_value[node.node_id] = float(value)
            self.last_time[node.node_id] = now
