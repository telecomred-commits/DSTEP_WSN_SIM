from .base import Policy


class TeenLikePolicy(Policy):
    """TEEN/APTEEN-like threshold baseline for controlled comparison.

    This is deliberately described as *TEEN-like*, not as a protocol-faithful
    reproduction: hard and soft thresholds gate event reports and an APTEEN-like
    report interval provides periodic refresh while the event remains active.
    """
    name = "teen_like"
    uses_local_inference = False

    def __init__(self, sim):
        super().__init__(sim)
        cfg = sim.cfg.get("teen_like", {})
        self.hard_threshold = float(cfg.get("hard_threshold", sim.sensor_threshold))
        self.soft_threshold = float(cfg.get("soft_threshold", 0.08))
        self.report_interval_s = float(cfg.get("report_interval_s", 5.0))
        self.last_reported = {}
        self.last_time = {}

    def on_sample(self, node, value, confidence):
        if value < self.hard_threshold:
            return
        now = self.sim.engine.time
        prev = self.last_reported.get(node.node_id)
        last_t = self.last_time.get(node.node_id, -1e30)
        soft = prev is None or abs(float(value) - float(prev)) >= self.soft_threshold
        periodic_refresh = (now - last_t) >= self.report_interval_s
        if soft or periodic_refresh:
            self.sim.send_application(node, {
                "type": "teen_like",
                "source": node.node_id,
                "value": float(value),
                "confidence": float(confidence),
                "time": now,
            })
            self.last_reported[node.node_id] = float(value)
            self.last_time[node.node_id] = now
