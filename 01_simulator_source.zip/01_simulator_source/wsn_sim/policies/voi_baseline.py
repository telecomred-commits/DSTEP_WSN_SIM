from .base import Policy


class VoIBaselinePolicy(Policy):
    """Local Value-of-Information dissemination baseline.

    No consensus, physical-front estimation, ETA prediction, density-aware
    forwarding, or channel-aware decision logic is used by the policy itself.
    It therefore isolates the value of a local relevance gate from full D-STEP.
    """
    name = "voi_baseline"
    uses_local_inference = True

    def __init__(self, sim):
        super().__init__(sim)
        cfg = sim.cfg.get("voi_baseline", {})
        self.threshold = float(cfg.get("threshold", 0.35))
        self.event_threshold = float(cfg.get("event_threshold", sim.sensor_threshold))
        self.novelty_weight = float(cfg.get("novelty_weight", 0.55))
        self.uncertainty_weight = float(cfg.get("uncertainty_weight", 0.20))
        self.timeliness_weight = float(cfg.get("timeliness_weight", 0.25))
        self.last_confidence = {}

    def on_sample(self, node, value, confidence):
        prev = self.last_confidence.get(node.node_id, 0.0)
        novelty = min(1.0, abs(float(confidence) - float(prev)))
        uncertainty = max(0.0, 1.0 - abs(0.5 - float(confidence)) * 2.0)
        if node.first_detection_time is None:
            timeliness = 0.0
        else:
            elapsed = max(0.0, self.sim.engine.time - node.first_detection_time)
            timeliness = min(1.0, elapsed / max(self.sim.deadline_s, 1e-9))
        voi = (
            self.novelty_weight * novelty
            + self.uncertainty_weight * uncertainty
            + self.timeliness_weight * timeliness
        )
        if confidence >= self.event_threshold and voi >= self.threshold:
            self.sim.send_application(node, {
                "type": "voi_baseline",
                "source": node.node_id,
                "confidence": float(confidence),
                "voi": float(voi),
                "time": self.sim.engine.time,
            })
            self.last_confidence[node.node_id] = float(confidence)
