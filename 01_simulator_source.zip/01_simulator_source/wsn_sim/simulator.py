import random
import math
from collections import deque
from .core.event_engine import EventEngine
from .nodes.node import Node
from .radio.model import RadioModel
from .radio.profiles import apply_radio_profile
from .radio_control.factory import create_radio_controller
from .environments.profiles import apply_profile
from .topology.metrics import topology_metrics
from .world.event_generator import realize_event
from .policies.periodic import PeriodicPolicy
from .policies.event_driven import EventDrivenPolicy
from .policies.central_edge import CentralEdgePolicy
from .policies.distributed_edge import DistributedEdgePolicy
from .policies.dstep import DStepPolicy
from .policies.dstep_payoff import DStepPayoffPolicy
from .policies.send_on_delta import SendOnDeltaPolicy
from .policies.teen_like import TeenLikePolicy
from .policies.voi_baseline import VoIBaselinePolicy
from .plugins.loader import load_plugin_policy
from .mobility import MobilityManager
from .energy import BatteryManager

POLICIES = {
    "periodic": PeriodicPolicy,
    "event_driven": EventDrivenPolicy,
    "central_edge": CentralEdgePolicy,
    "distributed_edge": DistributedEdgePolicy,
    "dstep": DStepPolicy,
    "dstep_payoff": DStepPayoffPolicy,
    "send_on_delta": SendOnDeltaPolicy,
    "teen_like": TeenLikePolicy,
    "voi_baseline": VoIBaselinePolicy,
}

class Simulator:
    def __init__(self, cfg, node_count, policy_name, seed, ablation_mode="full"):
        self.cfg = cfg
        self.duration = cfg["simulation_time_s"]
        self.deadline_s = cfg["deadline_s"]
        self.period_s = cfg["period_s"]
        self.sensor_threshold = cfg["sensor"]["threshold"]

        self.engine = EventEngine()
        # Independent random streams: topology/sensing/channel cannot perturb each other.
        self.seed = seed
        self.topology_rng = random.Random(seed + 100003)
        self.sensor_rng = random.Random(seed + 200003)
        self.channel_rng = random.Random(seed + 300007)
        self.control_rng = random.Random(seed + 400009)
        self.mac_rng = random.Random(seed + 500009)
        self.rng = self.sensor_rng  # backwards-compatible alias; D-STEP does not use it.
        self.radio_cfg = apply_radio_profile(apply_profile(cfg["radio"], cfg.get("environment", {"profile":"custom"})))
        # MAC is kept outside D-STEP/radio-control logic, but RadioModel needs
        # CCA parameters to decide whether an active signal is detectable.
        self.radio_cfg["mac"] = dict(cfg.get("mac", {}))
        self.radio = RadioModel(self.radio_cfg, self.channel_rng)
        self.policy_name = policy_name
        self.ablation_mode = ablation_mode
        # Resolve communication mode per simulation without mutating the shared cfg.
        # This preserves legacy batch experiments that reuse one config object across policies.
        raw_communication = cfg.get("communication") or {}
        default_architecture = "direct_to_sink" if policy_name == "central_edge" else "distributed"
        self.communication_architecture = raw_communication.get("architecture", default_architecture)
        self.communication_cfg = dict(raw_communication)
        self.communication_cfg["architecture"] = self.communication_architecture
        self.routing_cfg = dict(raw_communication.get("routing", {"strategy": "shortest_hop", "max_hops": 32}))
        self.routing_packets = 0
        self.routing_delivered = 0
        self.routing_no_route = 0
        self.routing_hops_attempted = 0
        self.routing_hops_successful = 0
        self.routing_hops_failed = 0
        self.routing_total_hops_delivered = 0
        self.intelligence_profile = cfg.get("_active_intelligence_profile")
        if self.intelligence_profile:
            profile = cfg.get("intelligence_profiles", {}).get(self.intelligence_profile)
            if profile is None:
                raise ValueError(f"Unknown intelligence profile: {self.intelligence_profile}")
            # Expose the profile through the existing D-STEP ablation interface.
            self.ablation_mode = self.intelligence_profile
            cfg.setdefault("ablation", {})[self.intelligence_profile] = {
                "use_consensus": profile.get("use_consensus", True),
                "use_voi": profile.get("use_voi", True),
                "use_estimation": profile.get("use_estimation", True),
                "use_prediction": profile.get("use_prediction", True),
                "use_density": profile.get("use_density", True),
                "use_suppression": profile.get("use_suppression", True),
                "use_backoff": profile.get("use_backoff", True),
            }

        # Ground truth is realized by an independent event RNG stream.
        # Policies do not receive this record; they only observe sensor samples.
        self.world = realize_event(cfg.get("event", {}), cfg["area_m"], seed)
        self.event_ground_truth = dict(self.world.ground_truth)

        w, h = cfg["area_m"]
        placement = cfg.get("topology", {}).get("placement", "uniform_random")
        manual = cfg.get("topology", {}).get("manual_positions", [])
        if placement == "manual":
            if len(manual) != node_count:
                raise ValueError(f"manual_positions must contain exactly {node_count} positions")
            self.nodes = [Node(i, tuple(map(float, manual[i]))) for i in range(node_count)]
        else:
            self.nodes = [Node(i, (self.topology_rng.uniform(0, w), self.topology_rng.uniform(0, h))) for i in range(node_count)]
        self.sink = Node(-1, tuple(cfg["sink_position"]))
        # Optional mobility layer. Static/0 m/s preserves the legacy execution path.
        self.mobility = MobilityManager(self)
        self.battery = BatteryManager(self)
        controller_name = cfg.get("radio_control", {}).get("mode", "fixed")
        self.radio_controller = create_radio_controller(controller_name, self)
        for node in self.nodes:
            self.radio_controller.initialize_node(node)
        self.radio_controller.initialize_node(self.sink)
        if cfg.get("radio_control", {}).get("tx_energy_by_power_mj"):
            self.radio_cfg["tx_energy_by_power_mj"] = cfg.get("radio_control", {}).get("tx_energy_by_power_mj", {})
        if policy_name.startswith("plugin:"):
            self.policy = load_plugin_policy(self, policy_name)
        else:
            self.policy = POLICIES[policy_name](self)

        self.collisions = 0
        self.channel_losses = 0
        self.out_of_range = 0
        self.below_sensitivity = 0
        # Link-level delivery accounting. A broadcast TX may create many
        # receiver attempts, therefore PDR must not be computed as RX/TX.
        self.link_delivery_attempts = 0
        self.link_delivery_successes = 0
        self.link_delivery_failures = 0
        # v0.39/v0.40 MAC-layer accounting. This is deliberately independent of
        # D-STEP's algorithmic forwarding/backoff and radio-controller waits.
        self.mac_cca_busy = 0
        self.mac_backoff_events = 0
        self.mac_access_drops = 0
        self.sinr_samples_db = []
        self.interfered_receptions = 0

        # v0.40 MAC reliability/queue state. A node owns one half-duplex radio,
        # therefore only one data request is serviced at a time. Waiting frames
        # are kept in a finite FIFO when queueing is enabled.
        self.mac_queues = {int(n.node_id): deque() for n in self.nodes}
        self.mac_active_requests = {}
        self.mac_queue_enqueued = 0
        self.mac_queue_drops = 0
        self.mac_queue_delay_samples_s = []
        self.mac_service_time_samples_s = []
        self.mac_max_queue_depth = 0
        self.mac_retry_tx_frames = 0
        self.mac_retries_scheduled = 0
        self.mac_retry_exhausted = 0
        self.mac_ack_timeouts = 0
        self.mac_ack_tx_frames = 0
        self.mac_ack_rx_frames = 0
        self.mac_ack_losses = 0
        self.mac_ack_collisions = 0
        self.mac_ack_channel_losses = 0
        self.mac_ack_below_sensitivity = 0
        self.mac_duplicate_data_rx = 0
        self.mac_retry_tx_energy_mj = 0.0
        self.mac_ack_energy_mj = 0.0
        self.mac_unicast_frames_started = 0
        self.mac_unicast_frames_success = 0
        self.mac_unicast_frames_failed = 0
        self.mac_unicast_queue_drops = 0
        # v0.40.1 separates actual DATA arrival from ACK-confirmed completion.
        self.mac_unicast_data_frames_received = 0
        self.mac_reliable_data_frames_received = 0
        self.mac_reliable_frames_started = 0
        self.mac_reliable_frames_success = 0
        self.mac_reliable_frames_failed = 0
        self.mac_reliable_queue_drops = 0
        self.routing_sink_data_arrivals = 0

        # Node-specific sensor bias
        self.sensor_bias = {
            n.node_id: self.sensor_rng.gauss(0.0, self.cfg["sensor"].get("bias_std", 0.0))
            for n in self.nodes
        }

    def confidence_from_sample(self, x):
        return max(0.0, min(1.0, x))

    def sensor_value(self, node):
        signal = self.world.intensity(node.position, self.engine.time)
        noise = self.sensor_rng.gauss(0.0, self.cfg["sensor"]["noise_std"])
        x = signal + noise + self.sensor_bias[node.node_id]

        # Imperfecciones sintéticas controladas
        if signal > 0.55 and self.sensor_rng.random() < self.cfg["sensor"].get("false_negative_prob", 0.0):
            x *= 0.35
        elif signal < 0.2 and self.sensor_rng.random() < self.cfg["sensor"].get("false_positive_prob", 0.0):
            x = max(x, self.sensor_rng.uniform(0.58, 0.85))

        return max(0.0, min(1.0, x))

    def schedule_samples(self):
        t = 0.0
        while t <= self.duration:
            for node in self.nodes:
                self.engine.schedule(t, self.sample_node, node)
            t += self.period_s

    def sample_node(self, node):
        if not self.battery.can_operate(node, self.engine.time):
            return
        tm = self.cfg["timing_ms"]
        en = self.cfg["energy_mj"]

        node.energy_sense += en["sense"]
        node.energy_preprocess += en["preprocess"]

        value = self.sensor_value(node)

        if self.policy.uses_local_inference:
            node.energy_infer += en["infer"]
            confidence = self.confidence_from_sample(value)
            infer_ms = tm["infer"]
        else:
            # Baselines without Edge AI use the sensor/threshold value directly.
            confidence = value
            infer_ms = 0.0

        payoff_ms = 0.0
        if self.policy_name == "dstep_payoff":
            payoff_ms = float(self.cfg.get("dstep_payoff", {}).get("decision_time_ms", 0.0))
        processing_delay = (tm["sense"] + tm["preprocess"] + infer_ms + tm["decision"] + payoff_ms) / 1000.0
        decision_time = self.engine.time + processing_delay

        if confidence >= self.sensor_threshold and node.first_detection_time is None:
            node.first_detection_time = decision_time

        self.battery.after_activity(node, self.engine.time)
        if node.alive or not self.battery.enabled:
            self.engine.schedule(decision_time, self.process_policy, node, value, confidence)

    def process_policy(self, node, value, confidence):
        if not self.battery.can_operate(node, self.engine.time):
            return
        self.policy.on_sample(node, value, confidence)
        self.battery.after_activity(node, self.engine.time)

        # For baselines, detection is local classifier output.
        # For D-STEP, confirmed state is the network-level decision.
        if self.policy_name in ("dstep", "dstep_payoff"):
            node.detected = node.confirmed
        elif self.policy_name.startswith("plugin:"):
            # External algorithms explicitly declare detection/alert through NodeContext.
            # This keeps their scientific metrics tied to their own decision logic.
            pass
        else:
            if confidence >= self.sensor_threshold:
                node.detected = True
                if self.policy_name in ("periodic", "event_driven", "distributed_edge", "send_on_delta", "teen_like", "voi_baseline") and node.first_alert_time is None:
                    # these baselines act on their own local decision
                    node.first_alert_time = self.engine.time

    def neighbors(self, sender):
        if self.battery.enabled and not self.battery.can_operate(sender, self.engine.time):
            return []
        return [
            n for n in self.nodes
            if n.node_id != sender.node_id
            and (not self.battery.enabled or self.battery.can_operate(n, self.engine.time))
            and self.radio.nominal_link_available(sender, n)
        ]

    def communication_candidates(self, sender):
        if self.battery.enabled and not self.battery.can_operate(sender, self.engine.time):
            return []
        return [
            n for n in self.nodes
            if n.node_id != sender.node_id
            and (not self.battery.enabled or self.battery.can_operate(n, self.engine.time))
            and self.radio.candidate_receiver(sender, n)
        ]

    def feedback_receivers(self, sender, candidates=None):
        """
        Feedback is based on the nearest relevant receivers, not the entire network.
        This avoids distant irrelevant nodes forcing TX-power escalation.
        """
        if candidates is None:
            candidates = self.communication_candidates(sender)
        k = int(self.cfg.get("radio_control", {}).get("feedback_neighbor_count", 4))
        ranked = sorted(
            candidates,
            key=lambda n: ((n.position[0]-sender.position[0])**2 + (n.position[1]-sender.position[1])**2)
        )
        return ranked[:max(1, k)]

    def set_node_tx_power(self, node, power_dbm):
        """Optional algorithm-level radio control hook."""
        if not self.cfg.get("radio_control", {}).get("allow_policy_override", True):
            return node.tx_power_dbm
        return self.radio_controller.set_power(node, power_dbm)

    def _radio_params(self):
        tm = self.cfg["timing_ms"]
        en = self.cfg["energy_mj"]
        return (
            tm["access"]/1000.0,
            tm["tx_base"]/1000.0,
            en["tx_base"],
            en["rx_base"],
        )

    def _record_delivery_outcome(self, success, reason=None):
        self.link_delivery_attempts += 1
        if success:
            self.link_delivery_successes += 1
        else:
            self.link_delivery_failures += 1

    def _record_radio_resolution(self, tx, receiver):
        meta = self.radio.last_resolution_meta.get((tx.tx_id, receiver.node_id), {})
        sinr = meta.get("sinr_db")
        if sinr is not None and math.isfinite(float(sinr)):
            self.sinr_samples_db.append(float(sinr))
        if int(meta.get("interferers", 0)) > 0:
            self.interfered_receptions += 1

    def _count_failure(self, reason):
        if reason == "collision":
            self.collisions += 1
        elif reason == "channel_loss":
            self.channel_losses += 1
        elif reason == "out_of_range":
            self.out_of_range += 1
        elif reason == "below_sensitivity":
            self.below_sensitivity += 1

    def send_application(self, sender, payload):
        """Send one application frame according to the selected network architecture.

        distributed       -> one-hop physical broadcast to neighboring nodes
        direct_to_sink    -> one direct physical transmission to the sink
        multi_hop_to_sink -> shortest-hop nominal route, then physical hop-by-hop delivery
        """
        if not self.battery.can_operate(sender, self.engine.time):
            return False
        architecture = self.communication_architecture
        if architecture == "distributed":
            return self.broadcast(sender, payload)
        if architecture == "direct_to_sink":
            return self.send_to_sink(sender, payload)
        if architecture == "multi_hop_to_sink":
            return self.route_to_sink(sender, payload)
        raise ValueError(f"Unknown communication architecture: {architecture}")

    def nominal_route_to_sink(self, sender):
        """Return a shortest-hop directed route [sender, ..., sink] using nominal links."""
        vertices = list(self.nodes) + [self.sink]
        by_id = {v.node_id: v for v in vertices}
        start, target = sender.node_id, self.sink.node_id
        q = deque([start]); parent = {start: None}
        max_hops = max(1, int(self.routing_cfg.get("max_hops", 32)))
        depth = {start: 0}
        while q:
            uid = q.popleft(); u = by_id[uid]
            if uid == target:
                break
            if depth[uid] >= max_hops:
                continue
            # Deterministic order: ordinary nodes by id, sink last.
            for v in sorted(vertices, key=lambda x: (x.node_id == -1, x.node_id)):
                vid = v.node_id
                if vid == uid or vid in parent:
                    continue
                if self.radio.nominal_link_available(u, v):
                    parent[vid] = uid; depth[vid] = depth[uid] + 1; q.append(vid)
                    if vid == target:
                        q.clear(); break
        if target not in parent:
            return None
        ids=[]; cur=target
        while cur is not None:
            ids.append(cur); cur=parent[cur]
        ids.reverse()
        return [by_id[i] for i in ids]

    # ------------------------------------------------------------------
    # v0.40 MAC queue + reliability layer
    # ------------------------------------------------------------------
    def _mac_cfg(self):
        return self.cfg.get("mac", {}) or {}

    def _reliability_cfg(self):
        return self._mac_cfg().get("reliability", {}) or {}

    def _reliable_unicast_enabled(self):
        rcfg = self._reliability_cfg()
        return bool(rcfg.get("enabled", True) and rcfg.get("ack_unicast", True))

    def _mac_request(self, sender):
        return self.mac_active_requests.get(int(sender.node_id))

    def _enqueue_mac_request(self, sender, callback, args, kind="data"):
        """Enqueue one logical data frame for a node's half-duplex radio.

        The active request is not counted against ``queue_capacity``. The
        capacity therefore describes the number of waiting frames, which makes
        queue-overflow experiments easier to interpret.
        """
        if not self.battery.can_operate(sender, self.engine.time):
            return False
        sid = int(sender.node_id)
        queue = self.mac_queues.setdefault(sid, deque())
        qcfg = self._mac_cfg()
        finite = bool(qcfg.get("queue_enabled", True))
        capacity = max(0, int(qcfg.get("queue_capacity", 16)))
        req = {
            "sender": sender,
            "callback": callback,
            "args": tuple(args),
            "kind": str(kind),
            "enqueued_s": float(self.engine.time),
            "service_start_s": None,
            "data_delivered": False,
            "completed": False,
            "unicast": bool(str(kind) in ("direct", "route")),
            "unicast_recorded": False,
            "reliable": bool(str(kind) in ("direct", "route") and self._reliable_unicast_enabled()),
            "reliable_recorded": False,
        }
        self.mac_queue_enqueued += 1
        if sid in self.mac_active_requests:
            if finite and len(queue) >= capacity:
                self.mac_queue_drops += 1
                if req["unicast"]:
                    self.mac_unicast_queue_drops += 1
                if req["reliable"]:
                    self.mac_reliable_queue_drops += 1
                return False
            req["_was_queued"] = True
            queue.append(req)
            self.mac_max_queue_depth = max(self.mac_max_queue_depth, len(queue))
            return True
        self.mac_active_requests[sid] = req
        if req["unicast"]:
            self.mac_unicast_frames_started += 1
        if req["reliable"]:
            self.mac_reliable_frames_started += 1
        self._start_mac_request(sender)
        return True

    def _start_mac_request(self, sender):
        sid = int(sender.node_id)
        req = self.mac_active_requests.get(sid)
        if not req or req.get("completed"):
            return
        if req.get("service_start_s") is None:
            req["service_start_s"] = float(self.engine.time)
            if req.get("unicast") and req.get("_was_queued", False) and not req.get("_unicast_started_counted", False):
                self.mac_unicast_frames_started += 1
                req["_unicast_started_counted"] = True
            if req.get("reliable") and req.get("enqueued_s") != req.get("_counted_started_s"):
                # Requests activated immediately are counted in enqueue; queued
                # requests are counted when they become the active radio frame.
                if req.get("_was_queued", False):
                    self.mac_reliable_frames_started += 1
                req["_counted_started_s"] = req.get("enqueued_s")
            self.mac_queue_delay_samples_s.append(max(0.0, self.engine.time - req["enqueued_s"]))
        directive = self.radio_controller.transmission_directive(sender)
        delay_s = max(0.0, float(directive.get("delay_s", 0.0)))
        if delay_s > 0.0:
            self.engine.schedule(self.engine.time + delay_s, self._dispatch_mac_request, sid)
        else:
            self._dispatch_mac_request(sid)

    def _dispatch_mac_request(self, sid):
        req = self.mac_active_requests.get(int(sid))
        if not req or req.get("completed"):
            return
        req["callback"](*req["args"], 0, 0)

    def _complete_mac_request(self, sender, outcome="success"):
        sid = int(sender.node_id)
        req = self.mac_active_requests.pop(sid, None)
        if req is not None and not req.get("completed"):
            req["completed"] = True
            if req.get("unicast") and not req.get("unicast_recorded"):
                req["unicast_recorded"] = True
                if req.get("data_delivered", False):
                    self.mac_unicast_data_frames_received += 1
                if str(outcome) == "success":
                    self.mac_unicast_frames_success += 1
                else:
                    self.mac_unicast_frames_failed += 1
            if req.get("reliable") and not req.get("reliable_recorded"):
                req["reliable_recorded"] = True
                if req.get("data_delivered", False):
                    self.mac_reliable_data_frames_received += 1
                if str(outcome) == "success":
                    self.mac_reliable_frames_success += 1
                else:
                    self.mac_reliable_frames_failed += 1
            started = req.get("service_start_s")
            if started is not None:
                self.mac_service_time_samples_s.append(max(0.0, self.engine.time - float(started)))
        queue = self.mac_queues.setdefault(sid, deque())
        if queue:
            nxt = queue.popleft()
            self.mac_active_requests[sid] = nxt
            # Same-time scheduling prevents deep recursive chains while still
            # allowing the next frame to contend immediately when the radio is free.
            self.engine.schedule(self.engine.time, self._start_mac_request, sender)

    def _mac_gate(self, sender, retry_callback, retry_args, mac_attempt=0):
        """Independent CSMA/CA-lite gate used by every data policy."""
        mac = self._mac_cfg()
        mode = str(mac.get("mode", "none")).lower()
        if mode in ("none", "off", "disabled"):
            return 1
        if not self.radio.channel_busy(sender, self.engine.time):
            return 1

        self.mac_cca_busy += 1
        max_attempts = max(0, int(mac.get("max_cca_attempts", 5)))
        if mac_attempt >= max_attempts:
            self.mac_access_drops += 1
            return -1

        min_be = max(0, int(mac.get("min_be", 3)))
        max_be = max(min_be, int(mac.get("max_be", 5)))
        be = min(max_be, min_be + int(mac_attempt))
        slot_s = max(1e-6, float(mac.get("slot_time_s", 0.00032)))
        slots = self.mac_rng.randrange(0, 2 ** be)
        backoff_s = max(slot_s, slots * slot_s)
        self.mac_backoff_events += 1
        self.engine.schedule(
            self.engine.time + backoff_s,
            retry_callback,
            *retry_args,
            int(mac_attempt) + 1,
        )
        return 0

    @staticmethod
    def _single_receiver_feedback(success, rssi, reason):
        return {
            "observations": 1 if rssi > -199 else 0,
            "relevant_receivers": 1,
            "mean_rssi_dbm": rssi if rssi > -199 else None,
            "success_rate": 1.0 if success else 0.0,
            "collision_rate": 1.0 if reason == "collision" else 0.0,
            "below_sensitivity_rate": 1.0 if reason == "below_sensitivity" else 0.0,
            "channel_loss_rate": 1.0 if reason == "channel_loss" else 0.0,
            "successes": 1 if success else 0,
            "collisions": 1 if reason == "collision" else 0,
            "below_sensitivity": 1 if reason == "below_sensitivity" else 0,
            "channel_losses": 1 if reason == "channel_loss" else 0,
        }

    def _retry_or_exhaust(self, sender, retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args):
        """Wait for ACK timeout, then retry a reliable unicast or terminate."""
        rcfg = self._reliability_cfg()
        max_retries = max(0, int(rcfg.get("max_retries", 3)))
        self.mac_ack_timeouts += 1
        if int(reliability_attempt) >= max_retries:
            self.mac_retry_exhausted += 1
            exhausted_callback(*exhausted_args)
            return
        self.mac_retries_scheduled += 1
        ack_timeout = max(0.0, float(rcfg.get("ack_timeout_s", 0.003)))
        retry_backoff = max(0.0, float(rcfg.get("retry_backoff_s", 0.0005)))
        when = self.engine.time + ack_timeout + retry_backoff
        self.engine.schedule(when, retry_callback, *retry_args, int(reliability_attempt) + 1, 0)

    def _charge_data_tx(self, sender, tx_e, reliability_attempt):
        if int(reliability_attempt) > 0:
            self.mac_retry_tx_frames += 1
            self.mac_retry_tx_energy_mj += self.radio.tx_energy_for_power(
                sender, tx_e, self.radio_cfg.get("payload_bytes", 48)
            )
        self.radio.charge_tx_frame(sender, tx_e)
        self.battery.after_activity(sender, self.engine.time)

    def _start_ack(self, data_sender, ack_sender, success_callback, success_args,
                   retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args):
        """Transmit one link-layer ACK after SIFS without performing CCA.

        ACKs still occupy the same physical medium, consume energy and can be
        destroyed by interference. This is intentionally a compact link model,
        not a complete IEEE 802.11 state machine.
        """
        rcfg = self._reliability_cfg()
        sifs_s = max(0.0, float(rcfg.get("sifs_s", 0.0002)))
        self.engine.schedule(
            self.engine.time + sifs_s,
            self._execute_ack,
            data_sender, ack_sender, success_callback, success_args,
            retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args,
        )

    def _execute_ack(self, data_sender, ack_sender, success_callback, success_args,
                     retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args):
        if ack_sender.node_id != -1 and not self.battery.can_operate(ack_sender, self.engine.time):
            self.mac_ack_losses += 1
            self._retry_or_exhaust(
                data_sender, retry_callback, retry_args, reliability_attempt,
                exhausted_callback, exhausted_args,
            )
            return
        _, _, tx_e, rx_e = self._radio_params()
        ack_bytes = max(1, int(self._reliability_cfg().get("ack_bytes", 14)))
        ack_energy = self.radio.tx_energy_for_power(ack_sender, tx_e, ack_bytes)
        self.radio.charge_tx_frame(ack_sender, tx_e, ack_bytes, count_data=False)
        if ack_sender.node_id != -1:
            self.mac_ack_energy_mj += ack_energy
            self.battery.after_activity(ack_sender, self.engine.time)
        self.mac_ack_tx_frames += 1
        ack_tx = self.radio.start_transmission(ack_sender, self.engine.time, ack_bytes)
        self.engine.schedule(
            ack_tx.end_s,
            self._finalize_ack,
            ack_tx, data_sender, ack_sender, rx_e, success_callback, success_args,
            retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args,
        )

    def _finalize_ack(self, ack_tx, data_sender, ack_sender, rx_e, success_callback, success_args,
                      retry_callback, retry_args, reliability_attempt, exhausted_callback, exhausted_args):
        ack_payload = {"type": "mac_ack", "confidence": 0.0}
        success, _, rssi, reason = self.radio.resolve_receive(
            ack_tx, data_sender, ack_payload, 0.0, 0.0, rx_e, commit_payload=False
        )
        self._record_radio_resolution(ack_tx, data_sender)
        self.radio.finish_transmission(ack_tx)
        self.battery.after_activity(data_sender, self.engine.time)
        if success:
            self.mac_ack_rx_frames += 1
            success_callback(*success_args)
            return
        self.mac_ack_losses += 1
        if reason == "collision":
            self.mac_ack_collisions += 1
        elif reason == "channel_loss":
            self.mac_ack_channel_losses += 1
        elif reason == "below_sensitivity":
            self.mac_ack_below_sensitivity += 1
        self._retry_or_exhaust(
            data_sender, retry_callback, retry_args, reliability_attempt,
            exhausted_callback, exhausted_args,
        )

    # ------------------------------- routing -------------------------------
    def route_to_sink(self, sender, payload):
        """Route one packet to the sink over the packet-level medium model."""
        self.routing_packets += 1
        route = self.nominal_route_to_sink(sender)
        if not route or len(route) < 2:
            self.routing_no_route += 1
            return False
        routed_payload = dict(payload)
        routed_payload["_route_origin"] = int(sender.node_id)
        routed_payload["_route_hops"] = [int(n.node_id) for n in route]
        return self._enqueue_route_hop(route, 0, sender, routed_payload)

    def _enqueue_route_hop(self, route, hop_index, origin, payload):
        if hop_index >= len(route) - 1:
            return False
        sender = route[hop_index]
        return self._enqueue_mac_request(
            sender, self._execute_route_hop, (route, hop_index, origin, payload), kind="route"
        )

    def _execute_route_hop(self, route, hop_index, origin, payload, reliability_attempt=0, mac_attempt=0):
        sender, receiver = route[hop_index], route[hop_index + 1]
        if not self.battery.can_operate(sender, self.engine.time):
            self.routing_hops_failed += 1
            self._complete_mac_request(sender, "failure")
            return
        if receiver.node_id != -1 and not self.battery.can_operate(receiver, self.engine.time):
            self.routing_hops_failed += 1
            self._complete_mac_request(sender, "failure")
            return

        gate = self._mac_gate(
            sender,
            self._execute_route_hop,
            (route, hop_index, origin, payload, reliability_attempt),
            mac_attempt,
        )
        if gate <= 0:
            if gate < 0:
                self.routing_hops_failed += 1
                self._complete_mac_request(sender, "failure")
            return

        access_s, tx_base_s, tx_e, rx_e = self._radio_params()
        self.radio_controller.before_transmit(sender)
        self._charge_data_tx(sender, tx_e, reliability_attempt)
        self.routing_hops_attempted += 1
        tx = self.radio.start_transmission(sender, self.engine.time, self.radio_cfg.get("payload_bytes", 48))
        self.engine.schedule(
            tx.end_s, self._finalize_route_hop,
            tx, route, hop_index, origin, payload, receiver, access_s, tx_base_s, rx_e, reliability_attempt,
        )

    def _finalize_route_hop(self, tx, route, hop_index, origin, payload, receiver,
                            access_s, tx_base_s, rx_e, reliability_attempt):
        sender = route[hop_index]
        req = self._mac_request(sender) or {}
        commit = not bool(req.get("data_delivered", False))
        success, delay, rssi, reason = self.radio.resolve_receive(
            tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=commit
        )
        self._record_radio_resolution(tx, receiver)
        self._record_delivery_outcome(success, reason)
        if receiver.node_id != -1:
            self.battery.after_activity(receiver, self.engine.time)
        if success:
            if not commit:
                self.mac_duplicate_data_rx += 1
            else:
                # On the final hop the application has the DATA now, even if
                # the reverse ACK is later lost. Keep ACK-confirmed routing
                # completion as a separate transport/MAC outcome.
                if receiver.node_id == -1:
                    self.routing_sink_data_arrivals += 1
                    self.engine.schedule(max(self.engine.time, tx.start_s + delay), self.sink_receive, origin, payload)
            req["data_delivered"] = True
        else:
            self._count_failure(reason)
        self.radio_controller.after_transmit(sender, self._single_receiver_feedback(success, rssi, reason))
        self.radio.finish_transmission(tx)

        if not self._reliable_unicast_enabled():
            if success:
                self._route_hop_success(route, hop_index, origin, payload, delay)
            else:
                self.routing_hops_failed += 1
                self._complete_mac_request(sender, "failure")
            return

        if success:
            self._start_ack(
                sender, receiver,
                self._route_hop_success, (route, hop_index, origin, payload, delay),
                self._execute_route_hop, (route, hop_index, origin, payload), reliability_attempt,
                self._route_hop_exhausted, (route, hop_index),
            )
        else:
            self._retry_or_exhaust(
                sender, self._execute_route_hop, (route, hop_index, origin, payload), reliability_attempt,
                self._route_hop_exhausted, (route, hop_index),
            )

    def _route_hop_success(self, route, hop_index, origin, payload, delay):
        sender, receiver = route[hop_index], route[hop_index + 1]
        self.routing_hops_successful += 1
        self._complete_mac_request(sender)
        # ACK success marks completion of the reliable hop. The next hop may
        # contend immediately after this handshake; no second propagation delay
        # is added here because the DATA frame has already reached the receiver.
        delivery_time = self.engine.time
        if receiver.node_id == -1:
            self.routing_delivered += 1
            self.routing_total_hops_delivered += len(route) - 1
        else:
            self.engine.schedule(delivery_time, self._enqueue_route_hop, route, hop_index + 1, origin, payload)

    def _route_hop_exhausted(self, route, hop_index):
        sender = route[hop_index]
        self.routing_hops_failed += 1
        self._complete_mac_request(sender, "failure")

    # ------------------------------ broadcast ------------------------------
    def broadcast(self, sender, payload):
        return self._enqueue_mac_request(sender, self._execute_broadcast, (sender, payload), kind="broadcast")

    def _execute_broadcast(self, sender, payload, reliability_attempt=0, mac_attempt=0):
        if not self.battery.can_operate(sender, self.engine.time):
            self._complete_mac_request(sender)
            return
        gate = self._mac_gate(
            sender, self._execute_broadcast, (sender, payload, reliability_attempt), mac_attempt
        )
        if gate <= 0:
            if gate < 0:
                self._complete_mac_request(sender)
            return

        access_s, tx_base_s, tx_e, rx_e = self._radio_params()
        self.radio_controller.before_transmit(sender)
        receivers = self.communication_candidates(sender)
        relevant = self.feedback_receivers(sender, receivers)
        relevant_ids = {n.node_id for n in relevant}

        self._charge_data_tx(sender, tx_e, reliability_attempt)
        tx = self.radio.start_transmission(sender, self.engine.time, self.radio_cfg.get("payload_bytes", 48))
        self.engine.schedule(
            tx.end_s, self._finalize_broadcast,
            tx, sender, payload, receivers, relevant_ids, access_s, tx_base_s, rx_e,
        )

    def _finalize_broadcast(self, tx, sender, payload, receivers, relevant_ids, access_s, tx_base_s, rx_e):
        obs = []
        successes = collisions = below = channel_loss = 0
        for receiver in receivers:
            success, delay, rssi, reason = self.radio.resolve_receive(
                tx, receiver, payload, access_s, tx_base_s, rx_e
            )
            self._record_radio_resolution(tx, receiver)
            self._record_delivery_outcome(success, reason)
            self.battery.after_activity(receiver, self.engine.time)
            if success:
                delivery_time = max(self.engine.time, tx.start_s + delay)
                self.engine.schedule(delivery_time, self.receive, receiver, payload)
            else:
                self._count_failure(reason)

            if receiver.node_id in relevant_ids and rssi > -199:
                obs.append(rssi)
                if success:
                    successes += 1
                elif reason == "collision":
                    collisions += 1
                elif reason == "below_sensitivity":
                    below += 1
                elif reason == "channel_loss":
                    channel_loss += 1

        nobs = len(obs)
        denom = max(nobs, 1)
        feedback = {
            "observations": nobs,
            "relevant_receivers": len(relevant_ids),
            "mean_rssi_dbm": (sum(obs) / nobs) if nobs else None,
            "success_rate": successes / denom if nobs else 0.0,
            "collision_rate": collisions / denom if nobs else 0.0,
            "below_sensitivity_rate": below / denom if nobs else 0.0,
            "channel_loss_rate": channel_loss / denom if nobs else 0.0,
            "successes": successes,
            "collisions": collisions,
            "below_sensitivity": below,
            "channel_losses": channel_loss,
        }
        self.radio_controller.after_transmit(sender, feedback)
        self.radio.finish_transmission(tx)
        self._complete_mac_request(sender)

    # ---------------------------- direct unicast ----------------------------
    def send_to_sink(self, sender, payload):
        return self._enqueue_mac_request(sender, self._execute_send_to_sink, (sender, payload), kind="direct")

    def _execute_send_to_sink(self, sender, payload, reliability_attempt=0, mac_attempt=0):
        if not self.battery.can_operate(sender, self.engine.time):
            self._complete_mac_request(sender, "failure")
            return
        gate = self._mac_gate(
            sender, self._execute_send_to_sink, (sender, payload, reliability_attempt), mac_attempt
        )
        if gate <= 0:
            if gate < 0:
                self._complete_mac_request(sender, "failure")
            return

        access_s, tx_base_s, tx_e, rx_e = self._radio_params()
        self.radio_controller.before_transmit(sender)
        self._charge_data_tx(sender, tx_e, reliability_attempt)
        tx = self.radio.start_transmission(sender, self.engine.time, self.radio_cfg.get("payload_bytes", 48))
        self.engine.schedule(
            tx.end_s, self._finalize_send_to_sink,
            tx, sender, payload, access_s, tx_base_s, rx_e, reliability_attempt,
        )

    def _finalize_send_to_sink(self, tx, sender, payload, access_s, tx_base_s, rx_e, reliability_attempt):
        req = self._mac_request(sender) or {}
        commit = not bool(req.get("data_delivered", False))
        success, delay, rssi, reason = self.radio.resolve_receive(
            tx, self.sink, payload, access_s, tx_base_s, rx_e, commit_payload=commit
        )
        self._record_radio_resolution(tx, self.sink)
        self._record_delivery_outcome(success, reason)
        if success:
            if not commit:
                self.mac_duplicate_data_rx += 1
            else:
                # DATA has reached the sink now. Application delivery must not
                # depend on whether the reverse ACK is later received.
                self.engine.schedule(max(self.engine.time, tx.start_s + delay), self.sink_receive, sender, payload)
            req["data_delivered"] = True
        else:
            self._count_failure(reason)
        self.radio_controller.after_transmit(sender, self._single_receiver_feedback(success, rssi, reason))
        self.radio.finish_transmission(tx)

        if not self._reliable_unicast_enabled():
            if success:
                self._complete_mac_request(sender, "success")
            else:
                self._complete_mac_request(sender, "failure")
            return

        if success:
            self._start_ack(
                sender, self.sink,
                self._direct_unicast_success, (sender, payload),
                self._execute_send_to_sink, (sender, payload), reliability_attempt,
                self._direct_unicast_exhausted, (sender,),
            )
        else:
            self._retry_or_exhaust(
                sender, self._execute_send_to_sink, (sender, payload), reliability_attempt,
                self._direct_unicast_exhausted, (sender,),
            )

    def _direct_unicast_success(self, sender, payload):
        # DATA was already delivered to the sink before the ACK handshake.
        self._complete_mac_request(sender, "success")

    def _direct_unicast_exhausted(self, sender):
        self._complete_mac_request(sender, "failure")

    def sink_receive(self, sender, payload):
        if payload["confidence"] >= self.sensor_threshold and sender.first_alert_time is None:
            sender.first_alert_time = self.engine.time

    def receive(self, receiver, payload):
        if not self.battery.can_operate(receiver, self.engine.time):
            return
        self.policy.on_receive(receiver, payload)
        self.battery.after_activity(receiver, self.engine.time)

    def on_node_moved(self, node, old_position, new_position, distance_m):
        """Observation hook; TraceSimulator overrides this without changing core behavior."""
        return None

    def topology_snapshot(self):
        return topology_metrics(
            self.nodes,
            self.cfg["area_m"],
            self.cfg.get("sensing", {}).get("sensing_radius_m"),
            link_predicate=self.radio.nominal_link_available,
            link_margin_fn=self.radio.link_margin_db
        )

    def run(self):
        # Schedule mobility first so a movement at time t is visible to sensing/radio events at t.
        # For static mobility this schedules nothing, preserving previous behavior exactly.
        self.mobility.schedule()
        self.schedule_samples()
        self.engine.run(self.duration)
        if self.battery.enabled:
            self.battery.finalize(self.duration)
        else:
            # Preserve legacy accounting exactly in ideal/unlimited mode.
            idle_e = self.cfg["energy_mj"]["idle_per_s"] * self.duration
            for n in self.nodes:
                n.energy_idle += idle_e
        return self
