import math

def _mean(xs):
    return sum(xs) / len(xs) if xs else None

def _std(xs):
    if not xs:
        return None
    m = _mean(xs)
    return math.sqrt(sum((x-m)**2 for x in xs)/len(xs))

def _jain(xs):
    vals=[max(0.0,float(x)) for x in xs]
    if not vals or sum(v*v for v in vals) <= 0:
        return None
    return (sum(vals)**2)/(len(vals)*sum(v*v for v in vals))

def summarize(sim):
    nodes = sim.nodes
    total_energy = sum(n.total_energy for n in nodes)
    tx = sum(n.tx_count for n in nodes)
    rx = sum(n.rx_count for n in nodes)
    bytes_tx = sum(n.bytes_tx for n in nodes)

    tp = fp = fn = 0
    deadline_ok = 0
    actual_events = 0
    aware_true = 0
    false_aware = 0
    false_confirmed = 0

    detection_delays = []
    pre_event_local_detections = 0
    confirmation_delays = []
    alert_delays = []
    lead_times = []

    origin_errors = []
    speed_errors = []
    eta_errors = []

    for n in nodes:
        true_arrival = sim.world.arrival_time(n.position)
        truth = true_arrival <= sim.duration
        pred = n.detected

        if truth and pred:
            tp += 1
        elif (not truth) and pred:
            fp += 1
            false_confirmed += 1
        elif truth and (not pred):
            fn += 1

        aware = n.first_alert_time is not None
        if truth and aware:
            aware_true += 1
        elif (not truth) and aware:
            false_aware += 1

        if truth:
            actual_events += 1

            if n.first_detection_time is not None:
                dd = n.first_detection_time - true_arrival
                detection_delays.append(dd)
                if dd < 0:
                    pre_event_local_detections += 1

            if n.first_confirmation_time is not None:
                confirmation_delays.append(n.first_confirmation_time - true_arrival)

            if n.first_alert_time is not None:
                alert_delay = n.first_alert_time - true_arrival
                alert_delays.append(alert_delay)
                lead_times.append(true_arrival - n.first_alert_time)
                if n.first_alert_time <= true_arrival + sim.deadline_s:
                    deadline_ok += 1

        # Ground truth is used ONLY here, by evaluator metrics, never by D-STEP.
        if sim.policy_name in ("dstep", "dstep_payoff"):
            if n.est_origin is not None:
                origin_errors.append(math.dist(n.est_origin, sim.world.origin))
            if n.est_speed is not None:
                speed_errors.append(abs(n.est_speed - sim.world.speed))
            if n.est_origin is not None and n.est_speed is not None and n.est_t0 is not None:
                pred_arrival = n.est_t0 + math.dist(n.position, n.est_origin) / max(n.est_speed, 1e-9)
                eta_errors.append(abs(pred_arrival - true_arrival))

    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    dcr = deadline_ok / actual_events if actual_events else 0.0
    negative_nodes = len(nodes) - actual_events
    awareness_recall = aware_true / actual_events if actual_events else 0.0
    false_confirmation_rate = false_confirmed / negative_nodes if negative_nodes else 0.0
    false_awareness_rate = false_aware / negative_nodes if negative_nodes else 0.0
    network_false_alarm = 1 if negative_nodes and false_aware > 0 else 0
    event_level_confirmed = 1 if tp > 0 else 0
    event_level_alerted = 1 if aware_true > 0 else 0

    e_sense = sum(n.energy_sense for n in nodes)
    e_prep = sum(n.energy_preprocess for n in nodes)
    e_infer = sum(n.energy_infer for n in nodes)
    e_consensus = sum(n.energy_consensus for n in nodes)
    e_estimate = sum(n.energy_estimate for n in nodes)
    e_prediction = sum(n.energy_prediction for n in nodes)
    e_tx = sum(n.energy_tx for n in nodes)
    e_rx = sum(n.energy_rx for n in nodes)
    e_idle = sum(n.energy_idle for n in nodes)
    e_payoff = sum(getattr(n, "energy_payoff", 0.0) for n in nodes)
    suppressed_tx = sum(n.suppressed_tx_count for n in nodes)

    battery = sim.battery.summary(sim.duration) if hasattr(sim, "battery") else {"mode":"ideal","enabled":False}
    alive_nodes = sum(1 for n in nodes if getattr(n, "alive", True))
    dead_nodes = len(nodes) - alive_nodes
    remaining = [sim.battery.remaining_pct(n) for n in nodes] if battery.get("enabled") else []
    remaining = [x for x in remaining if x is not None]

    # Energy balance across nodes: high Jain index means the workload is shared
    # more evenly, reducing the risk of repeatedly exhausting the same relays.
    node_energy = [float(n.total_energy) for n in nodes]
    energy_mean = _mean(node_energy)
    energy_std = _std(node_energy)
    energy_cv = (energy_std / energy_mean) if energy_mean and energy_std is not None else None
    energy_jain = _jain(node_energy)
    residual_jain = _jain(remaining) if remaining else None

    delivery_attempts = int(getattr(sim, "link_delivery_attempts", 0))
    delivery_successes = int(getattr(sim, "link_delivery_successes", 0))
    delivery_failures = int(getattr(sim, "link_delivery_failures", 0))
    link_pdr = delivery_successes / delivery_attempts if delivery_attempts else None
    collision_loss_rate = sim.collisions / delivery_attempts if delivery_attempts else None
    channel_loss_rate = sim.channel_losses / delivery_attempts if delivery_attempts else None
    sensitivity_loss_rate = getattr(sim, "below_sensitivity", 0) / delivery_attempts if delivery_attempts else None
    out_of_range_rate = getattr(sim, "out_of_range", 0) / delivery_attempts if delivery_attempts else None

    sinr_samples = list(getattr(sim, "sinr_samples_db", []))
    mean_sinr = _mean(sinr_samples)
    min_sinr = min(sinr_samples) if sinr_samples else None

    queue_delays = list(getattr(sim, "mac_queue_delay_samples_s", []))
    service_times = list(getattr(sim, "mac_service_time_samples_s", []))
    mean_queue_delay = _mean(queue_delays)
    max_queue_delay = max(queue_delays) if queue_delays else None
    mean_service_time = _mean(service_times)
    max_service_time = max(service_times) if service_times else None

    tx_power_values = [n.tx_power_dbm for n in nodes]
    tx_power_hist = [p for n in nodes for p in n.tx_power_history]
    power_changes = sum(n.radio_power_changes for n in nodes)
    power_increases = sum(n.radio_power_increases for n in nodes)
    power_decreases = sum(n.radio_power_decreases for n in nodes)
    feedback_rssi = [n.last_feedback_rssi_dbm for n in nodes if n.last_feedback_rssi_dbm is not None]
    feedback_success = [n.last_feedback_success_rate for n in nodes if n.last_feedback_success_rate is not None]
    backoff_actions = sum(n.radio_backoff_actions for n in nodes)
    wait_actions = sum(n.radio_wait_actions for n in nodes)
    congestion_events = sum(n.radio_congestion_events for n in nodes)
    coverage_events = sum(n.radio_coverage_events for n in nodes)
    radio_channel_loss_events = sum(n.radio_channel_loss_events for n in nodes)

    return {
        "policy": sim.policy_name,
        "nodes": len(nodes),
        "tx_packets": tx,
        "rx_packets": rx,
        "bytes_tx": bytes_tx,
        "link_delivery_attempts": delivery_attempts,
        "link_delivery_successes": delivery_successes,
        "link_delivery_failures": delivery_failures,
        "link_pdr": round(link_pdr, 4) if link_pdr is not None else None,
        "collision_loss_rate": round(collision_loss_rate, 4) if collision_loss_rate is not None else None,
        "channel_loss_rate": round(channel_loss_rate, 4) if channel_loss_rate is not None else None,
        "sensitivity_loss_rate": round(sensitivity_loss_rate, 4) if sensitivity_loss_rate is not None else None,
        "out_of_range_loss_rate": round(out_of_range_rate, 4) if out_of_range_rate is not None else None,
        "energy_mj": round(total_energy, 4),
        "energy_payoff_mj": round(e_payoff, 4),
        "payoff_decisions": sum(getattr(n, "payoff_decisions", 0) for n in nodes),
        "payoff_compute_accepted": sum(getattr(n, "payoff_compute_accepted", 0) for n in nodes),
        "payoff_compute_rejected": sum(getattr(n, "payoff_compute_rejected", 0) for n in nodes),
        "payoff_transmit_accepted": sum(getattr(n, "payoff_transmit_accepted", 0) for n in nodes),
        "payoff_transmit_rejected": sum(getattr(n, "payoff_transmit_rejected", 0) for n in nodes),
        "payoff_optional_compute_skipped": sum(getattr(n, "payoff_optional_compute_skipped", 0) for n in nodes),
        "payoff_estimated_tx_energy_saved_mj": round(sum(getattr(n, "payoff_estimated_tx_energy_saved_mj", 0.0) for n in nodes), 4),
        "payoff_reliability_overrides": sum(getattr(n, "payoff_reliability_overrides", 0) for n in nodes),
        "energy_per_node_mean_mj": round(energy_mean, 4) if energy_mean is not None else None,
        "energy_per_node_std_mj": round(energy_std, 4) if energy_std is not None else None,
        "energy_cv": round(energy_cv, 4) if energy_cv is not None else None,
        "energy_jain_fairness": round(energy_jain, 4) if energy_jain is not None else None,
        "battery_residual_jain_fairness": round(residual_jain, 4) if residual_jain is not None else None,

        "energy_sense_mj": round(e_sense, 4),
        "energy_preprocess_mj": round(e_prep, 4),
        "energy_infer_mj": round(e_infer, 4),
        "energy_consensus_mj": round(e_consensus, 4),
        "energy_estimate_mj": round(e_estimate, 4),
        "energy_prediction_mj": round(e_prediction, 4),
        "energy_tx_mj": round(e_tx, 4),
        "energy_rx_mj": round(e_rx, 4),
        "energy_idle_mj": round(e_idle, 4),

        "battery_mode": battery.get("mode", "ideal"),
        "battery_capacity_mah": battery.get("capacity_mah"),
        "battery_voltage_v": battery.get("voltage_v"),
        "battery_initial_energy_mj_per_node": round(battery.get("initial_energy_mj_per_node"), 4) if battery.get("initial_energy_mj_per_node") is not None else None,
        "battery_alive_nodes": alive_nodes,
        "battery_dead_nodes": dead_nodes,
        "battery_mean_remaining_pct": round(_mean(remaining), 4) if remaining else None,
        "battery_fnd_time_s": battery.get("fnd_time_s"),
        "battery_hnd_time_s": battery.get("hnd_time_s"),
        "battery_lnd_time_s": battery.get("lnd_time_s"),
        "battery_mean_estimated_lifetime_s": round(battery.get("mean_estimated_lifetime_s"), 4) if battery.get("mean_estimated_lifetime_s") is not None else None,
        "battery_min_estimated_lifetime_s": round(battery.get("min_estimated_lifetime_s"), 4) if battery.get("min_estimated_lifetime_s") is not None else None,
        "battery_max_estimated_lifetime_s": round(battery.get("max_estimated_lifetime_s"), 4) if battery.get("max_estimated_lifetime_s") is not None else None,

        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "confirmation_precision": round(precision, 4),
        "confirmation_recall": round(recall, 4),
        "confirmation_f1": round(f1, 4),
        "awareness_recall": round(awareness_recall, 4),
        "false_confirmation_rate": round(false_confirmation_rate, 4),
        "false_awareness_rate": round(false_awareness_rate, 4),
        "network_false_alarm": network_false_alarm,
        "event_level_confirmed": event_level_confirmed,
        "event_level_alerted": event_level_alerted,
        "dcr": round(dcr, 4),

        "mean_detection_delay_s": round(_mean(detection_delays), 4) if detection_delays else None,
        "pre_event_local_detections": pre_event_local_detections,
        "mean_confirmation_delay_s": round(_mean(confirmation_delays), 4) if confirmation_delays else None,
        "mean_alert_delay_s": round(_mean(alert_delays), 4) if alert_delays else None,
        "mean_lead_time_s": round(_mean(lead_times), 4) if lead_times else None,

        "mean_origin_error_m": round(_mean(origin_errors), 4) if origin_errors else None,
        "mean_speed_error_m_s": round(_mean(speed_errors), 4) if speed_errors else None,
        "mean_eta_error_s": round(_mean(eta_errors), 4) if eta_errors else None,

        "collisions": sim.collisions,
        "channel_losses": sim.channel_losses,
        "below_sensitivity": getattr(sim, "below_sensitivity", 0),
        "suppressed_tx": suppressed_tx,
        "mac_mode": sim.cfg.get("mac", {}).get("mode", "none"),
        "mac_cca_busy": int(getattr(sim, "mac_cca_busy", 0)),
        "mac_backoff_events": int(getattr(sim, "mac_backoff_events", 0)),
        "mac_access_drops": int(getattr(sim, "mac_access_drops", 0)),
        "mac_queue_enabled": bool(sim.cfg.get("mac", {}).get("queue_enabled", True)),
        "mac_queue_capacity": int(sim.cfg.get("mac", {}).get("queue_capacity", 16)),
        "mac_queue_enqueued": int(getattr(sim, "mac_queue_enqueued", 0)),
        "mac_queue_drops": int(getattr(sim, "mac_queue_drops", 0)),
        "mac_max_queue_depth": int(getattr(sim, "mac_max_queue_depth", 0)),
        "mean_mac_queue_delay_s": round(mean_queue_delay, 6) if mean_queue_delay is not None else None,
        "max_mac_queue_delay_s": round(max_queue_delay, 6) if max_queue_delay is not None else None,
        "mean_mac_service_time_s": round(mean_service_time, 6) if mean_service_time is not None else None,
        "max_mac_service_time_s": round(max_service_time, 6) if max_service_time is not None else None,
        "mac_reliability_enabled": bool(sim.cfg.get("mac", {}).get("reliability", {}).get("enabled", True)),
        "mac_max_retries": int(sim.cfg.get("mac", {}).get("reliability", {}).get("max_retries", 3)),
        "mac_retry_tx_frames": int(getattr(sim, "mac_retry_tx_frames", 0)),
        "mac_retries_scheduled": int(getattr(sim, "mac_retries_scheduled", 0)),
        "mac_retry_exhausted": int(getattr(sim, "mac_retry_exhausted", 0)),
        "mac_ack_timeouts": int(getattr(sim, "mac_ack_timeouts", 0)),
        "mac_ack_tx_frames": int(getattr(sim, "mac_ack_tx_frames", 0)),
        "mac_ack_rx_frames": int(getattr(sim, "mac_ack_rx_frames", 0)),
        "mac_ack_losses": int(getattr(sim, "mac_ack_losses", 0)),
        "mac_ack_collisions": int(getattr(sim, "mac_ack_collisions", 0)),
        "mac_ack_channel_losses": int(getattr(sim, "mac_ack_channel_losses", 0)),
        "mac_ack_below_sensitivity": int(getattr(sim, "mac_ack_below_sensitivity", 0)),
        "mac_duplicate_data_rx": int(getattr(sim, "mac_duplicate_data_rx", 0)),
        "mac_retry_tx_energy_mj": round(float(getattr(sim, "mac_retry_tx_energy_mj", 0.0)), 6),
        "mac_ack_energy_mj": round(float(getattr(sim, "mac_ack_energy_mj", 0.0)), 6),
        "mac_unicast_frames_started": int(getattr(sim, "mac_unicast_frames_started", 0)),
        "mac_unicast_frames_success": int(getattr(sim, "mac_unicast_frames_success", 0)),
        "mac_unicast_frames_failed": int(getattr(sim, "mac_unicast_frames_failed", 0)),
        "mac_unicast_queue_drops": int(getattr(sim, "mac_unicast_queue_drops", 0)),
        "mac_unicast_delivery_ratio": round(
            getattr(sim, "mac_unicast_frames_success", 0) / max(
                getattr(sim, "mac_unicast_frames_success", 0)
                + getattr(sim, "mac_unicast_frames_failed", 0)
                + getattr(sim, "mac_unicast_queue_drops", 0), 1
            ), 4
        ) if (getattr(sim, "mac_unicast_frames_success", 0)
              + getattr(sim, "mac_unicast_frames_failed", 0)
              + getattr(sim, "mac_unicast_queue_drops", 0)) else None,
        # v0.40.1: ACK-confirmed completion is not the same as DATA arrival.
        "mac_unicast_confirmed_delivery_ratio": round(
            getattr(sim, "mac_unicast_frames_success", 0) / max(
                getattr(sim, "mac_unicast_frames_success", 0)
                + getattr(sim, "mac_unicast_frames_failed", 0)
                + getattr(sim, "mac_unicast_queue_drops", 0), 1
            ), 4
        ) if (getattr(sim, "mac_unicast_frames_success", 0)
              + getattr(sim, "mac_unicast_frames_failed", 0)
              + getattr(sim, "mac_unicast_queue_drops", 0)) else None,
        "mac_unicast_data_frames_received": int(getattr(sim, "mac_unicast_data_frames_received", 0)),
        "mac_unicast_data_delivery_ratio": round(
            getattr(sim, "mac_unicast_data_frames_received", 0) / max(
                getattr(sim, "mac_unicast_frames_success", 0)
                + getattr(sim, "mac_unicast_frames_failed", 0)
                + getattr(sim, "mac_unicast_queue_drops", 0), 1
            ), 4
        ) if (getattr(sim, "mac_unicast_frames_success", 0)
              + getattr(sim, "mac_unicast_frames_failed", 0)
              + getattr(sim, "mac_unicast_queue_drops", 0)) else None,
        "mac_reliable_frames_started": int(getattr(sim, "mac_reliable_frames_started", 0)),
        "mac_reliable_frames_success": int(getattr(sim, "mac_reliable_frames_success", 0)),
        "mac_reliable_frames_failed": int(getattr(sim, "mac_reliable_frames_failed", 0)),
        "mac_reliable_queue_drops": int(getattr(sim, "mac_reliable_queue_drops", 0)),
        "mac_reliable_delivery_ratio": round(
            getattr(sim, "mac_reliable_frames_success", 0) / max(
                getattr(sim, "mac_reliable_frames_success", 0)
                + getattr(sim, "mac_reliable_frames_failed", 0)
                + getattr(sim, "mac_reliable_queue_drops", 0), 1
            ), 4
        ) if (getattr(sim, "mac_reliable_frames_success", 0)
              + getattr(sim, "mac_reliable_frames_failed", 0)
              + getattr(sim, "mac_reliable_queue_drops", 0)) else None,
        "mac_reliable_data_frames_received": int(getattr(sim, "mac_reliable_data_frames_received", 0)),
        "mac_reliable_data_delivery_ratio": round(
            getattr(sim, "mac_reliable_data_frames_received", 0) / max(
                getattr(sim, "mac_reliable_frames_success", 0)
                + getattr(sim, "mac_reliable_frames_failed", 0)
                + getattr(sim, "mac_reliable_queue_drops", 0), 1
            ), 4
        ) if (getattr(sim, "mac_reliable_frames_success", 0)
              + getattr(sim, "mac_reliable_frames_failed", 0)
              + getattr(sim, "mac_reliable_queue_drops", 0)) else None,
        "mac_pending_requests": int(len(getattr(sim, "mac_active_requests", {})) + sum(
            len(q) for q in getattr(sim, "mac_queues", {}).values()
        )),
        "physical_link_pdr_per_attempt": round(link_pdr, 4) if link_pdr is not None else None,
        "physical_tx_frames": int(tx + getattr(sim, "mac_ack_tx_frames", 0)),
        "interfered_receptions": int(getattr(sim, "interfered_receptions", 0)),
        "mean_sinr_db": round(mean_sinr, 4) if mean_sinr is not None else None,
        "min_sinr_db": round(min_sinr, 4) if min_sinr is not None else None,
        "radio_control_mode": sim.cfg.get("radio_control", {}).get("mode", "fixed"),
        "mean_tx_power_dbm": round(_mean(tx_power_values), 4) if tx_power_values else None,
        "min_tx_power_dbm": round(min(tx_power_values), 4) if tx_power_values else None,
        "max_tx_power_dbm": round(max(tx_power_values), 4) if tx_power_values else None,
        "mean_power_history_dbm": round(_mean(tx_power_hist), 4) if tx_power_hist else None,
        "power_changes": power_changes,
        "power_increases": power_increases,
        "power_decreases": power_decreases,
        "mean_feedback_rssi_dbm": round(_mean(feedback_rssi), 4) if feedback_rssi else None,
        "mean_feedback_success_rate": round(_mean(feedback_success), 4) if feedback_success else None,
        "radio_backoff_actions": backoff_actions,
        "radio_wait_actions": wait_actions,
        "radio_congestion_events": congestion_events,
        "radio_coverage_events": coverage_events,
        "radio_channel_loss_events": radio_channel_loss_events,
        "communication_architecture": getattr(sim, "communication_architecture", "distributed"),
        "routing_packets": getattr(sim, "routing_packets", 0),
        "routing_sink_data_arrivals": int(getattr(sim, "routing_sink_data_arrivals", 0)),
        "routing_delivered": getattr(sim, "routing_delivered", 0),
        "routing_no_route": getattr(sim, "routing_no_route", 0),
        "routing_hops_attempted": getattr(sim, "routing_hops_attempted", 0),
        "routing_hops_successful": getattr(sim, "routing_hops_successful", 0),
        "routing_hops_failed": getattr(sim, "routing_hops_failed", 0),
        "mean_route_hops_delivered": round(
            getattr(sim, "routing_total_hops_delivered", 0) / max(getattr(sim, "routing_delivered", 0), 1), 4
        ) if getattr(sim, "routing_delivered", 0) else None,
    }
