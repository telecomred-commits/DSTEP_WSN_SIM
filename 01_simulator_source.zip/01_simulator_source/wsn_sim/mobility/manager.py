import math
import random


class MobilityManager:
    """Time-stepped, optional mobility layer for WSN nodes.

    Supported models:
      - static
      - linear
      - random_walk
      - random_waypoint

    Positions are updated in-place on Node objects, so every existing radio,
    neighbor, routing and sensing calculation automatically sees the current
    geometry without coupling those layers to mobility.
    """

    MODELS = {"static", "linear", "random_walk", "random_waypoint"}

    def __init__(self, simulator):
        self.sim = simulator
        cfg = dict(simulator.cfg.get("mobility") or {})
        self.model = str(cfg.get("model", "static")).strip().lower()
        if self.model not in self.MODELS:
            raise ValueError(f"Unknown mobility model: {self.model}")

        self.speed_m_s = max(0.0, float(cfg.get("speed_m_s", 0.0)))
        self.update_interval_s = max(0.01, float(cfg.get("update_interval_s", 0.5)))
        self.direction_change_interval_s = max(
            self.update_interval_s, float(cfg.get("direction_change_interval_s", 5.0))
        )
        self.direction_deg = float(cfg.get("direction_deg", 0.0))
        self.mobile_fraction = min(1.0, max(0.0, float(cfg.get("mobile_fraction", 1.0))))
        self.boundary = str(cfg.get("boundary", "reflect")).strip().lower()
        if self.boundary not in {"reflect", "clamp"}:
            raise ValueError(f"Unknown mobility boundary mode: {self.boundary}")

        self.rng = random.Random(simulator.seed + 500009)
        self.area_w, self.area_h = map(float, simulator.cfg["area_m"])
        self.initial_positions = {n.node_id: tuple(n.position) for n in simulator.nodes}
        self.distance_by_node = {n.node_id: 0.0 for n in simulator.nodes}
        self.headings = {}
        self.next_direction_change = {}
        self.waypoints = {}
        self.mobile_ids = self._select_mobile_nodes()
        self._initialize_states()

    @property
    def enabled(self):
        return self.model != "static" and self.speed_m_s > 0.0 and bool(self.mobile_ids)

    def _select_mobile_nodes(self):
        nodes = list(self.sim.nodes)
        if self.mobile_fraction >= 1.0:
            return {n.node_id for n in nodes}
        count = int(round(len(nodes) * self.mobile_fraction))
        if self.mobile_fraction > 0.0 and count == 0 and nodes:
            count = 1
        ids = [n.node_id for n in nodes]
        self.rng.shuffle(ids)
        return set(ids[:count])

    def _random_heading(self):
        a = self.rng.uniform(0.0, 2.0 * math.pi)
        return (math.cos(a), math.sin(a))

    def _random_waypoint(self):
        return (self.rng.uniform(0.0, self.area_w), self.rng.uniform(0.0, self.area_h))

    def _initialize_states(self):
        linear_angle = math.radians(self.direction_deg)
        linear_heading = (math.cos(linear_angle), math.sin(linear_angle))
        for n in self.sim.nodes:
            if n.node_id not in self.mobile_ids:
                continue
            if self.model == "linear":
                self.headings[n.node_id] = linear_heading
            elif self.model == "random_walk":
                self.headings[n.node_id] = self._random_heading()
                self.next_direction_change[n.node_id] = self.direction_change_interval_s
            elif self.model == "random_waypoint":
                self.waypoints[n.node_id] = self._random_waypoint()

    def schedule(self):
        if not self.enabled:
            return
        t = self.update_interval_s
        while t <= self.sim.duration + 1e-12:
            self.sim.engine.schedule(t, self._update_all, t)
            t += self.update_interval_s

    def _reflect_axis(self, value, delta, maximum):
        new = value + delta
        sign = 1.0
        # Handles steps longer than the area dimension without allowing escape.
        while new < 0.0 or new > maximum:
            if new < 0.0:
                new = -new
                sign *= -1.0
            elif new > maximum:
                new = 2.0 * maximum - new
                sign *= -1.0
        return min(max(new, 0.0), maximum), sign

    def _move_heading(self, node, heading, distance):
        x, y = map(float, node.position)
        dx, dy = heading[0] * distance, heading[1] * distance
        if self.boundary == "clamp":
            nx = min(self.area_w, max(0.0, x + dx))
            ny = min(self.area_h, max(0.0, y + dy))
            return (nx, ny), heading
        nx, sx = self._reflect_axis(x, dx, self.area_w)
        ny, sy = self._reflect_axis(y, dy, self.area_h)
        return (nx, ny), (heading[0] * sx, heading[1] * sy)

    def _move_waypoint(self, node, distance):
        x, y = map(float, node.position)
        remaining = distance
        target = self.waypoints[node.node_id]
        # Consume a long step across multiple waypoints if necessary.
        for _ in range(32):
            dx, dy = target[0] - x, target[1] - y
            d = math.hypot(dx, dy)
            if d > remaining and d > 1e-12:
                x += dx / d * remaining
                y += dy / d * remaining
                remaining = 0.0
                break
            x, y = target
            remaining -= d
            target = self._random_waypoint()
            self.waypoints[node.node_id] = target
            if remaining <= 1e-12:
                break
        return (min(self.area_w, max(0.0, x)), min(self.area_h, max(0.0, y)))

    def _update_all(self, scheduled_time):
        dt = min(self.update_interval_s, max(0.0, self.sim.duration - (scheduled_time - self.update_interval_s)))
        distance = self.speed_m_s * dt
        if distance <= 0.0:
            return
        for node in self.sim.nodes:
            if node.node_id not in self.mobile_ids:
                continue
            old = tuple(node.position)
            if self.model == "random_waypoint":
                new = self._move_waypoint(node, distance)
            else:
                heading = self.headings[node.node_id]
                if self.model == "random_walk" and scheduled_time + 1e-12 >= self.next_direction_change[node.node_id]:
                    heading = self._random_heading()
                    self.next_direction_change[node.node_id] += self.direction_change_interval_s
                new, heading = self._move_heading(node, heading, distance)
                self.headings[node.node_id] = heading
            node.position = tuple(new)
            moved = math.dist(old, node.position)
            self.distance_by_node[node.node_id] += moved
            self.sim.on_node_moved(node, old, node.position, moved)

    def summary(self):
        distances = list(self.distance_by_node.values())
        moved = [d for d in distances if d > 1e-12]
        return {
            "model": self.model,
            "enabled": self.enabled,
            "speed_m_s": self.speed_m_s,
            "update_interval_s": self.update_interval_s,
            "direction_change_interval_s": self.direction_change_interval_s,
            "direction_deg": self.direction_deg,
            "boundary": self.boundary,
            "mobile_fraction": self.mobile_fraction,
            "mobile_nodes": len(self.mobile_ids) if self.enabled else 0,
            "total_distance_m": sum(distances),
            "mean_distance_mobile_m": (sum(moved) / len(moved)) if moved else 0.0,
        }
