"""Optional node mobility models.

Mobility is deliberately isolated from the radio, routing and policy layers.
When disabled (the default), the simulator follows the legacy static path.
"""

from .manager import MobilityManager

__all__ = ["MobilityManager"]
