class BatteryManager:
    """Optional finite-battery accounting.

    Legacy/ideal mode is a no-op so previous scientific results are preserved.
    In battery mode, the existing per-component energy counters remain the
    source of truth; this manager converts the initial mAh/voltage budget to mJ,
    settles idle energy lazily, and marks nodes dead when their budget is spent.
    """
    def __init__(self, sim):
        self.sim = sim
        cfg = dict(sim.cfg.get("battery") or {})
        self.mode = str(cfg.get("mode", "ideal")).strip().lower()
        self.enabled = self.mode == "battery"
        self.capacity_mah = float(cfg.get("capacity_mah", 2000.0))
        self.voltage_v = float(cfg.get("voltage_v", 3.7))
        self.initial_soc = max(0.0, min(1.0, float(cfg.get("initial_soc", 1.0))))
        self.initial_energy_mj = self.capacity_mah * self.voltage_v * 3600.0 * self.initial_soc
        self.fnd_time_s = None
        self.hnd_time_s = None
        self.lnd_time_s = None
        self._dead_count = 0

        for n in sim.nodes:
            n.battery_mode = self.mode
            n.battery_capacity_mah = self.capacity_mah
            n.battery_voltage_v = self.voltage_v
            n.battery_initial_mj = self.initial_energy_mj if self.enabled else None
            n.battery_last_account_s = 0.0
            n.alive = True
            n.death_time_s = None

    def _settle_idle(self, node, now):
        if not self.enabled or not node.alive:
            return
        now = max(float(now), float(node.battery_last_account_s))
        dt = now - float(node.battery_last_account_s)
        if dt > 0:
            node.energy_idle += float(self.sim.cfg["energy_mj"]["idle_per_s"]) * dt
            node.battery_last_account_s = now

    def _mark_if_depleted(self, node, now):
        if not self.enabled or not node.alive:
            return not getattr(node, "alive", True)
        if node.total_energy + 1e-12 < node.battery_initial_mj:
            return False
        node.alive = False
        node.death_time_s = float(now)
        node.state = "DEAD"
        self._dead_count += 1
        if self.fnd_time_s is None:
            self.fnd_time_s = float(now)
        half = (len(self.sim.nodes) + 1) // 2
        if self.hnd_time_s is None and self._dead_count >= half:
            self.hnd_time_s = float(now)
        if self._dead_count >= len(self.sim.nodes):
            self.lnd_time_s = float(now)
        return True

    def can_operate(self, node, now):
        if not self.enabled:
            return True
        self._settle_idle(node, now)
        self._mark_if_depleted(node, now)
        return bool(node.alive)

    def after_activity(self, node, now):
        if not self.enabled:
            return
        self._mark_if_depleted(node, now)

    def finalize(self, now):
        if not self.enabled:
            return
        for n in self.sim.nodes:
            self._settle_idle(n, now)
            self._mark_if_depleted(n, now)

    def remaining_mj(self, node):
        if not self.enabled:
            return None
        return max(0.0, float(node.battery_initial_mj) - float(node.total_energy))

    def remaining_pct(self, node):
        if not self.enabled or not node.battery_initial_mj:
            return None
        return max(0.0, min(100.0, 100.0 * self.remaining_mj(node) / node.battery_initial_mj))

    def estimated_lifetime_s(self, node, observation_s):
        if not self.enabled:
            return None
        obs = max(float(observation_s), 1e-12)
        consumed = float(node.total_energy)
        if consumed <= 0:
            return None
        avg_power_mw = consumed / obs  # mJ/s == mW
        return float(node.battery_initial_mj) / avg_power_mw if avg_power_mw > 0 else None

    def summary(self, observation_s):
        if not self.enabled:
            return {"mode": "ideal", "enabled": False}
        lifetimes = [self.estimated_lifetime_s(n, observation_s) for n in self.sim.nodes]
        lifetimes = [x for x in lifetimes if x is not None]
        return {
            "mode": "battery",
            "enabled": True,
            "capacity_mah": self.capacity_mah,
            "voltage_v": self.voltage_v,
            "initial_soc_pct": self.initial_soc * 100.0,
            "initial_energy_mj_per_node": self.initial_energy_mj,
            "alive_nodes": sum(1 for n in self.sim.nodes if n.alive),
            "dead_nodes": sum(1 for n in self.sim.nodes if not n.alive),
            "fnd_time_s": self.fnd_time_s,
            "hnd_time_s": self.hnd_time_s,
            "lnd_time_s": self.lnd_time_s,
            "mean_estimated_lifetime_s": (sum(lifetimes) / len(lifetimes)) if lifetimes else None,
            "min_estimated_lifetime_s": min(lifetimes) if lifetimes else None,
            "max_estimated_lifetime_s": max(lifetimes) if lifetimes else None,
        }
