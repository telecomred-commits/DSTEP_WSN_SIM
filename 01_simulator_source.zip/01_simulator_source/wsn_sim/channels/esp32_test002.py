"""ESP32/ESP-NOW TEST002 calibrated channel.

This channel separates two stochastic scales observed in the real two-ESP32
campaign:

* a *persistent* directed-link shadow term, drawn once per ordered node pair
  for a simulation realization; and
* a packet-to-packet Gaussian term, drawn independently for every frame.

The propagation mean is still log-distance.  Packet decoding probability is
handled by :class:`wsn_sim.radio.model.RadioModel` through the calibrated
logistic sensitivity curve stored in the radio profile.

Scope: this is an empirical system-level model calibrated from TEST002 at
1/10/20/25/30 m, 48-byte ESP-NOW payloads, channel 6, commanded maximum TX
power 80 qdBm (=20 dBm).  It is not a complete 802.11/ESP-NOW PHY model.
"""

from .log_distance import LogDistanceChannel


class ESP32Test002Channel(LogDistanceChannel):
    name = "esp32_test002"

    def __init__(self, cfg, rng):
        super().__init__(cfg, rng)
        self._link_shadow_db = {}

    def _link_key(self, tx, rx):
        """Return a stable key for the shadow realization of one link."""
        tx_id = getattr(tx, "node_id", None)
        rx_id = getattr(rx, "node_id", None)
        if tx_id is None:
            tx_id = ("pos", tuple(round(float(v), 9) for v in tx.position))
        if rx_id is None:
            rx_id = ("pos", tuple(round(float(v), 9) for v in rx.position))
        if self.cfg.get("static_shadow_reciprocal", False):
            # repr-based sorting handles mixed int/tuple identifiers safely.
            return tuple(sorted((tx_id, rx_id), key=repr))
        return (tx_id, rx_id)

    def persistent_shadow_db(self, tx, rx):
        key = self._link_key(tx, rx)
        if key not in self._link_shadow_db:
            sigma = max(0.0, float(self.cfg.get("link_shadow_sigma_db", 0.0)))
            self._link_shadow_db[key] = self.rng.gauss(0.0, sigma) if sigma else 0.0
        return self._link_shadow_db[key]

    def mean_link_adjustment_db(self, tx, rx):
        """Persistent per-link term used by nominal link-budget diagnostics."""
        return self.persistent_shadow_db(tx, rx)

    def shadowing_db(self, tx, rx):
        # Persistent geometry/link realization.
        return self.persistent_shadow_db(tx, rx)

    def fading_db(self, tx, rx):
        # Fast packet-to-packet variation inferred from the censored RSSI/PDR fit.
        sigma = max(
            0.0,
            float(self.cfg.get("shadow_sigma_db", self.cfg.get("fast_fading_sigma_db", 0.0))),
        )
        return self.rng.gauss(0.0, sigma) if sigma else 0.0
