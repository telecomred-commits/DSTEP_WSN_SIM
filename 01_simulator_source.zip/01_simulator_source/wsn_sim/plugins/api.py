"""Public algorithm-plugin API for WSN Edge-AI Simulator.

A user plugin subclasses AlgorithmPlugin. The plugin receives a NodeContext instead
of the Simulator object so algorithms use a small, stable surface.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass

ALGORITHM_API_VERSION = "1.0"


@dataclass(frozen=True)
class NeighborView:
    node_id: int
    position: tuple


class NodeContext:
    """Stable per-node interface exposed to external algorithms."""
    def __init__(self, sim, node):
        self._sim = sim
        self._node = node

    @property
    def time(self):
        return float(self._sim.engine.time)

    @property
    def node_id(self):
        return int(self._node.node_id)

    @property
    def position(self):
        return tuple(self._node.position)

    @property
    def energy_mj(self):
        return float(self._node.total_energy)

    @property
    def tx_count(self):
        return int(self._node.tx_count)

    @property
    def rx_count(self):
        return int(self._node.rx_count)

    @property
    def messages_received(self):
        return tuple(dict(m) for m in self._node.messages_received)

    def neighbors(self):
        return tuple(NeighborView(int(n.node_id), tuple(n.position)) for n in self._sim.neighbors(self._node))

    def send(self, message):
        """Use the communication architecture selected by the researcher."""
        return self._sim.send_application(self._node, dict(message))

    def broadcast(self, message):
        return self._sim.broadcast(self._node, dict(message))

    def send_to_sink(self, message):
        return self._sim.send_to_sink(self._node, dict(message))

    def route_to_sink(self, message):
        return self._sim.route_to_sink(self._node, dict(message))

    def set_tx_power(self, power_dbm):
        return self._sim.set_node_tx_power(self._node, float(power_dbm))

    def mark_detected(self):
        """Declare a local event detection produced by the external algorithm."""
        self._node.detected = True
        if self._node.first_detection_time is None:
            self._node.first_detection_time = self.time

    def mark_alert(self):
        """Declare that this node has raised/acted on an alert."""
        self.mark_detected()
        if self._node.first_alert_time is None:
            self._node.first_alert_time = self.time


class AlgorithmPlugin(ABC):
    """Base class implemented by researcher-provided Python algorithms."""
    INFO = {
        "name": "Unnamed algorithm",
        "version": "0.1",
        "api_version": ALGORITHM_API_VERSION,
        "description": "",
        "compatible_architectures": ["distributed", "direct_to_sink", "multi_hop_to_sink"],
    }
    PARAMETERS = {}
    uses_local_inference = False

    def __init__(self, parameters=None):
        self.parameters = dict(parameters or {})

    @abstractmethod
    def on_sample(self, ctx: NodeContext, value: float, confidence: float):
        ...

    def on_receive(self, ctx: NodeContext, message: dict):
        pass
