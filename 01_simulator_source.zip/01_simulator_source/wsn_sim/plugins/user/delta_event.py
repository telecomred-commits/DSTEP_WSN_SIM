"""Example external algorithm: transmit only a significant event change."""
from wsn_sim.plugins.api import AlgorithmPlugin


class DeltaEvent(AlgorithmPlugin):
    INFO = {
        "name": "Delta Event",
        "version": "1.0",
        "api_version": "1.0",
        "description": "Transmits when the sample is above threshold and changed enough since the previous report.",
        "compatible_architectures": ["distributed", "direct_to_sink", "multi_hop_to_sink"],
    }
    PARAMETERS = {
        "threshold": {"type": "float", "default": 0.55},
        "min_delta": {"type": "float", "default": 0.12},
    }
    uses_local_inference = False

    def __init__(self, parameters=None):
        super().__init__(parameters)
        self.threshold = float(self.parameters.get("threshold", 0.55))
        self.min_delta = float(self.parameters.get("min_delta", 0.12))
        self.last_sent = {}

    def on_sample(self, ctx, value, confidence):
        previous = self.last_sent.get(ctx.node_id)
        changed = previous is None or abs(value - previous) >= self.min_delta
        if value >= self.threshold:
            ctx.mark_detected()
        if value >= self.threshold and changed:
            ctx.mark_alert()
            ctx.send({"type": "delta_event", "confidence": confidence, "value": value, "time": ctx.time})
            self.last_sent[ctx.node_id] = value


ALGORITHM_CLASS = DeltaEvent
