from __future__ import annotations
import importlib.util
import re
from pathlib import Path
from .api import AlgorithmPlugin, NodeContext, ALGORITHM_API_VERSION

USER_PLUGIN_DIR = Path(__file__).resolve().parent / "user"
PLUGIN_PREFIX = "plugin:"


def _slug(filename):
    return re.sub(r"[^a-zA-Z0-9_]+", "_", Path(filename).stem).strip("_").lower()


def _load_module(path: Path):
    slug = _slug(path.name)
    spec = importlib.util.spec_from_file_location(f"wsn_user_plugin_{slug}", path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load plugin: {path.name}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _plugin_class(module):
    cls = getattr(module, "ALGORITHM_CLASS", None)
    if cls is None:
        candidates = [v for v in module.__dict__.values() if isinstance(v, type) and issubclass(v, AlgorithmPlugin) and v is not AlgorithmPlugin]
        if len(candidates) != 1:
            raise ValueError("Plugin must define ALGORITHM_CLASS or exactly one AlgorithmPlugin subclass")
        cls = candidates[0]
    if not isinstance(cls, type) or not issubclass(cls, AlgorithmPlugin):
        raise ValueError("ALGORITHM_CLASS must subclass AlgorithmPlugin")
    return cls


def validate_plugin_file(path: Path):
    module = _load_module(path)
    cls = _plugin_class(module)
    info = dict(getattr(cls, "INFO", {}) or {})
    if str(info.get("api_version", ALGORITHM_API_VERSION)) != ALGORITHM_API_VERSION:
        raise ValueError(f"Unsupported plugin API version: {info.get('api_version')}")
    arch = info.get("compatible_architectures", ["distributed", "direct_to_sink", "multi_hop_to_sink"])
    allowed = {"distributed", "direct_to_sink", "multi_hop_to_sink"}
    if not arch or not set(arch).issubset(allowed):
        raise ValueError("compatible_architectures contains an unknown architecture")
    return cls, info


def discover_plugins():
    USER_PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
    out = {}
    for path in sorted(USER_PLUGIN_DIR.glob("*.py")):
        if path.name.startswith("_"):
            continue
        try:
            cls, info = validate_plugin_file(path)
            slug = _slug(path.name)
            out[f"{PLUGIN_PREFIX}{slug}"] = {
                "id": f"{PLUGIN_PREFIX}{slug}",
                "file": path.name,
                "name": info.get("name", slug),
                "version": info.get("version", "0.1"),
                "description": info.get("description", ""),
                "compatible_architectures": info.get("compatible_architectures", ["distributed", "direct_to_sink", "multi_hop_to_sink"]),
                "uses_local_inference": bool(getattr(cls, "uses_local_inference", False)),
                "parameters": dict(getattr(cls, "PARAMETERS", {}) or {}),
                "valid": True,
            }
        except Exception as exc:
            slug = _slug(path.name)
            out[f"{PLUGIN_PREFIX}{slug}"] = {"id": f"{PLUGIN_PREFIX}{slug}", "file": path.name, "name": slug, "valid": False, "error": str(exc), "compatible_architectures": []}
    return out


def plugin_metadata(policy_id):
    return discover_plugins().get(policy_id)


class PluginPolicyAdapter:
    def __init__(self, sim, plugin_cls, parameters=None):
        self.sim = sim
        self.plugin = plugin_cls(parameters or {})
        self.name = getattr(plugin_cls, "INFO", {}).get("name", plugin_cls.__name__)
        self.uses_local_inference = bool(getattr(plugin_cls, "uses_local_inference", False))

    def on_sample(self, node, value, confidence):
        return self.plugin.on_sample(NodeContext(self.sim, node), value, confidence)

    def on_receive(self, node, message):
        return self.plugin.on_receive(NodeContext(self.sim, node), message)


def load_plugin_policy(sim, policy_id):
    meta = plugin_metadata(policy_id)
    if not meta:
        raise ValueError(f"Unknown algorithm plugin: {policy_id}")
    if not meta.get("valid"):
        raise ValueError(f"Invalid algorithm plugin {policy_id}: {meta.get('error')}")
    path = USER_PLUGIN_DIR / meta["file"]
    module = _load_module(path)
    cls = _plugin_class(module)
    slug = policy_id.split(":", 1)[1]
    params = sim.cfg.get("plugin_parameters", {}).get(slug, {})
    return PluginPolicyAdapter(sim, cls, params)
