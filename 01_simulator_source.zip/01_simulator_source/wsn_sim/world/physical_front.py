import math


class AttenuatingRadialEvent:
    """Physically parameterized propagating pulse/front.

    The hidden event front expands radially at a fixed speed.  A sensor receives
    no deterministic signal before physical arrival; after the front reaches
    the sensor, signal magnitude decays exponentially with distance travelled
    beyond that sensor.  Sensor noise and detector behavior remain outside this
    world model and are applied by ``Simulator.sensor_value``.
    """
    def __init__(self, origin, start_time_s, speed_m_s, radius_max_m,
                 peak_intensity=1.0, attenuation_per_m=0.035):
        self.origin = tuple(origin)
        self.start_time = float(start_time_s)
        self.speed = float(speed_m_s)
        self.radius_max = float(radius_max_m)
        self.peak_intensity = float(peak_intensity)
        self.attenuation_per_m = max(0.0, float(attenuation_per_m))

    def distance(self, position):
        return math.dist(position, self.origin)

    def arrival_time(self, position):
        d = self.distance(position)
        if d > self.radius_max:
            return math.inf
        return self.start_time + d / max(self.speed, 1e-12)

    def intensity(self, position, time):
        if time < self.start_time:
            return 0.0
        d = self.distance(position)
        front = min((time - self.start_time) * self.speed, self.radius_max)
        if d > front or d > self.radius_max:
            return 0.0
        trail = max(0.0, front - d)
        return max(0.0, min(1.0, self.peak_intensity * math.exp(-self.attenuation_per_m * trail)))


class NullEvent:
    """Explicit event-absent ground truth for false-positive stress tests."""
    def __init__(self):
        self.origin = (0.0, 0.0)
        self.start_time = math.inf
        self.speed = 1.0
        self.radius_max = 0.0

    def arrival_time(self, position):
        return math.inf

    def intensity(self, position, time):
        return 0.0
