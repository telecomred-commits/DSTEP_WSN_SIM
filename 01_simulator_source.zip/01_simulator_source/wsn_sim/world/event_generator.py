import math
import random
from .radial_event import RadialEvent
from .physical_front import AttenuatingRadialEvent, NullEvent

ALLOWED_EVENT_MODELS = {"deterministic", "stochastic", "spatial_risk", "physical_pulse", "absent"}

def _positive_range(a, b, floor=1e-9):
    lo, hi = sorted((max(floor, float(a)), max(floor, float(b))))
    return lo, hi

def _bounded_gaussian(rng, mean, sigma, lo, hi):
    sigma = max(1e-9, float(sigma))
    for _ in range(64):
        x = rng.gauss(float(mean), sigma)
        if lo <= x <= hi:
            return x
    return min(hi, max(lo, float(mean)))

def realize_event(cfg, area_m, seed):
    """Create one hidden ground-truth event for a simulation run.

    Uses a dedicated RNG stream so changing event generation does not perturb
    topology, sensing, channel, mobility, or control randomness.
    """
    ecfg = dict(cfg or {})
    model = str(ecfg.get("model", "deterministic")).strip().lower()
    if model not in ALLOWED_EVENT_MODELS:
        raise ValueError(f"Unknown event model: {model}")

    w, h = map(float, area_m)
    rng = random.Random(int(seed) + 500009)

    if model == "absent":
        event = NullEvent()
        event.generator_model = model
        event.ground_truth = {"model": model, "event_present": False, "seed": int(seed)}
        return event

    if model in ("deterministic", "physical_pulse"):
        origin = tuple(map(float, ecfg.get("origin", [w/2, h/2])))
        start = float(ecfg.get("start_time_s", 5.0))
        speed = max(1e-9, float(ecfg.get("speed_m_s", 8.0)))
        radius = max(0.0, float(ecfg.get("radius_max_m", max(w, h))))
    else:
        start_lo, start_hi = sorted((
            max(0.0, float(ecfg.get("start_min_s", 1.0))),
            max(0.0, float(ecfg.get("start_max_s", 10.0))),
        ))
        speed_lo, speed_hi = _positive_range(
            ecfg.get("speed_min_m_s", 2.0), ecfg.get("speed_max_m_s", 12.0)
        )
        radius_lo, radius_hi = sorted((
            max(0.0, float(ecfg.get("radius_min_m", min(w, h) * 0.5))),
            max(0.0, float(ecfg.get("radius_max_m_stochastic", max(w, h) * 1.5))),
        ))
        start = rng.uniform(start_lo, start_hi)
        speed = rng.uniform(speed_lo, speed_hi)
        radius = rng.uniform(radius_lo, radius_hi)

        margin = max(0.0, float(ecfg.get("origin_margin_m", 0.0)))
        xlo, xhi = min(margin, w/2), max(w-min(margin, w/2), min(margin, w/2))
        ylo, yhi = min(margin, h/2), max(h-min(margin, h/2), min(margin, h/2))

        if model == "spatial_risk":
            center = ecfg.get("risk_center", [w/2, h/2])
            cx = min(w, max(0.0, float(center[0])))
            cy = min(h, max(0.0, float(center[1])))
            sigma = max(0.1, float(ecfg.get("risk_sigma_m", min(w, h) * 0.2)))
            ox = _bounded_gaussian(rng, cx, sigma, xlo, xhi)
            oy = _bounded_gaussian(rng, cy, sigma, ylo, yhi)
        else:
            ox = rng.uniform(xlo, xhi)
            oy = rng.uniform(ylo, yhi)
        origin = (ox, oy)

    if model == "physical_pulse":
        event = AttenuatingRadialEvent(
            origin=origin, start_time_s=start, speed_m_s=speed, radius_max_m=radius,
            peak_intensity=float(ecfg.get("peak_intensity", 1.0)),
            attenuation_per_m=float(ecfg.get("attenuation_per_m", 0.035)),
        )
    else:
        event = RadialEvent(
            origin=origin, start_time_s=start, speed_m_s=speed, radius_max_m=radius,
        )
    event.generator_model = model
    event.ground_truth = {
        "model": model,
        "origin": [float(origin[0]), float(origin[1])],
        "start_time_s": float(start),
        "speed_m_s": float(speed),
        "radius_max_m": float(radius),
        "seed": int(seed),
        "event_present": True,
        "peak_intensity": float(ecfg.get("peak_intensity", 1.0)) if model == "physical_pulse" else None,
        "attenuation_per_m": float(ecfg.get("attenuation_per_m", 0.035)) if model == "physical_pulse" else None,
    }
    return event
