import math
from dataclasses import dataclass, field
from itertools import count
from wsn_sim.channels.factory import create_channel


@dataclass
class Transmission:
    """One physical frame occupying the medium over a real airtime interval."""
    tx_id: int
    sender: object
    start_s: float
    end_s: float
    payload_bytes: int
    tx_power_dbm: float
    rssi_cache: dict = field(default_factory=dict)
    resolved: bool = False


class RadioModel:
    def __init__(self, cfg, rng):
        self.cfg = cfg
        self.rng = rng
        self.channel = create_channel(cfg.get("channel_model", "log_normal"), cfg, rng)
        self._tx_ids = count(1)
        self.transmissions = []
        self.last_resolution_meta = {}

    def rssi(self, distance_m):
        class P:
            def __init__(self, x):
                self.position = (x, 0.0)
        return self.channel.rssi_dbm(P(0.0), P(max(distance_m, 1e-9)))

    def tx_power_dbm(self, sender):
        return float(getattr(sender, "tx_power_dbm", self.cfg.get("tx_power_dbm", 0.0)))

    def mean_rssi(self, a, b):
        return (
            self.tx_power_dbm(a)
            - self.channel.path_loss_db(a, b)
            + self.channel.mean_link_adjustment_db(a, b)
        )

    def instantaneous_rssi(self, a, b):
        return (
            self.tx_power_dbm(a)
            - self.channel.path_loss_db(a, b)
            + self.channel.shadowing_db(a, b)
            + self.channel.fading_db(a, b)
        )

    def receiver_sensitivity_dbm(self):
        return self.cfg.get("receiver_sensitivity_dbm", self.cfg.get("rssi_midpoint_dbm", -82.0))

    def link_margin_db(self, a, b):
        return self.mean_rssi(a, b) - self.receiver_sensitivity_dbm()

    def nominal_link_available(self, a, b):
        d = math.dist(a.position, b.position)
        mode = self.cfg.get("connectivity_mode", "geometric")
        if mode == "geometric":
            return d <= self.cfg.get("neighbor_radius_m", float("inf"))
        cap = self.cfg.get("max_geometric_range_m")
        if cap is not None and d > float(cap):
            return False
        return self.link_margin_db(a, b) >= 0.0

    def candidate_receiver(self, a, b):
        d = math.dist(a.position, b.position)
        if self.cfg.get("connectivity_mode", "geometric") == "geometric":
            return d <= self.cfg.get("neighbor_radius_m", float("inf"))
        cap = self.cfg.get("max_geometric_range_m")
        return cap is None or d <= float(cap)

    def success_probability(self, rssi_dbm):
        midpoint = self.receiver_sensitivity_dbm()
        slope = self.cfg.get("sensitivity_slope", self.cfg.get("rssi_slope", 0.18))
        return 1.0 / (1.0 + math.exp(-slope * (rssi_dbm - midpoint)))

    def packet_airtime_s(self, payload_bytes=None):
        payload_bytes = int(payload_bytes if payload_bytes is not None else self.cfg.get("payload_bytes", 48))
        phy = self.cfg.get("phy", "linear")
        reps = max(1, int(self.cfg.get("repetitions", 1)))
        if phy == "lora":
            sf = int(self.cfg.get("lora_sf", 7))
            bw = float(self.cfg.get("lora_bw_hz", 125000.0))
            cr = int(self.cfg.get("lora_cr", 1))
            preamble = float(self.cfg.get("lora_preamble_symbols", 8))
            crc = 1 if self.cfg.get("lora_crc", True) else 0
            ih = 1 if self.cfg.get("lora_implicit_header", False) else 0
            de = 1 if self.cfg.get("lora_low_data_rate_optimize", sf >= 11 and bw <= 125000) else 0
            tsym = (2 ** sf) / bw
            tpreamble = (preamble + 4.25) * tsym
            denom = 4 * max(1, sf - 2 * de)
            payload_sym = 8 + max(
                math.ceil((8 * payload_bytes - 4 * sf + 28 + 16 * crc - 20 * ih) / denom) * (cr + 4), 0
            )
            return reps * (tpreamble + payload_sym * tsym)
        overhead = int(self.cfg.get("phy_overhead_bytes", 0))
        return reps * ((payload_bytes + overhead) * 8.0 / float(self.cfg.get("bitrate_bps", 250000)))

    def packet_delay_s(self, distance_m, payload_bytes, access_s, tx_base_s):
        return access_s + tx_base_s + self.packet_airtime_s(payload_bytes) + distance_m / 3e8

    def _nearest_current_ma(self, table, power_dbm):
        pts = [(float(k), float(v)) for k, v in table.items()]
        return min(pts, key=lambda kv: abs(kv[0] - power_dbm))[1] if pts else None

    def current_based_tx_energy_mj(self, sender, payload_bytes=None):
        table = self.cfg.get("tx_current_by_power_ma", {})
        if not table:
            return None
        current = self._nearest_current_ma(table, self.tx_power_dbm(sender))
        return float(self.cfg.get("supply_voltage_v", 3.3)) * current * self.packet_airtime_s(payload_bytes)

    def current_based_rx_energy_mj(self, payload_bytes=None):
        cur = self.cfg.get("rx_current_ma")
        if cur is None:
            return None
        return float(self.cfg.get("supply_voltage_v", 3.3)) * float(cur) * self.packet_airtime_s(payload_bytes)

    def within_range(self, a, b):
        return self.nominal_link_available(a, b)

    def tx_energy_for_power(self, sender, default_tx_energy, payload_bytes=None):
        payload_bytes = int(payload_bytes if payload_bytes is not None else self.cfg.get("payload_bytes", 48))
        if self.cfg.get("energy_model") == "current_airtime":
            val = self.current_based_tx_energy_mj(sender, payload_bytes)
            if val is not None:
                return val
        table = self.cfg.get("tx_energy_by_power_mj", {})
        if not table:
            base_payload = max(1, int(self.cfg.get("payload_bytes", 48)))
            if payload_bytes == base_payload:
                return default_tx_energy
            return default_tx_energy * self.packet_airtime_s(payload_bytes) / max(self.packet_airtime_s(base_payload), 1e-12)
        p = self.tx_power_dbm(sender)
        pts = [(float(k), float(v)) for k, v in table.items()]
        _, energy = min(pts, key=lambda kv: abs(kv[0] - p))
        base_payload = max(1, int(self.cfg.get("payload_bytes", 48)))
        if payload_bytes != base_payload:
            energy *= self.packet_airtime_s(payload_bytes) / max(self.packet_airtime_s(base_payload), 1e-12)
        return energy

    def charge_tx_frame(self, sender, tx_energy, payload_bytes=None, count_data=True):
        payload_bytes = int(payload_bytes if payload_bytes is not None else self.cfg.get("payload_bytes", 48))
        if count_data:
            sender.tx_count += 1
            sender.bytes_tx += payload_bytes
        sender.energy_tx += self.tx_energy_for_power(sender, tx_energy, payload_bytes)

    # ------------------------------------------------------------------
    # v0.39 packet-level medium model
    # ------------------------------------------------------------------
    def start_transmission(self, sender, now, payload_bytes=None):
        """Register a frame on the medium until its actual airtime expires."""
        # Do not discard ended frames here. An ended frame may still be needed
        # when resolving a later-ending frame that overlapped it earlier.
        # Garbage collection is performed only after frame resolution, once no
        # unresolved overlapping transmission can still require the record.
        payload_bytes = int(payload_bytes if payload_bytes is not None else self.cfg.get("payload_bytes", 48))
        airtime = self.packet_airtime_s(payload_bytes)
        tx = Transmission(
            tx_id=next(self._tx_ids),
            sender=sender,
            start_s=float(now),
            end_s=float(now) + airtime,
            payload_bytes=payload_bytes,
            tx_power_dbm=self.tx_power_dbm(sender),
        )
        self.transmissions.append(tx)
        return tx

    @staticmethod
    def transmissions_overlap(a, b):
        return a.start_s < b.end_s and b.start_s < a.end_s

    @staticmethod
    def _dbm_to_mw(dbm):
        return 10.0 ** (float(dbm) / 10.0)

    @staticmethod
    def _ratio_to_db(ratio):
        return 10.0 * math.log10(max(float(ratio), 1e-30))

    def received_power_dbm(self, tx, receiver):
        rid = int(receiver.node_id)
        if rid not in tx.rssi_cache:
            tx.rssi_cache[rid] = (
                float(tx.tx_power_dbm)
                - self.channel.path_loss_db(tx.sender, receiver)
                + self.channel.shadowing_db(tx.sender, receiver)
                + self.channel.fading_db(tx.sender, receiver)
            )
        return tx.rssi_cache[rid]

    def overlapping_transmissions(self, tx):
        return [other for other in self.transmissions if other.tx_id != tx.tx_id and self.transmissions_overlap(tx, other)]

    def finish_transmission(self, tx):
        """Mark a frame resolved and safely garbage-collect medium history.

        An ended frame is retained while any unresolved frame overlaps it. This
        prevents staggered overlaps from disappearing before the later-ending
        frame is resolved.
        """
        tx.resolved = True
        unresolved = [t for t in self.transmissions if not t.resolved]
        kept = []
        for frame in self.transmissions:
            if not frame.resolved:
                kept.append(frame)
                continue
            if any(self.transmissions_overlap(frame, other) for other in unresolved):
                kept.append(frame)
        self.transmissions = kept

    def channel_busy(self, listener, now):
        """CCA-lite: busy only when an active signal is detectable by this node.

        This naturally permits hidden terminals: two senders may each see IDLE
        while their frames still overlap at a common receiver.
        """
        mac = self.cfg.get("mac", {}) or {}
        if str(mac.get("mode", "none")).lower() in ("none", "off", "disabled"):
            return False
        threshold = float(mac.get("cca_threshold_dbm", -82.0))
        for tx in self.transmissions:
            if tx.start_s <= now < tx.end_s:
                if tx.sender.node_id == listener.node_id:
                    return True
                if self.received_power_dbm(tx, listener) >= threshold:
                    return True
        return False

    def _charge_rx_attempt(self, receiver, rx_energy, payload_bytes=None):
        """Charge radio receive energy for an attempted frame, successful or not."""
        payload_bytes = int(payload_bytes if payload_bytes is not None else self.cfg.get("payload_bytes", 48))
        dyn_rx = self.current_based_rx_energy_mj(payload_bytes) if self.cfg.get("energy_model") == "current_airtime" else None
        if dyn_rx is not None:
            receiver.energy_rx += dyn_rx
        else:
            base_payload = max(1, int(self.cfg.get("payload_bytes", 48)))
            scaled = rx_energy * self.packet_airtime_s(payload_bytes) / max(self.packet_airtime_s(base_payload), 1e-12)
            receiver.energy_rx += scaled

    def resolve_receive(self, tx, receiver, payload, access_s, tx_base_s, rx_energy, commit_payload=True):
        """Resolve a reception after all overlapping transmissions are known."""
        if not self.candidate_receiver(tx.sender, receiver):
            self.last_resolution_meta[(tx.tx_id, receiver.node_id)] = {"sinr_db": None, "interferers": 0}
            return False, 0.0, -200.0, "out_of_range"

        d = math.dist(tx.sender.position, receiver.position)
        rssi = self.received_power_dbm(tx, receiver)
        sensitivity = self.receiver_sensitivity_dbm()
        delay = self.packet_delay_s(d, tx.payload_bytes, access_s, tx_base_s)

        if self.cfg.get("use_hard_sensitivity_cutoff", True) and rssi < sensitivity:
            # Below-sensitivity listening is represented by the idle/listen budget.
            # Incremental per-frame RX energy begins once the signal is strong
            # enough for a receive/decode attempt.
            self.last_resolution_meta[(tx.tx_id, receiver.node_id)] = {"sinr_db": None, "interferers": 0}
            return False, delay, rssi, "below_sensitivity"

        # Once a frame crosses sensitivity, receive energy is spent even when
        # interference, collision or channel error prevents successful decoding.
        self._charge_rx_attempt(receiver, rx_energy, tx.payload_bytes)

        interferers = self.overlapping_transmissions(tx)
        interference_mw = 0.0
        active_interferers = 0
        for other in interferers:
            p_dbm = self.received_power_dbm(other, receiver)
            interference_mw += self._dbm_to_mw(p_dbm)
            active_interferers += 1

        noise_floor_dbm = float(self.cfg.get("noise_floor_dbm", -100.0))
        noise_mw = self._dbm_to_mw(noise_floor_dbm)
        desired_mw = self._dbm_to_mw(rssi)
        sinr_db = self._ratio_to_db(desired_mw / (noise_mw + interference_mw))
        sinr_threshold_db = float(self.cfg.get("sinr_threshold_db", 6.0))

        self.last_resolution_meta[(tx.tx_id, receiver.node_id)] = {
            "sinr_db": sinr_db,
            "interferers": active_interferers,
        }

        # Interference/collision is now based on actual packet overlap and SINR.
        # Strong-packet capture is represented naturally when SINR remains above
        # the decoding threshold in spite of an overlapping weaker frame.
        if active_interferers and sinr_db < sinr_threshold_db:
            return False, delay, rssi, "collision"

        p = self.success_probability(rssi)
        success = self.rng.random() < p
        if success and commit_payload:
            receiver.rx_count += 1
            receiver.messages_received.append(payload)
        return success, delay, rssi, "ok" if success else "channel_loss"

    # Legacy synchronous API retained for plugins/tests that call RadioModel
    # directly. The Simulator v0.39 path uses start_transmission/resolve_receive.
    def attempt_receive(self, sender, receiver, payload, access_s, tx_base_s, rx_energy, now):
        tx = self.start_transmission(sender, now, self.cfg.get("payload_bytes", 48))
        result = self.resolve_receive(tx, receiver, payload, access_s, tx_base_s, rx_energy)
        self.finish_transmission(tx)
        return result
