RADIO_PROFILES = {
    "custom": {
        "label": "Custom / Generic",
        "technology": "generic",
        "evidence": "user_defined",
        "radio": {}
    },
    "esp_now_experimental": {
        "label": "ESP-NOW / ESP32 (experimental calibration)",
        "technology": "esp_now",
        "evidence": "experimentally_calibrated",
        "source_note": "User-provided ESP measurements used in simulator calibration",
        "radio": {
            "frequency_mhz": 2400.0,
            "tx_power_dbm": 0.0,
            "receiver_sensitivity_dbm": -90.0,
            "rssi_midpoint_dbm": -82.0,
            "sensitivity_slope": 0.35,
            "rssi_slope": 0.18,
            "bitrate_bps": 250000,
            "payload_bytes": 48,
            "phy": "linear",
            "phy_overhead_bytes": 0,
            "channel_model": "log_normal",
            "connectivity_mode": "link_budget",
            "use_hard_sensitivity_cutoff": True,
            "d0_m": 1.0,
            "pl_d0_db": 40.0,
            "path_loss_exponent": 2.2,
            "shadow_sigma_db": 2.0,
            "noise_floor_dbm": -100.0,
            "sinr_threshold_db": 6.0,
            "energy_model": "calibrated_packet_table",
            "tx_energy_by_power_mj": {"-10":0.31185,"0":0.41580,"10":0.58212,"20":0.99792},
        }
    },
    "esp_now_test002_real": {
        "label": "ESP-NOW / ESP32 DevKit TEST002 (real calibrated)",
        "technology": "esp_now",
        "evidence": "externally_calibrated_real_hardware",
        "source_note": (
            "TEST002 real two-ESP32 campaign: 15,000 DATA transmissions at "
            "1/10/20/25/30 m; Runs 1-2 calibration, Run 3 held-out validation. "
            "TX power command 80 qdBm = 20 dBm; channel 6; 48-byte payload; no application retries."
        ),
        "radio": {
            "frequency_mhz": 2400.0,
            "tx_power_dbm": 20.0,
            "receiver_sensitivity_dbm": -92.0968286968,
            "rssi_midpoint_dbm": -92.0968286968,
            "sensitivity_slope": 1.1242559347,
            "rssi_slope": 1.1242559347,
            "bitrate_bps": 1000000,
            "payload_bytes": 48,
            "phy": "linear",
            "phy_overhead_bytes": 43,
            "channel_model": "esp32_test002",
            "connectivity_mode": "link_budget",
            "use_hard_sensitivity_cutoff": False,
            "d0_m": 1.0,
            "pl_d0_db": 80.0333395827,
            "path_loss_exponent": 2.2395444914,
            "link_shadow_sigma_db": 5.4107865204,
            "fast_fading_sigma_db": 3.4081073263,
            "shadow_sigma_db": 3.4081073263,
            "static_shadow_reciprocal": False,
            "noise_floor_dbm": -100.0,
            "sinr_threshold_db": 6.0,
            "energy_model": "calibrated_packet_table",
            "tx_energy_by_power_mj": {"-10":0.31185,"0":0.41580,"10":0.58212,"20":0.99792},
            "calibration_scope": "TEST002 static two-node DATA/PDR/RSSI; ACK timing remains a separate validation layer",
        }
    },
    "lora_sx1262": {
        "label": "LoRa / Semtech SX1262 (datasheet)",
        "technology": "lora",
        "evidence": "datasheet_based",
        "source_note": "Semtech SX1262 official product/datasheet values",
        "radio": {
            "frequency_mhz": 915.0,
            "tx_power_dbm": 14.0,
            "receiver_sensitivity_dbm": -137.0,
            "payload_bytes": 48,
            "energy_model": "current_airtime",
            "supply_voltage_v": 3.3,
            "rx_current_ma": 4.6,
            "tx_current_by_power_ma": {"14":45.0,"22":118.0},
            "phy": "lora",
            "lora_sf": 12,
            "lora_bw_hz": 125000,
            "lora_cr": 1,
            "lora_preamble_symbols": 8,
            "lora_crc": True,
            "lora_implicit_header": False,
            "lora_low_data_rate_optimize": True,
            "bitrate_bps": 293.0,
        }
    },
    "ble_nrf52840": {
        "label": "Bluetooth LE / Nordic nRF52840 (datasheet)",
        "technology": "ble",
        "evidence": "datasheet_based",
        "source_note": "Nordic nRF52840 Product Specification",
        "radio": {
            "frequency_mhz": 2400.0,
            "tx_power_dbm": 0.0,
            "receiver_sensitivity_dbm": -95.0,
            "payload_bytes": 48,
            "bitrate_bps": 1000000,
            "energy_model": "current_airtime",
            "supply_voltage_v": 3.0,
            "rx_current_ma": 4.6,
            "tx_current_by_power_ma": {"0":4.8},
            "phy": "linear",
            "phy_overhead_bytes": 10,
            "repetitions": 1,
        }
    },
    "zigbee_cc2652r": {
        "label": "Zigbee / IEEE 802.15.4 / TI CC2652R (datasheet)",
        "technology": "zigbee_802154",
        "evidence": "datasheet_based",
        "source_note": "Texas Instruments CC2652R official datasheet/product page",
        "radio": {
            "frequency_mhz": 2400.0,
            "tx_power_dbm": 0.0,
            "receiver_sensitivity_dbm": -100.0,
            "payload_bytes": 48,
            "bitrate_bps": 250000,
            "energy_model": "current_airtime",
            "supply_voltage_v": 3.0,
            "rx_current_ma": 6.9,
            "tx_current_by_power_ma": {"0":7.0,"5":9.2},
            "phy": "linear",
            "phy_overhead_bytes": 17,
            "repetitions": 1,
        }
    },
    "sigfox_stm32wl_rc4": {
        "label": "Sigfox 0G RC4 / STM32WL55 (datasheet + protocol)",
        "technology": "sigfox",
        "evidence": "datasheet_plus_protocol",
        "source_note": "STM32WL55 radio electrical data + Sigfox RC4 600 bit/s protocol parameters",
        "radio": {
            "frequency_mhz": 920.8,
            "tx_power_dbm": 20.0,
            "receiver_sensitivity_dbm": -123.0,
            "payload_bytes": 12,
            "bitrate_bps": 600,
            "energy_model": "current_airtime",
            "supply_voltage_v": 3.0,
            "rx_current_ma": 4.82,
            "tx_current_by_power_ma": {"10":15.0,"20":87.0},
            "phy": "linear",
            "phy_overhead_bytes": 12,
            "repetitions": 3,
            "protocol_note": "RC4 supports 600 bit/s; 3-burst diversity retained as conservative default and is user-editable."
        }
    },
}


def apply_radio_profile(cfg):
    name = cfg.get("radio_profile", "custom")
    profile = RADIO_PROFILES.get(name)
    if profile is None:
        raise ValueError(f"Unknown radio_profile: {name}")
    merged = dict(cfg)
    # Profile defaults are applied first; explicit config values remain authoritative.
    defaults = profile.get("radio", {})
    for k, v in defaults.items():
        if k not in merged or merged.get(k) is None:
            merged[k] = v
    merged["radio_profile"] = name
    merged["profile_technology"] = profile.get("technology")
    merged["profile_evidence"] = profile.get("evidence")
    merged["profile_source_note"] = profile.get("source_note")
    return merged
