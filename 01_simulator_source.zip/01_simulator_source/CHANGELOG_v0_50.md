# v0.50 — Research candidate

- Freezes v0.49 risk-adaptive independent quorum after development tuning.
- Freezes false-consensus target at 0.02 and local fast-path threshold at 0.851.
- Adds cached risk-quorum computation for campaign performance.
- Preserves legacy F1 semantics and adds explicit confirmation/awareness metrics.
- Adds event-absent false-confirmation rate, false-awareness rate, and network false-alarm incidence.
- Adds a formal development/hold-out seed freeze.
