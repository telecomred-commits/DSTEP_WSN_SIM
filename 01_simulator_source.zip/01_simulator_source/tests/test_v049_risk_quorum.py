import json
from pathlib import Path
from wsn_sim.simulator import Simulator
ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_risk_quorum_enabled():
    c=cfg(); assert c['dstep_payoff']['risk_adaptive_quorum']['enabled'] is True

def test_dense_degree_requires_more_than_legacy_two_neighbors():
    c=cfg(); s=Simulator(c,100,'dstep_payoff',1)
    n=max(s.nodes,key=lambda x:s.policy._degree(x)); q,_,_=s.policy._confirmation_rule(n,0.7)
    if s.policy._degree(n) >= 8: assert q >= 3
