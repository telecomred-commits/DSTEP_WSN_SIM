import csv
from pathlib import Path
import gui_server


def _payload(mode, workers):
    return {
        'base_payload': {'node_count': 4, 'seed': 1234, 'policy': 'event_driven', 'positions': None,
            'config': {'simulation_time_s': .5, 'area_m':[100,100], 'sink_position':[50,50],
             'communication': {'architecture':'distributed','routing':{'strategy':'shortest_hop','max_hops':32}},
             'radio': {'radio_profile':'esp_now_experimental','channel_model':'log_normal'},
             'environment': {'profile':'custom','channel_model':'log_normal'}, 'topology': {'placement':'uniform_random'}}},
        'matrix': {'node_counts':[4,5], 'areas':[[100,100]], 'policies':['periodic','event_driven'],
                   'channels':['log_normal'], 'radios':['esp_now_experimental'], 'repetitions':2,
                   'seed_base':9400, 'architecture_mode':'auto', 'execution_mode':mode, 'workers':workers}}


def _rows(root, cid):
    with (Path(root)/cid/'campaign_results.csv').open(newline='', encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    for r in rows:
        r.pop('campaign_id', None)
    return rows


def test_parallel_and_sequential_campaigns_are_identical(tmp_path, monkeypatch):
    seq=tmp_path/'seq'; par=tmp_path/'par'; seq.mkdir(); par.mkdir()
    monkeypatch.setattr(gui_server,'CAMPAIGNS_ROOT',seq)
    a=gui_server.run_campaign(_payload('sequential',1))
    assert a['status']=='completed' and a['failed_runs']==0
    seq_rows=_rows(seq,a['id'])
    monkeypatch.setattr(gui_server,'CAMPAIGNS_ROOT',par)
    b=gui_server.run_campaign(_payload('parallel_cpu',2))
    assert b['status']=='completed' and b['failed_runs']==0
    par_rows=_rows(par,b['id'])
    assert seq_rows == par_rows


def test_auto_workers_are_conservative():
    _, perf=gui_server._campaign_cases(_payload('parallel_cpu','auto'))
    assert perf['workers'] >= 1
    assert perf['workers'] <= 8
    assert perf['workers'] <= perf['logical_cpus']
