import copy
import json
from pathlib import Path

from wsn_sim.plugins.loader import discover_plugins, load_plugin_policy
from wsn_sim.simulator import Simulator

ROOT = Path(__file__).resolve().parents[1]


def cfg():
    return json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def test_example_plugin_is_discovered():
    plugins = discover_plugins()
    assert "plugin:delta_event" in plugins
    assert plugins["plugin:delta_event"]["valid"] is True
    assert "distributed" in plugins["plugin:delta_event"]["compatible_architectures"]


def test_example_plugin_runs_with_existing_engine():
    c = cfg()
    c["simulation_time_s"] = 4.0
    c["period_s"] = 1.0
    c["communication"] = {"architecture":"distributed", "routing":{"strategy":"shortest_hop","max_hops":8}}
    c["plugin_parameters"] = {"delta_event":{"threshold":0.55,"min_delta":0.12}}
    sim = Simulator(c, 5, "plugin:delta_event", 1234)
    sim.run()
    assert sim.policy.name == "Delta Event"
    assert sum(n.tx_count for n in sim.nodes) >= 0


def test_plugin_can_use_multihop_architecture():
    c = cfg()
    c["simulation_time_s"] = 2.0
    c["communication"] = {"architecture":"multi_hop_to_sink", "routing":{"strategy":"shortest_hop","max_hops":8}}
    sim = Simulator(c, 5, "plugin:delta_event", 1234)
    assert sim.communication_architecture == "multi_hop_to_sink"
