import gui_server


def test_resource_preflight_auto_uses_safe_limit(monkeypatch):
    snap={'logical_cpus':16,'cpu_percent':20.0,'ram_total_bytes':16*1024**3,'ram_available_bytes':8*1024**3,
          'ram_total_gb':16.0,'ram_available_gb':8.0,'ram_available_pct':50.0,'disk_free_bytes':50*1024**3,'disk_free_gb':50.0,
          'platform':'Test','platform_release':'1'}
    monkeypatch.setattr(gui_server,'resource_snapshot',lambda:snap)
    pf=gui_server.resource_preflight(100,'auto','parallel_cpu')
    assert pf['status']=='good'
    assert 1 <= pf['effective_workers'] <= 8
    assert pf['effective_workers']==pf['safe_workers']


def test_resource_preflight_blocks_unsafe_manual_workers(monkeypatch):
    snap={'logical_cpus':16,'cpu_percent':80.0,'ram_total_bytes':8*1024**3,'ram_available_bytes':2*1024**3,
          'ram_total_gb':8.0,'ram_available_gb':2.0,'ram_available_pct':25.0,'disk_free_bytes':50*1024**3,'disk_free_gb':50.0,
          'platform':'Test','platform_release':'1'}
    monkeypatch.setattr(gui_server,'resource_snapshot',lambda:snap)
    pf=gui_server.resource_preflight(100,8,'parallel_cpu')
    assert pf['status']=='blocked'
    assert pf['safe_workers'] < 8


def test_resource_preflight_blocks_critical_ram(monkeypatch):
    snap={'logical_cpus':8,'cpu_percent':10.0,'ram_total_bytes':8*1024**3,'ram_available_bytes':300*1024**2,
          'ram_total_gb':8.0,'ram_available_gb':0.29,'ram_available_pct':3.7,'disk_free_bytes':50*1024**3,'disk_free_gb':50.0,
          'platform':'Test','platform_release':'1'}
    monkeypatch.setattr(gui_server,'resource_snapshot',lambda:snap)
    pf=gui_server.resource_preflight(100,'auto','parallel_cpu')
    assert pf['status']=='blocked'
