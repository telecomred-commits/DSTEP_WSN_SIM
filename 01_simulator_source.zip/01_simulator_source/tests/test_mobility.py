import copy
import json
from pathlib import Path

from wsn_sim.simulator import Simulator


def base_config():
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "config.json").read_text())
    cfg["simulation_time_s"] = 2.0
    cfg["period_s"] = 1.0
    return cfg


def test_static_mobility_preserves_positions():
    cfg = base_config()
    sim = Simulator(cfg, 5, "dstep", 1234)
    initial = [n.position for n in sim.nodes]
    sim.run()
    assert [n.position for n in sim.nodes] == initial
    assert sim.mobility.summary()["enabled"] is False


def test_linear_mobility_moves_nodes_at_configured_speed():
    cfg = base_config()
    cfg["mobility"] = {
        "model": "linear", "speed_m_s": 1.0, "update_interval_s": 0.5,
        "direction_change_interval_s": 5.0, "direction_deg": 0.0,
        "mobile_fraction": 1.0, "boundary": "reflect",
    }
    sim = Simulator(cfg, 3, "dstep", 1234)
    initial = [n.position for n in sim.nodes]
    sim.run()
    assert [n.position for n in sim.nodes] != initial
    assert abs(sim.mobility.summary()["mean_distance_mobile_m"] - 2.0) < 1e-9


def test_random_models_are_seed_reproducible():
    for model in ("random_walk", "random_waypoint"):
        cfg = base_config()
        cfg["mobility"] = {
            "model": model, "speed_m_s": 1.25, "update_interval_s": 0.5,
            "direction_change_interval_s": 1.0, "direction_deg": 0.0,
            "mobile_fraction": 1.0, "boundary": "reflect",
        }
        a = Simulator(copy.deepcopy(cfg), 5, "dstep", 99).run()
        b = Simulator(copy.deepcopy(cfg), 5, "dstep", 99).run()
        assert [n.position for n in a.nodes] == [n.position for n in b.nodes]
        assert all(0 <= n.position[0] <= cfg["area_m"][0] and 0 <= n.position[1] <= cfg["area_m"][1] for n in a.nodes)
