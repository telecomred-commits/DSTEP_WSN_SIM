import copy, json
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize

ROOT=Path(__file__).resolve().parents[1]

def base():
    return json.loads((ROOT/"config.json").read_text())

def test_ideal_mode_preserves_unlimited_nodes():
    cfg=base(); cfg["battery"]["mode"]="ideal"; cfg["simulation_time_s"]=2.0
    sim=Simulator(cfg, 3, "periodic", 1234).run()
    assert all(n.alive for n in sim.nodes)
    assert sim.battery.summary(sim.duration)["enabled"] is False

def test_battery_energy_conversion_and_lifetime_estimate():
    cfg=base(); cfg["battery"]={"mode":"battery","capacity_mah":1000,"voltage_v":3.7,"initial_soc":1.0}; cfg["simulation_time_s"]=2.0
    sim=Simulator(cfg, 3, "periodic", 1234).run()
    assert abs(sim.nodes[0].battery_initial_mj - 13320000.0) < 1e-6
    m=summarize(sim)
    assert m["battery_mode"]=="battery"
    assert m["battery_mean_estimated_lifetime_s"] > cfg["simulation_time_s"]

def test_tiny_battery_can_kill_nodes():
    cfg=base(); cfg["battery"]={"mode":"battery","capacity_mah":0.00001,"voltage_v":1.0,"initial_soc":1.0}; cfg["simulation_time_s"]=3.0
    sim=Simulator(cfg, 3, "periodic", 1234).run()
    assert any(not n.alive for n in sim.nodes)
    assert sim.battery.fnd_time_s is not None
