from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_server_has_independent_packet_playback_stream():
    src=(ROOT/'gui_server.py').read_text(encoding='utf-8')
    assert 'self.packet_trace = []' in src
    assert 'PACKET_TRACE_TARGET = 120000' in src
    assert 'def _trace_packet_playback' in src
    assert 'packet_playback_complete_coverage' in src
    assert 'packet_playback_trace.csv' in src

def test_gui_uses_dedicated_packet_stream_without_duplicates():
    js=(ROOT/'gui'/'app.js').read_text(encoding='utf-8')
    assert 'packetTrace=(d.packet_trace||[])' in js
    assert "scientificTrace.filter(e=>e.kind!=='packet')" in js
    assert 'scientificPlayback.concat(mobilityTrace,packetTrace)' in js
    assert 'cobertura paquetes completa' in js
    assert 'último intento enlace' in js

def test_gui_clarifies_physical_event_front():
    js=(ROOT/'gui'/'app.js').read_text(encoding='utf-8')
    assert 'Frente físico del fenómeno' in js
    assert 'NO es radio RF' in js
    assert 'Radio máximo físico del fenómeno' in js
    assert 'sin nuevos intentos de enlace desde' in js
