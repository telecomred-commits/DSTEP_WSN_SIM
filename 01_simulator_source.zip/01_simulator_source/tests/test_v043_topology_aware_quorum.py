import json
from pathlib import Path
from wsn_sim.simulator import Simulator

ROOT=Path(__file__).resolve().parents[1]

def cfg():
    return json.loads((ROOT/'config.json').read_text())

def test_sparse_degree_reduces_quorum_without_exceeding_base():
    sim=Simulator(cfg(), 3, 'dstep_payoff', 123)
    p=sim.policy
    # Force a simple line: nodes 0 and 1 near, node 2 far. Nominal degree is local information.
    sim.nodes[0].position=(0.0,0.0); sim.nodes[1].position=(1.0,0.0); sim.nodes[2].position=(99.0,99.0)
    q,tau,local=p._confirmation_rule(sim.nodes[0],0.9)
    assert q == 1
    assert tau >= sim.cfg['dstep']['confirm_threshold']
    assert local is False

def test_isolated_node_uses_stricter_local_fallback():
    sim=Simulator(cfg(), 2, 'dstep_payoff', 124)
    p=sim.policy
    sim.nodes[0].position=(0.0,0.0); sim.nodes[1].position=(1000.0,1000.0)
    q,tau,local=p._confirmation_rule(sim.nodes[0],0.9)
    assert q == 0
    assert local is True
    assert tau > sim.cfg['dstep']['confirm_threshold']
