import json
from pathlib import Path
import gui_server


def test_saved_configuration_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, "CONFIGURATIONS_ROOT", tmp_path)
    snapshot = {
        "ui": {"placement": "mixed"},
        "payload": {
            "node_count": 2,
            "seed": 1234,
            "policy": "dstep",
            "positions": [[1.0, 2.0], [3.0, 4.0]],
            "config": {"mobility": {"model": "random_waypoint", "speed_m_s": 1.0}},
        },
    }
    saved = gui_server.save_named_configuration("D-STEP prueba 1", snapshot)
    assert saved["ok"] is True
    cid = saved["configuration"]["id"]
    record = gui_server.load_named_configuration(cid)
    assert record["name"] == "D-STEP prueba 1"
    assert record["snapshot"] == snapshot
    assert record["simulator_version"] == "0.42"
    assert gui_server.list_saved_configurations()[0]["id"] == cid
    assert gui_server.delete_named_configuration(cid)["ok"] is True
    assert gui_server.list_saved_configurations() == []


def test_saved_configuration_prevents_accidental_overwrite(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, "CONFIGURATIONS_ROOT", tmp_path)
    snap = {"payload": {"node_count": 20}}
    gui_server.save_named_configuration("same name", snap)
    try:
        gui_server.save_named_configuration("same name", {"payload": {"node_count": 50}})
    except FileExistsError:
        pass
    else:
        raise AssertionError("Expected FileExistsError")
    gui_server.save_named_configuration("same name", {"payload": {"node_count": 50}}, overwrite=True)
    assert gui_server.load_named_configuration("same_name")["snapshot"]["payload"]["node_count"] == 50


def test_configuration_name_cannot_escape_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, "CONFIGURATIONS_ROOT", tmp_path)
    out = gui_server.save_named_configuration("../../my config", {"payload": {}})
    cid = out["configuration"]["id"]
    assert "/" not in cid and "\\" not in cid
    assert (tmp_path / f"{cid}.json").exists()
