import copy
import json
from pathlib import Path

import pytest

from gui_server import build_config
from wsn_sim.simulator import Simulator


def base_cfg():
    root = Path(__file__).resolve().parents[1]
    return json.loads((root / "config.json").read_text(encoding="utf-8"))


def chain_cfg():
    cfg = base_cfg()
    cfg["area_m"] = [20.0, 5.0]
    cfg["sink_position"] = [15.0, 0.0]
    cfg["topology"] = {
        "placement": "manual",
        "manual_positions": [[0.0, 0.0], [5.0, 0.0], [10.0, 0.0]],
    }
    cfg["radio"]["connectivity_mode"] = "geometric"
    cfg["radio"]["neighbor_radius_m"] = 5.1
    cfg["radio"]["receiver_sensitivity_dbm"] = -200.0
    cfg["radio"]["use_hard_sensitivity_cutoff"] = True
    cfg["radio"]["channel_model"] = "free_space"
    cfg["radio"]["collision_window_ms"] = 0.0
    cfg["radio_control"]["mode"] = "fixed"
    cfg["communication"] = {
        "architecture": "multi_hop_to_sink",
        "routing": {"strategy": "shortest_hop", "max_hops": 8},
    }
    return cfg


def test_multihop_route_uses_relays_and_reaches_sink():
    sim = Simulator(chain_cfg(), 3, "central_edge", seed=77)
    route = sim.nominal_route_to_sink(sim.nodes[0])
    assert [n.node_id for n in route] == [0, 1, 2, -1]

    assert sim.route_to_sink(sim.nodes[0], {"type": "test", "confidence": 1.0})
    sim.engine.run(1.0)

    assert sim.routing_packets == 1
    assert sim.routing_delivered == 1
    assert sim.routing_hops_attempted == 3
    assert sim.routing_hops_successful == 3
    assert sim.nodes[0].tx_count == 1
    assert sim.nodes[1].tx_count == 1
    assert sim.nodes[2].tx_count == 1
    assert sim.nodes[1].rx_count == 1
    assert sim.nodes[2].rx_count == 1
    assert sim.nodes[0].first_alert_time is not None


def test_multihop_reports_no_route_without_geometric_chain():
    cfg = chain_cfg()
    cfg["radio"]["neighbor_radius_m"] = 4.0
    sim = Simulator(cfg, 3, "central_edge", seed=77)
    assert sim.nominal_route_to_sink(sim.nodes[0]) is None
    assert sim.route_to_sink(sim.nodes[0], {"type": "test", "confidence": 1.0}) is False
    assert sim.routing_no_route == 1
    assert sim.routing_hops_attempted == 0


def test_legacy_central_edge_defaults_to_direct_sink():
    cfg = base_cfg()
    cfg.pop("communication", None)
    sim = Simulator(cfg, 3, "central_edge", seed=9)
    assert sim.communication_architecture == "direct_to_sink"


def test_gui_rejects_incompatible_dstep_sink_architecture():
    payload = {
        "node_count": 3,
        "policy": "dstep",
        "seed": 1,
        "config": {"communication": {"architecture": "multi_hop_to_sink"}},
    }
    with pytest.raises(ValueError, match="not compatible"):
        build_config(payload)
