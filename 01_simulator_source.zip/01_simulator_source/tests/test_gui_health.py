from gui_server import _graph_summary

class P:
    def __init__(self, node_id, x):
        self.node_id=node_id
        self.position=(x,0.0)

def test_graph_summary_components_and_isolates():
    nodes=[P(0,0),P(1,1),P(2,10)]
    h=_graph_summary(nodes, lambda a,b: abs(a.position[0]-b.position[0]) <= 2)
    assert h['connected_components'] == 2
    assert h['isolated_nodes'] == 1
    assert h['isolated_ids'] == [2]
    assert h['largest_component_fraction'] == 2/3
    assert h['mean_degree'] == 2/3
