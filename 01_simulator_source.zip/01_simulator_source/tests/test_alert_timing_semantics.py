from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_gui_labels_negative_delay_as_anticipation():
    js=(ROOT/"gui"/"app.js").read_text(encoding="utf-8")
    assert "alertDelay<0?'Anticipación media':'Retardo medio alerta'" in js
    assert "Math.abs(alertDelay).toFixed(4)" in js
    assert "Lead time predictivo" in js
    assert "s antes" in js
    assert "s después" in js

def test_campaign_aggregate_keeps_mean_lead_time():
    server=(ROOT/"gui_server.py").read_text(encoding="utf-8")
    assert '"mean_lead_time_s"' in server
