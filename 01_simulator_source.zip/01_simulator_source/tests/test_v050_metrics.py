import json
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize
ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_legacy_f1_is_explicit_confirmation_f1():
    c=cfg(); s=Simulator(c,20,'dstep_payoff',5000001); s.run(); r=summarize(s)
    assert r['f1'] == r['confirmation_f1']
    assert 'awareness_recall' in r and 'false_awareness_rate' in r

def test_absent_metrics_are_evaluator_only_and_bounded():
    c=cfg(); c['event']['model']='absent'; s=Simulator(c,20,'dstep_payoff',5000002); s.run(); r=summarize(s)
    assert 0 <= r['false_confirmation_rate'] <= 1
    assert 0 <= r['false_awareness_rate'] <= 1
    assert r['network_false_alarm'] in (0,1)
