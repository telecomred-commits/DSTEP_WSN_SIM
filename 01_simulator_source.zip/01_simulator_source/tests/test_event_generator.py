import json
from pathlib import Path
from wsn_sim.simulator import Simulator

ROOT=Path(__file__).resolve().parents[1]

def base():
    return json.loads((ROOT/"config.json").read_text())

def gt(cfg, seed=1234):
    return Simulator(cfg, 5, "dstep", seed).event_ground_truth

def test_deterministic_event_preserves_requested_truth():
    cfg=base()
    cfg["event"]["model"]="deterministic"
    cfg["event"]["origin"]=[12.5, 33.0]
    cfg["event"]["start_time_s"]=7.25
    cfg["event"]["speed_m_s"]=4.5
    cfg["event"]["radius_max_m"]=88.0
    g=gt(cfg)
    assert g["model"]=="deterministic"
    assert g["origin"]==[12.5,33.0]
    assert g["start_time_s"]==7.25
    assert g["speed_m_s"]==4.5
    assert g["radius_max_m"]==88.0

def test_stochastic_event_is_seed_reproducible_and_bounded():
    cfg=base()
    cfg["event"].update({
        "model":"stochastic","start_min_s":2.0,"start_max_s":6.0,
        "speed_min_m_s":1.0,"speed_max_m_s":3.0,
        "radius_min_m":20.0,"radius_max_m_stochastic":40.0,
        "origin_margin_m":5.0,
    })
    a=gt(cfg,77); b=gt(cfg,77); c=gt(cfg,78)
    assert a==b
    assert a!=c
    assert 5 <= a["origin"][0] <= 95
    assert 5 <= a["origin"][1] <= 95
    assert 2 <= a["start_time_s"] <= 6
    assert 1 <= a["speed_m_s"] <= 3
    assert 20 <= a["radius_max_m"] <= 40

def test_spatial_risk_is_reproducible_and_inside_area():
    cfg=base()
    cfg["event"].update({
        "model":"spatial_risk","risk_center":[80,20],"risk_sigma_m":5,
        "start_min_s":1,"start_max_s":4,"speed_min_m_s":2,"speed_max_m_s":5,
        "radius_min_m":30,"radius_max_m_stochastic":70,
    })
    a=gt(cfg,99); b=gt(cfg,99)
    assert a==b
    assert 0 <= a["origin"][0] <= 100
    assert 0 <= a["origin"][1] <= 100

def test_event_rng_does_not_change_topology_for_same_seed():
    cfg1=base(); cfg2=base()
    cfg1["event"]["model"]="deterministic"
    cfg2["event"]["model"]="stochastic"
    s1=Simulator(cfg1,20,"dstep",1234)
    s2=Simulator(cfg2,20,"dstep",1234)
    assert [n.position for n in s1.nodes] == [n.position for n in s2.nodes]
