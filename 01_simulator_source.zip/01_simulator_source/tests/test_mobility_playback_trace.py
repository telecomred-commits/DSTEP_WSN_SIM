from pathlib import Path
import importlib.util, copy, json

ROOT=Path(__file__).resolve().parents[1]

def load_server():
    spec=importlib.util.spec_from_file_location("gui_server_mobility_test", ROOT/"gui_server.py")
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def test_trace_simulator_has_separate_mobility_stream():
    src=(ROOT/"gui_server.py").read_text(encoding="utf-8")
    assert "self.mobility_trace = []" in src
    assert "MOBILITY_TRACE_TARGET = 120000" in src
    assert "finalize_mobility_trace" in src
    assert '"mobility_trace"' in src
    assert '"mobility_complete"' in src

def test_gui_merges_scientific_and_mobility_for_playback():
    js=(ROOT/"gui"/"app.js").read_text(encoding="utf-8")
    assert "scientificTrace=(d.trace||[])" in js
    assert "mobilityTrace=(d.mobility_trace||[])" in js
    assert "scientificPlayback.concat(mobilityTrace,packetTrace)" in js
    assert "movilidad completa" in js

def test_event_front_is_labeled_as_phenomenon():
    js=(ROOT/"gui"/"app.js").read_text(encoding="utf-8")
    assert "Frente físico del fenómeno" in js
    assert "Radio máximo físico del fenómeno" in js
