import gui_server


def test_campaign_architecture_auto_respects_algorithm():
    assert gui_server._campaign_architecture('dstep', 'multi_hop_to_sink', 'auto') == 'distributed'
    assert gui_server._campaign_architecture('central_edge', 'distributed', 'auto') == 'direct_to_sink'
    assert gui_server._campaign_architecture('periodic', 'direct_to_sink', 'auto') == 'direct_to_sink'


def test_tiny_campaign_exports_research_files(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, 'CAMPAIGNS_ROOT', tmp_path)
    payload = {
        'base_payload': {
            'node_count': 3,
            'seed': 1234,
            'policy': 'event_driven',
            'positions': None,
            'config': {
                'simulation_time_s': 0.5,
                'area_m': [100, 100],
                'sink_position': [50, 50],
                'communication': {'architecture': 'distributed', 'routing': {'strategy': 'shortest_hop', 'max_hops': 32}},
                'radio': {'radio_profile': 'esp_now_experimental', 'channel_model': 'log_normal'},
                'environment': {'profile': 'custom', 'channel_model': 'log_normal'},
                'topology': {'placement': 'uniform_random'},
            },
        },
        'matrix': {
            'node_counts': [3], 'areas': [[100, 100]], 'policies': ['event_driven'],
            'channels': ['log_normal'], 'radios': ['esp_now_experimental'],
            'repetitions': 2, 'seed_base': 7000, 'architecture_mode': 'auto',
        },
    }
    result = gui_server.run_campaign(payload)
    assert result['requested_runs'] == 2
    assert result['completed_runs'] == 2
    assert result['failed_runs'] == 0
    folder = tmp_path / result['id']
    for name in ('campaign_results.csv', 'aggregate_summary.csv', 'experiment_matrix.csv', 'failures.csv', 'campaign_config.json'):
        assert (folder / name).exists()
    assert (tmp_path / f"{result['id']}.zip").exists()
