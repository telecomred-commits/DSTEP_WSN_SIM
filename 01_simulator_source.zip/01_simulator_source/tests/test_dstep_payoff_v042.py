import copy, json
from pathlib import Path
from wsn_sim.simulator import Simulator, POLICIES
from wsn_sim.metrics.collector import summarize

ROOT=Path(__file__).resolve().parents[1]

def cfg():
    return json.loads((ROOT/'config.json').read_text())

def test_payoff_policy_registered_and_runs():
    c=cfg(); c['simulation_time_s']=3.0; c['period_s']=1.0
    sim=Simulator(c, 8, 'dstep_payoff', 77)
    sim.run()
    m=summarize(sim)
    assert 'dstep_payoff' in POLICIES
    assert m['policy']=='dstep_payoff'
    assert m['payoff_decisions'] > 0
    assert m['energy_payoff_mj'] > 0

def test_high_compute_cost_rejects_optional_compute():
    c=cfg(); c['simulation_time_s']=1.0; c['dstep_payoff']['compute_cost_scale']=50.0
    sim=Simulator(c, 6, 'dstep_payoff', 12)
    p=sim.policy; n=sim.nodes[0]
    accepted, payoff=p._should_deep_compute(n, 0.7, 0.65, 0.4)
    assert not accepted
    assert payoff < 0
    assert n.payoff_compute_rejected == 1

def test_expensive_communication_increases_compute_payoff():
    c=cfg(); c['simulation_time_s']=1.0
    low=Simulator(copy.deepcopy(c), 6, 'dstep_payoff', 13)
    n1=low.nodes[0]; n1.last_feedback_success_rate=1.0
    low.cfg['dstep_payoff']['congestion_weight']=0.0
    low.cfg['dstep_payoff']['link_risk_weight']=0.0
    p1,_=low.policy._compute_payoff(n1,0.55,0.55,0.15)

    high=Simulator(copy.deepcopy(c), 6, 'dstep_payoff', 13)
    n2=high.nodes[0]; n2.last_feedback_success_rate=0.35; n2.radio_tx_observations=10; n2.radio_congestion_events=8
    p2,_=high.policy._compute_payoff(n2,0.55,0.55,0.15)
    assert p2 > p1

def test_urgent_confirmed_message_has_higher_transmit_payoff():
    c=cfg(); c['simulation_time_s']=5.0
    sim=Simulator(c, 6, 'dstep_payoff', 22)
    n=sim.nodes[0]
    n.first_detection_time=sim.engine.time
    p0,_=sim.policy._transmit_payoff(n,0.7,0.7,0.45,eta=3.0,confirmed=False)
    p1,_=sim.policy._transmit_payoff(n,0.7,0.7,0.45,eta=0.1,confirmed=True)
    assert p1 > p0
