import json
from pathlib import Path
from wsn_sim.simulator import Simulator
ROOT=Path(__file__).resolve().parents[1]

def _sim():
    cfg=json.loads((ROOT/'config.json').read_text())
    return Simulator(cfg,2,'dstep_payoff',222)

def test_single_sample_does_not_relax_quorum():
    sim=_sim(); p=sim.policy; n=sim.nodes[0]
    n.first_detection_time=sim.engine.time
    q,tau,local=p._apply_persistent_local_evidence(n,0.9,0,1,0.67,False)
    assert q==1 and local is False

def test_persistent_evidence_can_relax_one_missing_confirmation():
    sim=_sim(); p=sim.policy; n=sim.nodes[0]
    n.first_detection_time=0.0; sim.engine.time=1.0
    q,tau,local=p._apply_persistent_local_evidence(n,0.7,0,1,0.67,False)
    assert q==0 and local is True
    assert tau >= 0.60
