import json
from pathlib import Path
from wsn_sim.simulator import Simulator
ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_unique_source_quorum_enabled():
    assert cfg()['dstep_payoff']['unique_source_quorum']['enabled'] is True

def test_absent_reference_seed_limits_false_confirmation():
    c=cfg(); c['event']['model']='absent'
    s=Simulator(c,100,'dstep_payoff',1960123); s.run()
    assert sum(1 for n in s.nodes if n.confirmed) <= 2
