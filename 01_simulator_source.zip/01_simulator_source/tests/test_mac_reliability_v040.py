import copy
import json
from pathlib import Path

from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize


def base_cfg():
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    cfg["area_m"] = [10.0, 10.0]
    cfg["sink_position"] = [2.0, 0.0]
    cfg["topology"] = {"placement": "manual", "manual_positions": [[0.0, 0.0], [4.0, 0.0], [6.0, 0.0]]}
    cfg["radio"]["connectivity_mode"] = "geometric"
    cfg["radio"]["neighbor_radius_m"] = 20.0
    cfg["radio"]["receiver_sensitivity_dbm"] = -200.0
    cfg["radio"]["channel_model"] = "free_space"
    cfg["radio_control"]["mode"] = "fixed"
    cfg["mac"]["mode"] = "none"  # isolate reliability from contention in unit tests
    cfg["mac"]["queue_enabled"] = True
    cfg["mac"]["queue_capacity"] = 16
    cfg["mac"]["reliability"]["enabled"] = True
    cfg["mac"]["reliability"]["ack_unicast"] = True
    cfg["mac"]["reliability"]["max_retries"] = 3
    cfg["mac"]["reliability"]["ack_timeout_s"] = 0.0001
    cfg["mac"]["reliability"]["retry_backoff_s"] = 0.0001
    cfg["mac"]["reliability"]["sifs_s"] = 0.0001
    return cfg


def test_data_failure_retries_then_ack_completes_delivery():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    sim = Simulator(cfg, 3, "central_edge", seed=101)
    sender = sim.nodes[0]
    calls = {"data": 0, "ack": 0}

    def fake_resolve(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        if payload.get("type") == "mac_ack":
            calls["ack"] += 1
            return True, 0.0001, -50.0, "ok"
        calls["data"] += 1
        if calls["data"] == 1:
            return False, 0.0001, -50.0, "channel_loss"
        return True, 0.0001, -50.0, "ok"

    sim.radio.resolve_receive = fake_resolve
    assert sim.send_to_sink(sender, {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)

    assert calls == {"data": 2, "ack": 1}
    assert sender.tx_count == 2
    assert sim.mac_retry_tx_frames == 1
    assert sim.mac_retries_scheduled == 1
    assert sim.mac_ack_tx_frames == 1
    assert sim.mac_ack_rx_frames == 1
    assert sim.mac_retry_exhausted == 0
    assert sender.first_alert_time is not None
    assert not sim.mac_active_requests


def test_lost_ack_causes_duplicate_data_retry_without_duplicate_upper_delivery():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    sim = Simulator(cfg, 3, "central_edge", seed=102)
    sender = sim.nodes[0]
    calls = {"data": 0, "ack": 0}

    def fake_resolve(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        if payload.get("type") == "mac_ack":
            calls["ack"] += 1
            if calls["ack"] == 1:
                return False, 0.0001, -50.0, "channel_loss"
            return True, 0.0001, -50.0, "ok"
        calls["data"] += 1
        return True, 0.0001, -50.0, "ok"

    sim.radio.resolve_receive = fake_resolve
    assert sim.send_to_sink(sender, {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)

    assert calls == {"data": 2, "ack": 2}
    assert sender.tx_count == 2
    assert sim.mac_ack_losses == 1
    assert sim.mac_ack_channel_losses == 1
    assert sim.mac_duplicate_data_rx == 1
    assert sim.mac_retry_tx_frames == 1
    assert sim.mac_ack_rx_frames == 1
    assert sender.first_alert_time is not None


def test_retry_exhaustion_is_bounded_and_releases_queue():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    cfg["mac"]["reliability"]["max_retries"] = 2
    sim = Simulator(cfg, 3, "central_edge", seed=103)
    sender = sim.nodes[0]

    def always_fail(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        return False, 0.0001, -50.0, "channel_loss"

    sim.radio.resolve_receive = always_fail
    assert sim.send_to_sink(sender, {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)

    # Initial frame + two retries.
    assert sender.tx_count == 3
    assert sim.mac_retry_tx_frames == 2
    assert sim.mac_retries_scheduled == 2
    assert sim.mac_retry_exhausted == 1
    assert sim.mac_ack_tx_frames == 0
    assert sender.first_alert_time is None
    assert not sim.mac_active_requests


def test_finite_queue_drops_excess_waiting_frame_and_records_delay():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "distributed"}
    cfg["mac"]["queue_capacity"] = 1
    sim = Simulator(cfg, 3, "event_driven", seed=104)
    sender = sim.nodes[0]

    assert sim.broadcast(sender, {"type": "q1", "confidence": 1.0}) is True
    assert sim.broadcast(sender, {"type": "q2", "confidence": 1.0}) is True
    assert sim.broadcast(sender, {"type": "q3", "confidence": 1.0}) is False
    assert sim.mac_queue_drops == 1
    assert sim.mac_max_queue_depth == 1
    sim.engine.run(0.1)

    assert sender.tx_count == 2
    assert len(sim.mac_queue_delay_samples_s) == 2
    assert sim.mac_queue_delay_samples_s[1] > 0.0
    assert not sim.mac_active_requests


def test_broadcast_remains_ackless_by_default():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "distributed"}
    sim = Simulator(cfg, 3, "event_driven", seed=105)
    sender = sim.nodes[0]
    sim.broadcast(sender, {"type": "broadcast", "confidence": 1.0})
    sim.engine.run(0.1)
    assert sender.tx_count == 1
    assert sim.mac_ack_tx_frames == 0
    assert sim.mac_retry_tx_frames == 0


def test_summary_exposes_v040_mac_reliability_metrics():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    sim = Simulator(cfg, 3, "central_edge", seed=106)
    sim.send_to_sink(sim.nodes[0], {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)
    out = summarize(sim)
    for key in (
        "mac_queue_drops", "mean_mac_queue_delay_s", "mac_retry_tx_frames",
        "mac_ack_tx_frames", "mac_ack_rx_frames", "mac_retry_tx_energy_mj",
        "physical_tx_frames",
    ):
        assert key in out
    assert out["physical_tx_frames"] == out["tx_packets"] + out["mac_ack_tx_frames"]


def test_unreliable_unicast_failure_counts_as_logical_failure():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    cfg["mac"]["reliability"]["enabled"] = False
    sim = Simulator(cfg, 3, "central_edge", seed=107)

    def always_fail(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        return False, 0.0001, -50.0, "channel_loss"

    sim.radio.resolve_receive = always_fail
    sim.send_to_sink(sim.nodes[0], {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)
    out = summarize(sim)
    assert out["mac_unicast_frames_success"] == 0
    assert out["mac_unicast_frames_failed"] == 1
    assert out["mac_unicast_delivery_ratio"] == 0.0


def test_data_arrival_is_counted_even_when_all_acks_are_lost():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "direct_to_sink"}
    cfg["mac"]["reliability"]["max_retries"] = 1
    sim = Simulator(cfg, 3, "central_edge", seed=108)
    sender = sim.nodes[0]

    def data_ok_ack_lost(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        if payload.get("type") == "mac_ack":
            return False, 0.0001, -50.0, "channel_loss"
        return True, 0.0001, -50.0, "ok"

    sim.radio.resolve_receive = data_ok_ack_lost
    sim.send_to_sink(sender, {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)
    out = summarize(sim)

    # Application data reached the sink on the first DATA frame even though
    # the sender never obtained confirmation from the reverse ACK path.
    assert sender.first_alert_time is not None
    assert out["mac_unicast_data_delivery_ratio"] == 1.0
    assert out["mac_unicast_confirmed_delivery_ratio"] == 0.0
    assert out["mac_unicast_data_frames_received"] == 1
    assert out["mac_duplicate_data_rx"] == 1


def test_final_multihop_data_arrival_counts_before_ack_confirmation():
    cfg = base_cfg()
    cfg["communication"] = {"architecture": "multi_hop_to_sink"}
    cfg["mac"]["reliability"]["max_retries"] = 0
    # Place node 0 close enough to the sink so the route has one final hop.
    cfg["topology"] = {"placement": "manual", "manual_positions": [[0.0, 0.0], [8.0, 0.0], [9.0, 0.0]]}
    cfg["sink_position"] = [2.0, 0.0]
    sim = Simulator(cfg, 3, "central_edge", seed=109)
    sender = sim.nodes[0]

    def data_ok_ack_lost(tx, receiver, payload, access_s, tx_base_s, rx_e, commit_payload=True):
        if payload.get("type") == "mac_ack":
            return False, 0.0001, -50.0, "channel_loss"
        return True, 0.0001, -50.0, "ok"

    sim.radio.resolve_receive = data_ok_ack_lost
    assert sim.route_to_sink(sender, {"type": "test", "confidence": 1.0})
    sim.engine.run(0.1)
    out = summarize(sim)
    assert sender.first_alert_time is not None
    assert out["routing_sink_data_arrivals"] == 1
    assert out["routing_delivered"] == 0  # no ACK confirmation
