from pathlib import Path
import importlib.util

ROOT=Path(__file__).resolve().parents[1]

def load_server():
    spec=importlib.util.spec_from_file_location("gui_server_test", ROOT/"gui_server.py")
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def test_mean_std_still_excludes_raw_bool():
    mod=load_server()
    assert mod._mean_std([True, False]) == (None, None)

def test_campaign_aggregation_converts_functional_bool():
    source=(ROOT/"gui_server.py").read_text(encoding="utf-8")
    assert 'if metric == "functional_at_end"' in source
    assert '1.0 if v is True else 0.0 if v is False' in source
    assert 'functional_success_rate' in source

def test_campaign_exports_three_topology_families():
    source=(ROOT/"gui_server.py").read_text(encoding="utf-8")
    for key in (
        "geometric_mean_degree",
        "radio_configured_mean_degree",
        "radio_mean_degree",
        "radio_degree_basis",
    ):
        assert key in source

def test_gui_clarifies_radio_degree_semantics():
    js=(ROOT/"gui"/"app.js").read_text(encoding="utf-8")
    assert "Radio baseline (potencia configurada)" in js
    assert "Radio post-simulación (link budget)" in js
    assert "potencia TX final/adaptada" in js
