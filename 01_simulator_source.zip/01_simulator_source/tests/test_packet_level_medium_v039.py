import random

from wsn_sim.nodes.node import Node
from wsn_sim.radio.model import RadioModel


def radio_cfg(**overrides):
    cfg = {
        "channel_model": "free_space",
        "tx_power_dbm": 0.0,
        "receiver_sensitivity_dbm": -120.0,
        "sensitivity_slope": 1.0,
        "use_hard_sensitivity_cutoff": True,
        "connectivity_mode": "link_budget",
        "max_geometric_range_m": None,
        "bitrate_bps": 250000,
        "payload_bytes": 48,
        "phy_overhead_bytes": 0,
        "noise_floor_dbm": -120.0,
        "sinr_threshold_db": 6.0,
        "pl_d0_db": 40.0,
        "d0_m": 1.0,
        "path_loss_exponent": 2.0,
        "mac": {
            "mode": "csma_ca_lite",
            "cca_threshold_dbm": -63.0,
        },
    }
    cfg.update(overrides)
    return cfg


def test_equal_power_overlapping_frames_collide_symmetrically():
    radio = RadioModel(radio_cfg(), random.Random(4))
    a = Node(0, (-10.0, 0.0)); a.tx_power_dbm = 0.0
    c = Node(1, (10.0, 0.0)); c.tx_power_dbm = 0.0
    r = Node(2, (0.0, 0.0))

    tx_a = radio.start_transmission(a, 0.0)
    tx_c = radio.start_transmission(c, 0.0)

    ra = radio.resolve_receive(tx_a, r, {"type": "x"}, 0.0, 0.0, 0.18)
    rc = radio.resolve_receive(tx_c, r, {"type": "x"}, 0.0, 0.0, 0.18)

    assert ra[0] is False and ra[3] == "collision"
    assert rc[0] is False and rc[3] == "collision"
    assert radio.last_resolution_meta[(tx_a.tx_id, r.node_id)]["interferers"] == 1
    assert radio.last_resolution_meta[(tx_c.tx_id, r.node_id)]["interferers"] == 1


def test_strong_frame_can_be_captured_under_overlap():
    radio = RadioModel(radio_cfg(), random.Random(7))
    strong = Node(0, (1.0, 0.0)); strong.tx_power_dbm = 0.0
    weak = Node(1, (80.0, 0.0)); weak.tx_power_dbm = 0.0
    r = Node(2, (0.0, 0.0))

    tx_s = radio.start_transmission(strong, 0.0)
    tx_w = radio.start_transmission(weak, 0.0)

    success, _, _, reason = radio.resolve_receive(tx_s, r, {"type": "x"}, 0.0, 0.0, 0.18)
    assert success is True
    assert reason == "ok"
    assert radio.last_resolution_meta[(tx_s.tx_id, r.node_id)]["sinr_db"] > 6.0


def test_failed_collision_still_consumes_rx_energy():
    radio = RadioModel(radio_cfg(), random.Random(2))
    a = Node(0, (-10.0, 0.0)); a.tx_power_dbm = 0.0
    c = Node(1, (10.0, 0.0)); c.tx_power_dbm = 0.0
    r = Node(2, (0.0, 0.0))
    tx_a = radio.start_transmission(a, 0.0)
    radio.start_transmission(c, 0.0)

    before = r.energy_rx
    success, _, _, reason = radio.resolve_receive(tx_a, r, {"type": "x"}, 0.0, 0.0, 0.18)

    assert success is False
    assert reason == "collision"
    assert r.energy_rx == before + 0.18
    assert r.rx_count == 0


def test_cca_can_reproduce_hidden_terminal_geometry():
    # A---B---C. B senses A, but C does not. C can therefore transmit while A
    # is active, creating a hidden-terminal overlap at B.
    radio = RadioModel(radio_cfg(), random.Random(9))
    a = Node(0, (0.0, 0.0)); a.tx_power_dbm = 0.0
    b = Node(1, (10.0, 0.0))
    c = Node(2, (20.0, 0.0)); c.tx_power_dbm = 0.0

    radio.start_transmission(a, 0.0)

    assert radio.channel_busy(b, 0.0005) is True
    assert radio.channel_busy(c, 0.0005) is False


def test_staggered_overlap_is_retained_until_later_frame_resolves():
    """An earlier-ending interferer must not disappear before a later frame resolves."""
    cfg = radio_cfg(bitrate_bps=250000)
    radio = RadioModel(cfg, random.Random(12))
    early = Node(0, (-10.0, 0.0)); early.tx_power_dbm = 0.0
    late = Node(1, (10.0, 0.0)); late.tx_power_dbm = 0.0
    unrelated = Node(3, (1000.0, 1000.0)); unrelated.tx_power_dbm = 0.0
    r = Node(2, (0.0, 0.0))

    airtime = radio.packet_airtime_s(48)
    tx_early = radio.start_transmission(early, 1.0, 48)
    tx_late = radio.start_transmission(late, 1.0 + airtime * 0.40, 48)

    # Resolve and finish the earlier frame first. It must be retained because
    # the later frame is unresolved and overlapped it.
    radio.resolve_receive(tx_early, r, {"type": "x"}, 0.0, 0.0, 0.18)
    radio.finish_transmission(tx_early)
    assert tx_early in radio.transmissions

    # Starting another frame after the early frame ended must not erase its
    # interference history for tx_late.
    radio.start_transmission(unrelated, tx_early.end_s + airtime * 0.05, 48)
    assert tx_early in radio.overlapping_transmissions(tx_late)

    success, _, _, reason = radio.resolve_receive(tx_late, r, {"type": "x"}, 0.0, 0.0, 0.18)
    assert success is False
    assert reason == "collision"
