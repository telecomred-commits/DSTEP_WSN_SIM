import json
import math
import random
from pathlib import Path

from wsn_sim.channels.factory import create_channel
from wsn_sim.radio.model import RadioModel
from wsn_sim.radio.profiles import RADIO_PROFILES, apply_radio_profile


class Node:
    def __init__(self, node_id, x, y=0.0, tx_power_dbm=20.0):
        self.node_id = node_id
        self.position = (float(x), float(y))
        self.tx_power_dbm = float(tx_power_dbm)


def test_real_profile_is_present_and_externally_calibrated():
    p = RADIO_PROFILES["esp_now_test002_real"]
    r = p["radio"]
    assert p["evidence"] == "externally_calibrated_real_hardware"
    assert r["channel_model"] == "esp32_test002"
    assert r["payload_bytes"] == 48
    assert math.isclose(r["tx_power_dbm"], 20.0)
    assert r["use_hard_sensitivity_cutoff"] is False
    assert r["link_shadow_sigma_db"] > r["fast_fading_sigma_db"] > 0


def test_calibrated_channel_has_persistent_link_shadow_and_fast_packet_variation():
    cfg = dict(RADIO_PROFILES["esp_now_test002_real"]["radio"])
    ch = create_channel("esp32_test002", cfg, random.Random(12345))
    a = Node(0, 0.0)
    b = Node(1, 20.0)
    static1 = ch.mean_link_adjustment_db(a, b)
    static2 = ch.mean_link_adjustment_db(a, b)
    assert static1 == static2
    # Directed-link calibration: reverse direction gets its own persistent offset.
    reverse = ch.mean_link_adjustment_db(b, a)
    assert reverse != static1
    # Fast packet term is independent across frames.
    vals = [ch.fading_db(a, b) for _ in range(10)]
    assert len(set(round(v, 9) for v in vals)) > 1


def test_decoder_midpoint_is_half_probability_without_hard_cutoff():
    cfg = dict(RADIO_PROFILES["esp_now_test002_real"]["radio"])
    radio = RadioModel(cfg, random.Random(7))
    midpoint = cfg["receiver_sensitivity_dbm"]
    assert math.isclose(radio.success_probability(midpoint), 0.5, rel_tol=1e-12)
    assert radio.cfg["use_hard_sensitivity_cutoff"] is False


def test_default_config_uses_real_test002_profile():
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    assert cfg["radio"]["radio_profile"] == "esp_now_test002_real"
    assert cfg["radio"]["channel_model"] == "esp32_test002"
    assert math.isclose(cfg["radio"]["path_loss_exponent"], 2.2395444914, rel_tol=1e-9)


def test_gui_build_config_applies_selected_profile_before_explicit_overrides():
    from gui_server import build_config
    payload = {
        "node_count": 1,
        "policy": "central_edge",
        "config": {
            "communication": {"architecture": "direct_to_sink"},
            "radio": {"radio_profile": "esp_now_experimental", "tx_power_dbm": 7.0},
        },
    }
    cfg, _, _, _ = build_config(payload)
    # Old profile is restored coherently, while the explicit TX override wins.
    assert cfg["radio"]["channel_model"] == "log_normal"
    assert math.isclose(cfg["radio"]["pl_d0_db"], 40.0)
    assert math.isclose(cfg["radio"]["tx_power_dbm"], 7.0)
