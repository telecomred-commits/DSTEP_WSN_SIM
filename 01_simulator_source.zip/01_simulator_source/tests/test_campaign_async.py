import time
import gui_server


def payload(reps=3):
    return {
        'base_payload': {'node_count': 3, 'seed': 1234, 'policy': 'event_driven', 'positions': None,
            'config': {'simulation_time_s': .2, 'area_m':[100,100], 'sink_position':[50,50],
             'communication': {'architecture':'distributed','routing':{'strategy':'shortest_hop','max_hops':32}},
             'radio': {'radio_profile':'esp_now_experimental','channel_model':'log_normal'},
             'environment': {'profile':'custom','channel_model':'log_normal'}, 'topology': {'placement':'uniform_random'}}},
        'matrix': {'node_counts':[3], 'areas':[[100,100]], 'policies':['event_driven'],
                   'channels':['log_normal'], 'radios':['esp_now_experimental'], 'repetitions':reps,
                   'seed_base':9200, 'architecture_mode':'auto'}}


def test_async_campaign_starts_and_finishes(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, 'CAMPAIGNS_ROOT', tmp_path)
    d=gui_server.start_campaign(payload(3))
    assert d['requested_runs']==3
    job=gui_server.CAMPAIGN_JOBS[d['id']]
    job['thread'].join(timeout=10)
    st=gui_server.campaign_status(d['id'])
    assert st['status']=='completed'
    assert st['completed_runs']==3
    assert (tmp_path/d['id']/'campaign_results.csv').exists()
    assert (tmp_path/f"{d['id']}.zip").exists()


def test_persisted_running_campaign_is_recoverable(tmp_path, monkeypatch):
    monkeypatch.setattr(gui_server, 'CAMPAIGNS_ROOT', tmp_path)
    cid='campaign_test_interrupted'; folder=tmp_path/cid;folder.mkdir()
    (folder/'campaign_state.json').write_text('{"id":"campaign_test_interrupted","status":"running","requested_runs":10,"completed_runs":4,"failed_runs":0}',encoding='utf-8')
    gui_server.CAMPAIGN_JOBS.pop(cid,None)
    st=gui_server.campaign_status(cid)
    assert st['status']=='interrupted'
    assert st['recoverable'] is True


def test_completed_state_is_inside_final_zip(tmp_path, monkeypatch):
    import json, zipfile
    monkeypatch.setattr(gui_server, 'CAMPAIGNS_ROOT', tmp_path)
    d=gui_server.start_campaign(payload(2))
    job=gui_server.CAMPAIGN_JOBS[d['id']]
    job['thread'].join(timeout=10)
    zip_path=tmp_path/f"{d['id']}.zip"
    assert zip_path.exists()
    with zipfile.ZipFile(zip_path) as zf:
        state=json.loads(zf.read(f"{d['id']}/campaign_state.json").decode('utf-8'))
    assert state['status']=='completed'
    assert state['completed_runs']==2
    assert state['finished_utc']
