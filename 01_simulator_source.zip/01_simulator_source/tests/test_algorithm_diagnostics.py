import json
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize
import gui_server

ROOT=Path(__file__).resolve().parents[1]
def base(): return json.loads((ROOT/'config.json').read_text())

def test_link_pdr_uses_delivery_attempts_not_rx_over_tx():
    cfg=base(); cfg['simulation_time_s']=5.0
    sim=Simulator(cfg,20,'dstep',1234).run(); m=summarize(sim)
    assert m['link_delivery_attempts'] >= m['link_delivery_successes'] >= 0
    if m['link_delivery_attempts']:
        assert 0 <= m['link_pdr'] <= 1

def test_energy_fairness_is_bounded():
    cfg=base(); cfg['simulation_time_s']=5.0
    m=summarize(Simulator(cfg,20,'dstep',1234).run())
    assert 0 < m['energy_jain_fairness'] <= 1
    assert m['energy_cv'] >= 0

def test_health_exposes_density_and_nearest_neighbor():
    cfg=base(); sim=Simulator(cfg,20,'dstep',1234)
    h=gui_server.scenario_health(sim)
    assert h['node_density_per_km2'] == 2000.0
    assert h['mean_nearest_neighbor_m'] > 0
    assert 0 <= h['radio']['link_density'] <= 1
    assert h['radio']['min_degree'] <= h['radio']['max_degree']

def test_diagnostic_reports_functional_lower_bound_without_inventing_failure_time():
    cfg=base(); cfg['simulation_time_s']=5.0
    sim=Simulator(cfg,20,'dstep',1234).run(); m=summarize(sim); h=gui_server.scenario_health(sim)
    d=gui_server.algorithm_diagnostic(sim,m,h)
    assert d['type']=='heuristic'
    assert set(d['dimensions']) >= {'detection','link_delivery','connectivity','energy_fairness'}
    if d['functional_at_end']:
        assert d['functional_lifetime_observed_lower_bound_s']==5.0
        assert d['functional_failure_present_by_end'] is False

def test_stochastic_ground_truth_is_used_for_estimation_reference(tmp_path, monkeypatch):
    cfg=base(); cfg['simulation_time_s']=8.0
    cfg['event'].update({'model':'stochastic','start_min_s':1.0,'start_max_s':2.0,'speed_min_m_s':3.0,'speed_max_m_s':4.0,'radius_min_m':50.0,'radius_max_m_stochastic':80.0})
    monkeypatch.setattr(gui_server,'EXPERIMENTS_ROOT',tmp_path)
    result=gui_server.simulation_payload(cfg,20,'dstep',4321,True)
    eid,folder,_=gui_server.export_experiment(result,cfg,20,'dstep',4321)
    gt=json.loads((folder/'ground_truth.json').read_text())
    import csv
    rows=list(csv.DictReader((folder/'estimates.csv').open(encoding='utf-8-sig')))
    if rows:
        assert abs(float(rows[0]['true_origin_x'])-float(gt['origin'][0])) < 1e-9
        assert abs(float(rows[0]['true_speed_m_s'])-float(gt['speed_m_s'])) < 1e-9
