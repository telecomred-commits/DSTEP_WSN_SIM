import json
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize
ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_high_confidence_local_event_can_confirm_without_neighbors():
    c=cfg(); c['topology']['placement']='manual'; c['topology']['manual_positions']=[[0,0],[1000,1000]]
    c['event']['origin']=[0,0]; c['event']['start_time_s']=0; c['event']['speed_m_s']=100; c['event']['radius_max_m']=2000
    c['sensor']['noise_std']=0; c['sensor']['bias_std']=0; c['sensor']['false_negative_prob']=0; c['sensor']['false_positive_prob']=0
    sim=Simulator(c,2,'dstep_payoff',123); sim.run()
    assert sim.nodes[0].confirmed is True

def test_event_absent_does_not_create_confirmed_nodes_in_controlled_noise_free_case():
    c=cfg(); c['event']['model']='absent'; c['sensor']['noise_std']=0; c['sensor']['bias_std']=0; c['sensor']['false_positive_prob']=0
    sim=Simulator(c,20,'dstep_payoff',124); sim.run()
    assert all(not n.confirmed for n in sim.nodes)
