import json
from pathlib import Path
from wsn_sim.simulator import Simulator
ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_verification_window_is_shorter_than_estimation_memory():
    c=cfg(); assert c['dstep']['verify_window_s'] < c['dstep']['estimate_memory_s']
    assert c['dstep_payoff']['verification_window_guard']['enabled'] is True

def test_absent_noise_control_does_not_amplify_for_reference_seed():
    c=cfg(); c['event']['model']='absent'
    s=Simulator(c,100,'dstep_payoff',1840123); s.run()
    assert sum(1 for n in s.nodes if n.confirmed) <= 2
