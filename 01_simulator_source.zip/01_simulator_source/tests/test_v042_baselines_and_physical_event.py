import json
from pathlib import Path
from wsn_sim.simulator import Simulator, POLICIES
from wsn_sim.world.event_generator import realize_event

ROOT=Path(__file__).resolve().parents[1]

def cfg(): return json.loads((ROOT/'config.json').read_text())

def test_new_baselines_registered_and_run():
    c=cfg(); c['simulation_time_s']=2.0
    for name in ('send_on_delta','teen_like','voi_baseline'):
        assert name in POLICIES
        sim=Simulator(c,8,name,101); sim.run()
        assert sum(n.tx_count for n in sim.nodes) >= 0

def test_physical_pulse_zero_before_arrival_and_positive_at_arrival():
    e=realize_event({'model':'physical_pulse','origin':[0,0],'start_time_s':1,'speed_m_s':2,'radius_max_m':100,'peak_intensity':1,'attenuation_per_m':0.05}, [100,100], 1)
    p=(10.0,0.0); ta=e.arrival_time(p)
    assert e.intensity(p,ta-0.01)==0.0
    assert e.intensity(p,ta) > 0.99
    assert e.intensity(p,ta+10.0) < e.intensity(p,ta)

def test_absent_event_has_no_signal_or_arrival():
    e=realize_event({'model':'absent'},[100,100],2)
    assert e.intensity((5,5),100.0)==0.0
    assert e.arrival_time((5,5))==float('inf')
