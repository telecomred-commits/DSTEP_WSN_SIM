import json
from pathlib import Path
from wsn_sim.simulator import Simulator

ROOT=Path(__file__).resolve().parents[1]

def test_default_esp32_calibrated_profile_starts_at_test002_power():
    cfg=json.loads((ROOT/'config.json').read_text())
    assert cfg['radio']['radio_profile']=='esp_now_test002_real'
    assert float(cfg['radio']['tx_power_dbm'])==20.0
    assert float(cfg['radio_control']['initial_tx_power_dbm'])==20.0
    sim=Simulator(cfg,3,'event_driven',123)
    assert all(n.tx_power_dbm==20.0 for n in sim.nodes)
