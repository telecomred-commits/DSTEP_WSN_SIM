# v0.50 development freeze

The v0.50 parameters were frozen **before** the hold-out campaign.

Development/tuning used earlier seed ranges below 4,000,000 across v0.42-v0.49. The v0.50 hold-out campaign uses fresh seeds beginning at 5,000,000. No parameter changes are permitted after inspecting hold-out results.

Frozen reliability parameters:
- verification window: 2.0 s
- independent-source confirmation evidence
- risk-adaptive false-consensus target: 0.02
- local fast-path confidence threshold: 0.851
- persistent quorum relaxation is bypassed while risk-adaptive quorum is active

Legacy `f1` is preserved and explicitly aliased as `confirmation_f1`. New evaluator-only metrics separate local confirmation from network awareness and false alarms.
