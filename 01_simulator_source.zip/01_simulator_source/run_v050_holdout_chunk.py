import argparse,copy,csv,json,os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from wsn_sim.simulator import Simulator
from wsn_sim.metrics.collector import summarize
ROOT=Path(__file__).parent; BASE=json.loads((ROOT/'config.json').read_text()); OUT=ROOT/'results_v050_holdout'; OUT.mkdir(exist_ok=True)
POLICIES=['periodic','event_driven','send_on_delta','teen_like','distributed_edge','voi_baseline','dstep','dstep_payoff']
EVENTS=['deterministic','physical_pulse','absent']; NODES=[20,50,100]; BASESEED=5000000

def worker(t):
 event,policy,n,run,seed=t;c=copy.deepcopy(BASE);c['event']['model']=event
 s=Simulator(c,n,policy,seed);s.run();r=summarize(s);r.update({'event_model':event,'run':run,'seed':seed});return r

def write(path,rows):
 keys=[];seen=set()
 for r in rows:
  for k in r:
   if k not in seen:seen.add(k);keys.append(k)
 with open(path,'w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,required=True);ap.add_argument('--stop',type=int,required=True);a=ap.parse_args()
tasks=[]
for event in EVENTS:
 for policy in POLICIES:
  for n in NODES:
   for run in range(a.start,a.stop):
    seed=BASESEED+EVENTS.index(event)*100000+n*1000+run
    tasks.append((event,policy,n,run,seed))
with ProcessPoolExecutor(max_workers=min(5,os.cpu_count() or 1)) as ex: rows=list(ex.map(worker,tasks,chunksize=1))
path=OUT/f'holdout_raw_{a.start:02d}_{a.stop-1:02d}.csv';write(path,rows);print(path)
