# WSN Edge-AI / D-STEP Simulator v0.42 — Payoff-Aware D-STEP

v0.42 preserves the validated/calibrated v0.41 lineage and adds an explicit **computation–communication payoff policy** (`dstep_payoff`) plus stronger baselines and physically grounded event scenarios. The original `dstep` policy remains available unchanged for paired comparison.

## What is new in v0.42

- `dstep_payoff`: node-local policy that evaluates whether optional distributed computation and transmission are worth their expected communication, delay, reliability and energy costs.
- Reliability guards preserve minimum evidence exchange needed for distributed confirmation and confirmed-alert dissemination.
- Optional robust estimation/ETA is skipped when insufficient independent evidence exists and reused when no new evidence has arrived, avoiding repeated compute that cannot change the estimate.
- Explicit payoff diagnostics: accepted/rejected compute and TX decisions, reliability overrides, skipped computation, payoff-decision energy and estimated avoided TX energy.
- New first-class baselines: `send_on_delta`, `teen_like`, and `voi_baseline`.
- New event models: `physical_pulse` and `absent`, with example configurations in `scenarios_v042/`.
- The default ESP32 calibrated profile now starts the adaptive radio at **20 dBm**, matching the TX power used in TEST002 hardware calibration. v0.41 had `radio.tx_power_dbm=20` but `radio_control.initial_tx_power_dbm=0`; the v0.42 pilot exposed that profile/controller inconsistency.
- Pilot gate included in `results_v042_payoff_pilot/`; it is exploratory only and is not a publication-scale result.
- Full suite: **101 tests passed**.

## Scientific scope

The payoff-decision energy/time values remain explicit sensitivity parameters rather than hardware-calibrated measurements. The ESP32 TEST002 calibration continues to support the DATA RSSI/PDR channel model; it does not claim protocol-faithful reproduction of native ESP-NOW contention or ACK timing.

---

v0.41 parte exactamente del motor validado v0.40.1 y añade una capa de canal **calibrada con hardware real ESP32/ESP-NOW**. La configuración principal usa ahora `radio_profile = esp_now_test002_real`; el perfil anterior y los demás perfiles de radio se conservan para comparación.

## Novedad principal de v0.41

La calibración TEST002 usa **15,000 transmisiones DATA reales**: 5 distancias (1, 10, 20, 25 y 30 m) × 3 corridas × 1000 paquetes, payload de 48 bytes, canal 6, potencia comandada 80 qdBm (=20 dBm), sin reintentos de aplicación. Runs 1–2 se usan para calibración y Run 3 se mantiene fuera del ajuste para validación.

El nuevo canal `esp32_test002` implementa:

- pérdida media log-distance;
- shadowing persistente por enlace y por realización, para representar la gran variabilidad entre corridas observada físicamente;
- variación rápida paquete-a-paquete;
- curva logística de probabilidad de decodificación ajustada con RSSI censurado + conteo de pérdidas;
- separación ya existente en v0.40.1 entre llegada de DATA y confirmación por ACK.

Parámetros centrales del perfil:

```text
TX reference                 20 dBm
PL(d0=1 m)                   80.03334 dB
path-loss exponent           2.23954
persistent link shadow sigma 5.41079 dB
fast packet sigma            3.40811 dB
decoder midpoint             -92.09683 dBm
decoder logistic slope       1.12426 / dB
ESP-NOW default PHY rate     1 Mbps
payload                      48 B
```

El intercepto `PL(d0)` es **efectivo/sistémico**: absorbe placas, antenas, orientación y entorno del ensayo. No debe interpretarse como pérdida de espacio libre a 1 m.

## Validación externa incluida

Ejecuta:

```bash
python run_esp32_test002_validation.py
```

El script usa el canal implementado y compara contra la tercera corrida no usada para calibrar. El paquete entregado incluye una ejecución de 500 realizaciones por distancia en `results_esp32_test002_validation/`. Los cinco PDR y los cinco RSSI medios de la corrida retenida quedaron dentro de los intervalos predictivos del 95%.

La suite completa de v0.41 contiene **93 pruebas**. Para mantener reproducibilidad histórica, `run_v040_acceptance.py` y `run_v0401_validation.py` usan `config_v0401_reference.json` y siguen reproduciendo los chequeos de la versión anterior.

## Límites científicos importantes

La calibración TEST002 valida la capa **DATA RSSI/PDR** del enlace estático de dos ESP32 en el rango ensayado. Los ACK del firmware TEST002 eran mensajes de aplicación sobre ESP-NOW; por eso sus timeouts/stale ACK se preservan como evidencia experimental en `calibration/esp32_test002/esp32_test002_runs.csv`, pero no se presentan como una calibración exacta del ACK MAC interno del simulador. CCA, contención, retries nativos, captura/SINR y corrientes TX/RX/idle requieren experimentos específicos adicionales.

Documentos clave:

- `calibration/esp32_test002/CALIBRATION_REPORT.md`
- `calibration/esp32_test002/calibrated_parameters.json`
- `calibration/esp32_test002/esp32_test002_runs.csv`
- `V041_SCIENTIFIC_STATUS.md`
- `CHANGELOG_v0_41.md`

---

# WSN Edge-AI / D-STEP Simulator v0.40 — MAC Reliability

v0.40 toma como base la capa de medio validada en v0.39.1. Añade colas MAC finitas y confiabilidad unicast mediante DATA/ACK/retry sin modificar la política D-STEP.

## Qué cambia en v0.40

- Un radio por nodo atiende una trama lógica a la vez; las demás esperan en una FIFO configurable.
- `direct_to_sink` y cada salto de `multi_hop_to_sink` pueden utilizar ACK y retransmisiones.
- Los ACK ocupan el mismo medio, consumen energía y pueden perderse por interferencia o canal.
- Los broadcasts distribuidos continúan sin ACK por defecto.
- Se separa PDR físico por intento de `mac_unicast_delivery_ratio`, que mide entrega final después de retries.
- Se registran delay de cola, profundidad máxima, drops, retries, timeouts, ACKs, duplicados y energía asociada.

Configuración principal en `config.json`:

```json
"mac": {
  "mode": "csma_ca_lite",
  "queue_enabled": true,
  "queue_capacity": 16,
  "reliability": {
    "enabled": true,
    "ack_unicast": true,
    "ack_broadcast": false,
    "ack_bytes": 14,
    "sifs_s": 0.0002,
    "ack_timeout_s": 0.003,
    "retry_backoff_s": 0.0005,
    "max_retries": 3
  }
}
```

La prueba reproducible `run_v040_acceptance.py` genera `V040_ACCEPTANCE_REPORT.txt`. La suite contiene **86 pruebas**.

## Base PHY/MAC heredada de v0.39.1


La v0.39 parte de v0.38 y modifica la capa de comunicación que sustenta las métricas de colisión, PDR, latencia y energía. D-STEP, los modelos de evento, la movilidad, la batería y la GUI se conservan.

## Cambios científicos de v0.39

- Las transmisiones ocupan el medio durante su **airtime real**. Las colisiones ya no dependen de una ventana fija de 2 ms.
- La recepción se resuelve al finalizar el airtime, cuando ya se conocen todas las transmisiones temporalmente solapadas.
- Se calcula **SINR** con potencia deseada, interferencia concurrente y piso de ruido.
- El efecto de captura aparece cuando una señal mantiene SINR suficiente frente a interferentes más débiles.
- Se añade un **CSMA/CA-lite** independiente de D-STEP y del backoff del controlador adaptativo: CCA, binary-exponential backoff simplificado y límite de intentos.
- La CCA depende de la potencia realmente observable en el transmisor, por lo que el modelo puede reproducir **hidden terminals**.
- Una trama que supera sensibilidad consume energía RX aunque termine en colisión o error de canal. Las señales por debajo de sensibilidad permanecen dentro del presupuesto idle/listen.
- Se añaden métricas de MAC e interferencia: `mac_cca_busy`, `mac_backoff_events`, `mac_access_drops`, `interfered_receptions`, `mean_sinr_db` y `min_sinr_db`.
- El packet playback exporta también SINR e interferentes cuando están disponibles.
- Se añadieron cuatro pruebas físicas específicas de v0.39. La suite completa contiene **79 pruebas**.

## Parámetros nuevos

En `radio`:

```json
"noise_floor_dbm": -100.0,
"sinr_threshold_db": 6.0
```

En `mac`:

```json
{
  "mode": "csma_ca_lite",
  "cca_threshold_dbm": -82.0,
  "slot_time_s": 0.00032,
  "min_be": 3,
  "max_be": 5,
  "max_cca_attempts": 5
}
```

`collision_window_ms` se conserva por compatibilidad con configuraciones antiguas, pero la ruta científica v0.39 ya no lo usa para decidir colisiones.

## Validación v0.39

- 74/74 pruebas heredadas de v0.38 aprobadas sin cambios.
- 4 pruebas nuevas: colisión simétrica por solapamiento, captura por SINR, energía RX en colisión y geometría de hidden terminal.
- Resultado total: **78/78 pruebas aprobadas**.

---

# WSN Edge-AI / D-STEP Simulator v0.38 — Saved Configurations + Optional Node Mobility

La v0.38 conserva las capacidades de v0.29 y añade un gestor local de configuraciones reproducibles. La movilidad sigue siendo totalmente opcional y el modo `static` mantiene el comportamiento previo.

## Nuevo en v0.38: configuraciones guardadas

- Panel **Configuraciones guardadas** en la GUI.
- Guarda la configuración completa con un nombre definido por el usuario.
- Archivos JSON persistentes en `configurations/`.
- Conserva parámetros de red, seed, área, posiciones, algoritmo, plugins y sus parámetros, radio, canal, arquitectura, evento y movilidad.
- **Cargar** restaura la GUI/topología pero **no ejecuta** una simulación.
- **Eliminar** permite limpiar configuraciones antiguas.
- Una configuración existente requiere confirmación explícita antes de ser reemplazada.
- Cada archivo registra fechas de creación/actualización y versión del simulador.

## Base heredada de v0.29 — Optional Node Mobility

La v0.29 conserva íntegramente las capacidades de v0.28 y añade una capa opcional de movilidad de nodos. Por defecto, `mobility.model = "static"` y `speed_m_s = 0.0`, de modo que las simulaciones existentes conservan el comportamiento estático anterior.

Modelos disponibles: **Static, Linear, Random Walk y Random Waypoint**. La velocidad se configura en m/s y la GUI permite ajustar intervalo de actualización, dirección lineal, intervalo de cambio de dirección y porcentaje de nodos móviles. Al cambiar `Node.position`, el motor ya existente recalcula implícitamente las condiciones de radio, vecinos, routing y sensado usando la geometría vigente.

La GUI registra y reproduce eventos de movimiento. Consulte `CHANGELOG_v0_29.md` para detalles y validación.

## Validación v0.29

- Regresión Static contra v0.28: resultados idénticos con misma seed/configuración.
- Reproducibilidad de Random Walk y Random Waypoint por seed.
- Movimiento lineal a velocidad configurable comprobado.
- **47/47 pruebas automatizadas aprobadas.**

---

# WSN Edge-AI / D-STEP Simulator v0.28 — Resource-Aware & Adaptive Execution

La v0.28 conserva el motor científico y el paralelismo de v0.27.1, y añade una capa de ejecución consciente de recursos. Antes de iniciar una campaña comprueba CPU, RAM y espacio libre en disco, estima un número seguro de workers y bloquea configuraciones manuales que excedan el margen actual del equipo.

Durante la campaña, la concurrencia se adapta de forma conservadora: el pool puede tener capacidad para varios workers, pero el sistema reduce o pausa el lanzamiento de **nuevas corridas** cuando detecta presión elevada de RAM/CPU. Las corridas ya iniciadas terminan normalmente y los resultados continúan guardándose de forma incremental. Cuando el margen se recupera, la concurrencia vuelve a aumentar.

## Resource-Aware Execution

- Detección automática de procesadores lógicos.
- Comprobación de RAM física disponible.
- Comprobación de espacio libre en disco.
- `Workers = Auto` basado en CPU + RAM, con máximo conservador de 8 por defecto.
- Bloqueo preventivo si la RAM libre cae por debajo del margen mínimo o hay menos de 512 MB libres en disco.
- Los workers manuales se rechazan si exceden la recomendación segura actual.
- Ajuste dinámico del número de corridas simultáneas sin matar corridas en curso.
- Estado visible en la GUI: GOOD / LIMITADO / BLOQUEADO.
- Registro de ajustes de concurrencia en `campaign_state.json`.

## Filosofía

El objetivo no es ocupar el 100 % de la máquina, sino alcanzar el máximo rendimiento sostenible manteniendo margen para el sistema operativo y otras aplicaciones. La ejecución científica, seeds y métricas no cambian por la adaptación de recursos; solo cambia cuántas corridas independientes se ejecutan simultáneamente.

## Validación v0.28

- 44/44 pruebas automatizadas aprobadas.
- Campaña paralela real de integración completada 4/4, 0 fallos.
- Verificado que el estado de recursos y el límite activo de workers se publican durante la campaña.


La v0.27.1 conserva el motor científico y toda la GUI de v0.26, y paraleliza las corridas independientes de las campañas Batch/Monte Carlo. El investigador puede elegir **CPU paralela** o **CPU secuencial**. En paralelo, `Workers = Auto` detecta los procesadores lógicos y selecciona un número conservador de procesos (máximo 8 por defecto, dejando margen al sistema operativo y al navegador).

Cada corrida recibe su `run index` y `seed` **antes** de entrar al pool de procesos. Por tanto, el orden en que terminan los workers no altera el escenario científico. Los CSV se ordenan de nuevo por número de corrida antes de exportarse.

Se mantienen progreso, ETA, pausa, continuación, cancelación, guardado incremental y recuperación tras una interrupción. `campaign_config.json` registra ahora el modo de ejecución, workers solicitados/efectivos y CPUs lógicas detectadas.

> Para campañas muy pequeñas, el modo secuencial puede ser más rápido debido al costo de iniciar procesos. Para campañas de decenas, cientos o miles de corridas, CPU paralela es el modo recomendado.

## Validación v0.27.1

**40/40 pruebas aprobadas.** Una prueba específica ejecuta la misma matriz en secuencial y paralelo y comprueba que los resultados por corrida sean idénticos. En un benchmark interno corto de 40 corridas D-STEP se observó aproximadamente **1.9×** de aceleración con 4 workers (el speedup real depende del procesador, RAM y complejidad de la campaña).

---

# WSN Edge-AI / D-STEP Simulator v0.26 — Asynchronous Experiment Manager + Python Algorithm Plugin API

Esta versión parte directamente de la v0.23 verificada y añade una API estable para algoritmos externos en Python. El investigador puede cargar un archivo `.py` desde la GUI sin modificar el motor. La API expone contexto de nodo, envío según arquitectura, broadcast, envío/routing al sink, vecinos, energía, tiempo, potencia TX y declaración explícita de detección/alerta.

Incluye **Delta Event** como ejemplo breve: transmite solo cuando la muestra supera un umbral y cambia al menos `min_delta` respecto al último reporte. Sus parámetros aparecen automáticamente en la GUI.

Los plugins declaran sus arquitecturas compatibles y la GUI/servidor rechazan combinaciones inválidas. Los parámetros y metadatos del plugin quedan incluidos en la configuración y exportación del experimento. Consulte `ALGORITHM_PLUGIN_GUIDE.md`.

> Seguridad local: un plugin Python es código ejecutable. Cargue únicamente algoritmos propios o de fuentes de confianza.

## Validación v0.25

**36/36 pruebas aprobadas**, incluyendo descubrimiento y ejecución del plugin de ejemplo, además de las pruebas previas de arquitectura/routing.

---

# WSN Edge-AI / D-STEP Simulator v0.22.1 — Network Health / Scenario Validation

La v0.22.1 conserva el motor científico v0.16 y añade un diagnóstico no intrusivo del escenario antes y después de ejecutar. La GUI calcula en paralelo **conectividad geométrica** y **conectividad nominal por link budget**, independientemente del modo de conectividad elegido para la simulación.

## Network Health

- **Conectividad geométrica:** grafo por distancia usando `neighbor_radius_m`, editable como *Radio geométrico (m)*.
- **Conectividad radio/link:** enlace nominal cuando el RSSI medio del modelo de canal alcanza la sensibilidad RX, respetando `max_geometric_range_m` si existe.
- **Alcance al sink:** porcentaje de nodos con una ruta multi-hop nominal hasta el sink.
- Nodos aislados, componentes conectadas y grado medio para ambos grafos.
- Distancia media y máxima entre pares de nodos.
- Advertencias de escenario fragmentado, nodos aislados, sink no alcanzable o discrepancia entre geometría y canal.

El diagnóstico es solo observacional: **no cambia el canal, la topología, el algoritmo ni los resultados de la corrida**. Su objetivo es ayudar a separar un problema de despliegue/topología de un problema de propagación/radio.

## Reproducibilidad y exportación

Se mantienen el constructor visual, playback temporal, Ground Truth vs conocimiento D-STEP, perfiles multi-radio y exportación completa del dataset científico por corrida.

## Arranque

Use `START_GUI.bat` en Windows o `python gui_server.py`. Si el puerto 8765 está ocupado, el servidor selecciona automáticamente el siguiente puerto libre.

## Validación

La batería del núcleo continúa pasando: **26/26 pruebas**.

---

# WSN Edge-AI / D-STEP Simulator v0.20 — Ground Truth vs Distributed Knowledge

## Interfaz interactiva v0.20

Esta versión conserva el motor científico v0.16 y amplía el playback v0.18 con una capa comparativa Ground Truth vs conocimiento distribuido. El motor no se reescribe: la GUI registra y reproduce los eventos que realmente ocurrieron durante la ejecución.

### Funciones de la interfaz

- área física dibujada a escala;
- topología aleatoria, manual o mixta con arrastre de nodos;
- número de nodos, semilla y sink configurables;
- políticas `periodic`, `event_driven`, `central_edge`, `distributed_edge` y `dstep`;
- TX, sensibilidad RX, bitrate, payload y link budget;
- selección de modelo de canal y perfil de entorno;
- configuración del evento radial;
- visualización de enlaces nominales;
- exportación de `config.json`;
- ejecución directa del motor Python;
- reproducción temporal de la ejecución con play/pausa, scrubber y velocidades 0.5x–20x;
- frente físico del evento `r(t)=v(t-t0)`;
- visualización de intentos de transmisión y recepción;
- estados D-STEP `NORMAL`, `SUSPECT`, `VERIFY`, `CONFIRMED` y `PROPAGATE`;
- inspección temporal por nodo de confianza, creencia, energía y TX/RX;
- origen real y origen estimado por D-STEP superpuestos;
- frente físico real y frente estimado;
- velocidad y t0 reales frente a estimados;
- error instantáneo de origen, velocidad y t0;
- curva temporal del error de localización del origen;
- nodos físicamente alcanzados por el fenómeno pero aún no detectados;
- llegada real y llegada predicha para el nodo seleccionado.

### Trazador no intrusivo

`gui_server.py` usa `TraceSimulator`, una subclase de observación. La lógica de `Simulator`, `EventEngine`, las políticas y el modelo de radio permanecen sin cambios. El trazador registra muestras, decisiones, intentos de recepción, recepciones y entregas al sink para que la animación corresponda con la misma corrida que genera las métricas.


### Definición de “conocimiento distribuido” en la GUI

La interfaz **no entrega ground truth a D-STEP**. Cada nodo sigue calculando localmente `est_origin`, `est_t0`, `est_speed`, `est_direction` y `est_eta` usando solo sus detecciones y mensajes recibidos. Para visualizar una única estimación de red, la GUI selecciona en cada instante la mejor estimación local disponible, priorizando: (1) mayor número de evidencias usadas, (2) nodo confirmado, (3) mayor creencia y (4) mayor confianza. Esta selección es exclusivamente observacional y no modifica la simulación ni retroalimenta a los nodos.

El Ground Truth se usa únicamente para comparación visual y cálculo de errores después/durante la observación de la corrida.

### Ejecutar la GUI

Windows:

```bat
START_GUI.bat
```

Linux/macOS:

```bash
./START_GUI.sh
```

o:

```bash
python gui_server.py
```

La interfaz se sirve localmente en `http://127.0.0.1:8765/`.

### Validación

La batería del núcleo continúa pasando: **26/26 pruebas**.

---

## Historial técnico del núcleo

# WSN Edge-AI Simulator v0.5

Versión enfocada en dos problemas detectados en v0.4:

1. degradación del ahorro de transmisiones al aumentar la densidad;
2. error elevado en estimación de origen/velocidad.

## D-STEP v0.5

### 1. Estimación robusta del evento

La estimación ya no usa un único centroide.

Se generan varios candidatos de origen a partir de:

- detecciones más tempranas;
- centroide ponderado temporalmente.

Para cada candidato se ajusta:

`arrival_time = t0 + distance/speed`

y se calcula un error residual robusto.

Luego:

- se estima MAD;
- se eliminan outliers;
- se recorta una fracción de los mayores residuos;
- se reajustan `t0` y `speed`;
- se selecciona el candidato con menor residual mediano.

Todo continúa usando únicamente información disponible en los nodos.

### 2. Density-aware forwarding

El forwarding incluye un factor de densidad local:

`density_factor = (reference_degree / max(reference_degree, degree))^exponent`

con un mínimo configurable.

Así, cuantos más vecinos tenga un nodo, más exigente se vuelve el reenvío.

### 3. Suppression + backoff

Los nodos:

- retrasan el forwarding según score y densidad;
- cancelan un forwarding pendiente si oyen evidencia equivalente;
- suprimen mensajes con confianza y tiempo suficientemente similares;
- contabilizan `suppressed_tx`.

Esto busca evitar que muchos nodos densos retransmitan la misma evidencia.

## Ground truth

D-STEP sigue sin acceso al:

- origen verdadero;
- velocidad verdadera;
- ETA verdadera;
- estado global del fenómeno.

El ground truth solo se usa en `metrics/`.

## Métricas adicionales

- `suppressed_tx`
- error de origen;
- error de velocidad;
- error ETA;
- `ΔE_AI`;
- reducción de TX y energía frente a event-driven.

## Monte Carlo

La distribución viene con:

```json
"monte_carlo_runs": 5
```

para validación rápida.

Para experimentos:

```json
"monte_carlo_runs": 20
```

o más.

## Ejecutar

```bash
py run_experiment.py
```

## Monte Carlo 20

Esta variante fue configurada y ejecutada con 20 corridas por configuración.

Archivos adicionales:
- `results/statistical_summary_event_vs_dstep.csv`
- `results/paired_reduction_summary.csv`


## v0.6 - Ablation Study

Esta variante incorpora un experimento de ablación de D-STEP.

Modos evaluados:

- `full`: D-STEP completo.
- `no_density`: sin factor adaptativo de densidad.
- `no_suppression`: sin supresión de mensajes equivalentes.
- `no_backoff`: sin backoff adaptativo.
- `no_voi`: VoI deshabilitado.
- `no_consensus`: consenso espacio-temporal deshabilitado.

El diseño usa las mismas semillas para cada variante dentro de cada tamaño de red,
permitiendo comparación pareada.

### Ejecutar validación rápida

```bash
py run_ablation.py
```

La distribución viene con 5 corridas por configuración para validación rápida.

### Ejecutar MC20

Cambiar en `config.json`:

```json
"monte_carlo_runs": 20
```

y volver a ejecutar:

```bash
py run_ablation.py
```

### Resultados

```text
results_ablation/ablation_raw.csv
results_ablation/ablation_summary.csv
results_ablation/ablation_paired_effects.csv
```

Interpretación de `ablation_paired_effects.csv`:

- `tx_increase_vs_full_pct_mean > 0`: quitar ese componente aumenta transmisiones.
- `energy_increase_vs_full_pct_mean > 0`: quitar ese componente aumenta energía.
- `collision_increase_vs_full_pct_mean > 0`: quitar ese componente aumenta colisiones.
- `f1_change_vs_full_mean < 0`: quitar ese componente empeora F1.
- `dcr_change_vs_full_mean < 0`: quitar ese componente empeora cumplimiento de deadline.


## v0.6.1 - Radio/broadcast accounting correction

A wireless broadcast is now counted physically as:

- one TX frame at the sender;
- zero or more reception attempts at neighbors;
- one RX energy charge per successful reception.

The old over-counting `N_neighbors × TX` has been removed.

A parameter reference file is included as:

`simulation_parameters.csv`

The current radio values remain exploratory model parameters and are not yet
a hardware-calibrated ESP32-S3 / ESP-NOW profile.


## v0.7 - Barrido paramétrico de break-even

Se añadió `run_parameter_sweep.py`.

Barrido configurable de:

- `tx_power_dbm`
- `energy_mj.infer`
- `neighbor_radius_m`
- número de nodos

Comparación pareada:

- `event_driven`
- `dstep`

Métrica principal:

`ΔE_AI = E_inteligencia_adicional - E_comunicación_evitada`

Interpretación:

- `ΔE_AI < 0` => ahorro energético neto.
- `ΔE_AI > 0` => el costo de inteligencia supera el ahorro de radio.

Archivos:

```text
results_sweep/sweep_raw.csv
results_sweep/sweep_paired.csv
results_sweep/sweep_summary.csv
results_sweep/break_even_frontier.csv
```

La distribución incluye 1 corrida por punto para validación rápida.
Para experimentos robustos cambie `runs_per_point` a 5, 10 o 20.

Importante: `tx_power_dbm` modifica RSSI y probabilidad de recepción, pero todavía
no modifica automáticamente `energy_mj.tx_base`. Esa relación se calibrará con
mediciones físicas del hardware.


## v0.8 — Modular channels, environments and spatial coverage

D-STEP is unchanged. The simulator now decouples **algorithm**, **channel**, **environment**, **topology**, and **sensing coverage**.

### Channel plugins
`free_space`, `log_distance`, `log_normal`, `two_ray`, `rayleigh`, `rician`, `nakagami`.

### Environment presets
`custom`, `open_field`, `forest`, `urban`, `industrial`, `open_water`. Presets are editable starting points, not claims that one parameter set universally represents an environment.

### Spatial metrics
Node density, nearest-neighbor distance, neighbor distance, mean/min/max degree, isolated nodes, connected components, largest-component fraction, and grid-estimated sensing coverage. `R_sense` is kept separate from `R_comm`.

### Reproducibility
Topology, sensor, and channel randomness use independent streams derived from the same scenario seed, so policy-dependent radio calls do not alter the sensor sequence or node placement.

### Channel sweep
Run:
```bash
py run_channel_sweep.py
```
Outputs:
```text
results_channel/channel_raw.csv
results_channel/channel_summary.csv
results_channel/coverage_summary.csv
results_channel/robustness_by_channel.csv
```
For large-area sweeps the event origin and maximum event radius are scaled with the area so channel/topology comparisons are not confounded by an event that never reaches most nodes.

### Manual node placement
Set `topology.placement` to `manual` and provide exactly N `[x,y]` positions in `topology.manual_positions`. This is the backend hook intended for the future HTML interface.


## v0.9 - Critical communication radius / operational frontier

This release adds a dedicated experiment to quantify the transition between:

- connectivity-limited regime;
- channel-limited regime;
- operational regime.

### Main experiment

```bash
py run_critical_radius_sweep.py
```

The sweep varies:

- simulated area;
- node count;
- communication radius;
- wireless channel model;
- transmit power.

### Operational criteria

By default, a configuration is considered operational when:

```text
largest connected component >= 0.95
F1 >= 0.95
DCR >= 0.95
```

These values are configurable in `config.json`.

### Outputs

```text
results_critical_radius/
    critical_radius_raw.csv
    critical_radius_summary.csv
    critical_radius_frontier.csv
```

### New quantities

`critical_topological_radius_m`

The minimum tested communication radius at which the largest connected
component contains at least the configured fraction of nodes.

`critical_operational_radius_m`

The minimum tested communication radius at which connectivity, F1 and DCR
simultaneously satisfy the operational thresholds.

This distinction is intentional: a network may be geometrically connected
but still fail because of channel conditions or algorithmic behavior.

### Scientific use

The experiment allows comparison of:

- sparse long-range deployments;
- dense short-range deployments;
- different environment/channel conditions;
- the effect of area scaling on D-STEP;
- the boundary between topology-limited and channel-limited operation.

D-STEP itself is not modified in v0.9.


## v0.10 - Link-budget-derived connectivity

Connectivity is no longer primarily imposed through a fixed communication radius.

In `link_budget` mode:

`mean RSSI = TX power - path loss`

A nominal link exists when:

`mean RSSI >= receiver_sensitivity_dbm`

Instantaneous packet reception additionally includes the selected channel's
shadowing/fading and the receiver sensitivity model.

### Main parameters

```json
"connectivity_mode": "link_budget",
"receiver_sensitivity_dbm": -90.0,
"sensitivity_slope": 0.35,
"max_geometric_range_m": null
```

`neighbor_radius_m` is retained only for backwards-compatible geometric mode.

### New experiment

```bash
py run_link_budget_sweep.py
```

Outputs:

```text
results_link_budget/link_budget_raw.csv
results_link_budget/link_budget_summary.csv
results_link_budget/critical_tx_power_frontier.csv
```

The frontier estimates the minimum tested TX power required for topological
and operational success for each area, node count, channel, and receiver
sensitivity.

TX power still does not automatically alter TX energy consumption; hardware
calibration is required before coupling dBm to current/airtime energy.


## v0.11 - Per-node adaptive radio control

This release adds per-node dynamic TX power as an algorithm/control variable.

A node does not directly control RSSI. It controls TX power; RSSI is the
result observed at receivers after path loss, shadowing, fading and distance.

### Per-node state

Each node now maintains:

```text
tx_power_dbm
last_feedback_rssi_dbm
last_feedback_success_rate
radio_power_changes
radio_power_increases
radio_power_decreases
tx_power_history
```

### Radio controllers

```text
fixed
rule_based_adaptive
```

The adaptive controller raises or lowers TX power using receiver RSSI/success
feedback and configurable link-margin thresholds.

### Configuration

```json
"radio_control": {
  "mode": "rule_based_adaptive",
  "power_levels_dbm": [-20,-10,0,10,20],
  "initial_tx_power_dbm": 0,
  "target_link_margin_db": 8.0,
  "high_link_margin_db": 15.0,
  "min_success_rate": 0.80,
  "high_success_rate": 0.95
}
```

### Algorithm-level hook

Policies/plugins may explicitly request a node power level through:

```python
sim.set_node_tx_power(node, power_dbm)
```

Thus future algorithms, including an MLP-based controller, can control the
radio without modifying the propagation model.

### Feedback abstraction

v0.11 uses idealized receiver RSSI/success feedback after transmissions.
This is intentionally protocol-agnostic; a future hardware/protocol profile
can map it to ACK/telemetry mechanisms.

### TX energy

Adaptive power changes propagation and connectivity immediately.

TX energy remains constant by default. If measured hardware data is available,
populate:

```json
"tx_energy_by_power_mj": {
  "-10": 0.25,
  "0": 0.35,
  "10": 0.50
}
```

The simulator will then use the nearest calibrated energy point. No uncalibrated
dBm-to-energy relationship is invented.

### Experiment

```bash
py run_adaptive_power_sweep.py
```

Outputs:

```text
results_adaptive_power/
  adaptive_power_raw.csv
  adaptive_power_summary.csv
  adaptive_vs_fixed.csv
```

This compares D-STEP with fixed vs adaptive per-node TX power under matched
topology/channel seeds.


## v0.12 - Channel-aware adaptive radio

v0.12 corrects the main weakness found in v0.11: low delivery success is no
longer interpreted automatically as a reason to increase TX power.

The controller distinguishes three causes:

```text
weak RSSI / below sensitivity  -> increase TX power
collision / congestion         -> backoff or wait; do not increase power
channel fading/loss            -> backoff first; power increase only if margin is weak
```

When the link has excessive margin and high success, power may be reduced.

### Relevant-link feedback

Broadcast feedback is computed from the nearest configurable set of relevant
receivers instead of all nodes in the simulation:

```json
"feedback_neighbor_count": 4
```

The physical broadcast can still reach any candidate receiver.

### Joint radio actions

The node can now adapt:

```text
TX power
backoff
wait/delay before TX
```

These actions are separate from D-STEP's sensing/event logic.

### Independent control RNG

Adaptive backoff uses its own random stream, preserving the independence of:

```text
topology RNG
sensor RNG
channel RNG
radio-control RNG
```

### Experiment

```bash
py run_channel_aware_sweep.py
```

It compares:

```text
fixed
rule_based_adaptive        # v0.11 naive baseline
channel_aware_adaptive     # v0.12
```

under matched seeds.

Outputs:

```text
results_channel_aware/
  channel_aware_raw.csv
  channel_aware_summary.csv
  channel_aware_vs_fixed.csv
```

### Feedback abstraction

RSSI/collision/success feedback is still an idealized protocol-agnostic
abstraction. Mapping to real ESP-NOW ACK/telemetry or another MAC/radio
technology is a later hardware-calibration step.

### Energy caveat

TX power changes propagation immediately. TX energy is still power-independent
unless `tx_energy_by_power_mj` is populated with measured hardware data.


## v0.13 - Intelligent WSN / intelligence-stack benchmark

This release changes the research framing.

Adaptive communication is no longer treated as a separate competitor to
D-STEP. It is one capability of the complete intelligent distributed WSN.

### External baselines

The benchmark keeps conventional/non-intelligent algorithms outside D-STEP:

```text
periodic
event_driven
distributed_edge
```

### Progressive D-STEP intelligence stack

```text
DSTEP_0_LOCAL
  local inference + basic evidence dissemination

DSTEP_1_CONSENSUS
  + decentralized spatiotemporal consensus

DSTEP_2_VOI
  + value-of-information communication decisions

DSTEP_3_PREDICTION
  + robust event estimation + ETA prediction

DSTEP_4_NETWORK_ADAPTIVE
  + density-aware forwarding, suppression and backoff

DSTEP_FULL
  + channel-aware per-node TX-power/backoff adaptation
```

These are not separate proposed algorithms. They are progressive configurations
of the same intelligent WSN used to quantify the marginal value of each
capability.

### Central research question

Does the additional local/distributed intelligence produce enough improvement
in reliability, deadline compliance, communication cost, energy and robustness
to justify its computational cost?

### Benchmark

```bash
py run_intelligence_benchmark.py
```

Outputs:

```text
results_intelligence_stack/
  intelligence_raw.csv
  intelligence_summary.csv
  full_vs_baselines.csv
  intelligence_layer_contribution.csv
```

`full_vs_baselines.csv` answers whether the complete intelligent WSN beats
the conventional comparison algorithms.

`intelligence_layer_contribution.csv` quantifies the marginal effect of adding
each successive intelligence layer.

### Fairness

Matched scenarios use the same seed. The simulator retains independent random
streams for topology, sensing, channel and radio-control backoff.

### Important energy caveat

The computational energy costs are modeled explicitly. TX-power-dependent
radio energy is used only when calibrated measurements are supplied in
`tx_energy_by_power_mj`. Therefore the simulator does not fabricate a physical
dBm-to-energy relationship.


## v0.14 - Monte Carlo intelligence validation

No new D-STEP capability is added here. This version formalizes the statistical
validation of the intelligent WSN against non-intelligent/classical baselines.

Default design:

```text
N = 20, 50, 100
areas = 100x100 m, 500x500 m
channels = Log-normal, Rician
20 matched Monte Carlo runs per point
```

Run:

```bash
py run_mc_intelligence_validation.py
```

Outputs:

```text
results_mc_intelligence/
  mc_intelligence_raw.csv
  mc_intelligence_summary.csv
  full_vs_baselines_statistics.csv
  intelligence_layer_statistics.csv
```

For the principal metrics the analysis reports mean, standard deviation,
approximate 95% confidence intervals, paired mean differences, paired Cohen's dz,
and Wilcoxon signed-rank p-values when SciPy is available.

Matched seeds are used across algorithms within each scenario/run.

## v0.15 - Calibrated adaptive TX energy

D-STEP logic is unchanged. TX energy is now power-dependent using the supplied
3.3 V / 1.26 ms table:

- -10 dBm: 0.311850 mJ
- 0 dBm: 0.415800 mJ
- 10 dBm: 0.582120 mJ
- 20 dBm: 0.997920 mJ

Formula: `E_mJ = V * I_mA * t_ms / 1000`.

Scope: these values correspond to the supplied 802.11b example and are not
presented as measured ESP-NOW calibration.

Run `py run_calibrated_energy_validation.py`.

Outputs are written to `results_calibrated_energy/`, including a matched
uncalibrated reference to isolate the impact of the energy model.


## v0.16 - Computational break-even frontier

No new D-STEP capability is introduced.

This version asks:

```text
How expensive can local/distributed intelligence become before DSTEP_FULL
loses its total-energy advantage over each baseline?
```

The experiment multiplies only these intelligence-specific energy components:

```text
infer
consensus
estimate
prediction
```

by a common scale factor. Sensing, preprocessing, RX, TX and idle costs are not
scaled. The calibrated TX-power energy table from v0.15 is preserved.

Default tested scales:

```text
0.10, 0.25, 0.50, 0.75, 1.00, 1.25, 1.50, 2.00, 3.00, 4.00
```

Run:

```bash
py run_compute_break_even.py
```

Outputs:

```text
results_compute_break_even/
  compute_break_even_raw.csv
  compute_break_even_summary.csv
  compute_break_even_paired.csv
  compute_break_even_frontier.csv
```

`compute_break_even_frontier.csv` reports, for each scenario and baseline:

- highest tested compute-cost scale where DSTEP_FULL total energy is no greater
  than the baseline while F1/DCR remain above the configured thresholds;
- an interpolated zero-crossing estimate when the tested grid brackets it;
- mean D-STEP AI-compute energy at the tested frontier.

This experiment changes only the energy accounting of intelligence-related
processing. It does not alter D-STEP decisions or channel behavior.

---

## v0.17 Interactive Scenario Builder

This package includes a dependency-free local browser interface that sits on top of the existing v0.16 simulation engine.

### Start the GUI

**Windows**

Double-click `START_GUI.bat`, or run:

```bash
python gui_server.py
```

**macOS / Linux**

```bash
./START_GUI.sh
```

The interface opens at `http://127.0.0.1:8765/`.

### v0.17 GUI capabilities

- Configure node count, physical area, sink position and reproducible random seed.
- Select `periodic`, `event_driven`, `central_edge`, `distributed_edge`, or `dstep`.
- Configure TX power, RX sensitivity, bitrate, payload and connectivity mode.
- Select the channel model: Free Space, Log Distance, Log Normal, Two Ray, Rayleigh, Rician or Nakagami.
- Select environment profiles: Custom, Open Field, Forest, Urban, Industrial or Open Water.
- Configure event origin, start time, propagation speed, maximum radius, simulation time, sampling period and deadline.
- Generate topologies to scale, inspect node coordinates, display nominal links, drag nodes in mixed/manual mode, or place nodes manually.
- Run the existing Python simulator and visualize F1, DCR, energy, packet counts, alert delay, collisions and sensitivity losses.
- Export the visual experiment as a reproducible `config.json` with exact manual node coordinates.

### Reproducibility rule

When the GUI generates random positions it uses the same topology RNG convention as the simulator (`seed + 100003`) and then freezes the generated coordinates as `manual_positions`. Therefore, the topology displayed by the browser is the topology executed by the simulator.

The original v0.16 scientific engine remains unchanged; the GUI is an integration layer.


## v0.20 - Research dataset export
Every GUI simulation is automatically preserved under `results/gui_experiments/<experiment_id>/` and packaged as a ZIP. The GUI exposes direct download buttons for the complete ZIP and each component file.

Files per experiment:
- `summary.csv`: one-row experiment-level metrics.
- `event_trace.csv`: full temporal observation trace.
- `packets.csv`: packet-by-packet TX/RX attempt log including RSSI, delay, outcome and failure reason.
- `node_states.csv`: sensor samples, decisions and received-message state evolution.
- `estimates.csv`: D-STEP origin/speed/t0 estimates plus errors against Ground Truth.
- `nodes_final.csv`: final node positions and counters.
- `config.json`: exact effective configuration for reproducibility.
- `metadata.json`: simulator version, experiment ID, UTC timestamp, policy, seed and trace status.

The ZIP contains the same files in one portable experiment directory.

## v0.21 — Multi-Radio WSN Profiles

The GUI now separates the WSN/Edge-AI algorithms from the underlying radio technology. Available profiles:

- **ESP-NOW / ESP32** — experimentally calibrated TX energy table from the project measurements.
- **LoRa / Semtech SX1262** — datasheet-based current/sensitivity plus LoRa time-on-air calculation using SF, BW, CR, preamble, CRC and payload.
- **Bluetooth LE / Nordic nRF52840** — datasheet-based TX/RX current and sensitivity.
- **Zigbee / IEEE 802.15.4 / TI CC2652R** — datasheet-based TX/RX current and 250 kbps PHY.
- **Sigfox 0G RC4 / STM32WL55** — STM32WL electrical data combined with Sigfox RC4 protocol rate. This is marked `datasheet_plus_protocol`, not experimentally calibrated.
- **Custom / Generic** — user-defined profile.

Every research export records `radio_profile` and its evidence class in `metadata.json`. `radio_profiles_reference.csv` records the provenance used for the built-in profiles.

For profiles using the current/airtime model:

`E_TX [mJ] = V [V] × I_TX [mA] × T_air [s]`

`E_RX [mJ] = V [V] × I_RX [mA] × T_air [s]`

ESP-NOW retains the experimentally calibrated per-packet TX table. These radio profiles do not imply that every protocol detail of LoRaWAN, Zigbee, BLE or Sigfox network stacks is modeled; they provide PHY/radio-energy profiles for controlled WSN comparisons.


## v0.21.1 startup reliability fix
If port 8765 is already occupied by an older GUI instance, the server now automatically selects the next available local port and opens that exact URL. This prevents the browser from accidentally communicating with a stale backend and avoids `Failed to fetch`/version-mismatch errors.


## v0.22.1 UI/link-view fix
- Network Health moved immediately above the network canvas for visibility.
- Link rendering split into Radio/link, Geometric, and Simulation-mode views.
- Sink links are now included in the visual graph.
- Radio links are deterministic mean-link-budget links (mean RSSI >= RX sensitivity); stochastic fading still affects packet delivery during simulation, not the nominal preview.

## v0.23 — Communication architectures and sink routing

The interactive GUI adds an explicit communication-architecture selector while preserving the legacy behavior of v0.22.1 when no architecture is supplied.

Supported architectures:

- **Distributed / peer-to-peer**: one-hop physical broadcast among neighboring nodes. This is required by `distributed_edge` and `dstep` because their decisions depend on evidence exchanged among peers.
- **Direct-to-Sink**: every application report attempts one physical node-to-sink transmission. No relay is used.
- **Multi-hop-to-Sink**: the simulator finds a deterministic shortest-hop nominal route to the sink. Every hop is then executed through the normal physical radio model, so sensitivity, fading, channel loss, collision, airtime and TX/RX energy still apply.

Compatibility matrix:

| Policy | Distributed/P2P | Direct-to-Sink | Multi-hop-to-Sink |
|---|---:|---:|---:|
| periodic | yes | yes | yes |
| event_driven | yes | yes | yes |
| central_edge | no | yes | yes |
| distributed_edge | yes | no | no |
| dstep | yes | no | no |

Routing diagnostics include sink reachability, direct-to-sink fraction, mean/max hops to sink, no-route counters and hop-level delivery counters. The GUI also provides a **Rutas al sink** link view.

Important distinction: route construction uses the **nominal connectivity graph**. A route being available does not imply successful delivery. Each hop is subjected to the actual configured channel and radio model at run time.


## Experiment Manager (v0.25)
La GUI incorpora un modo de campañas experimentales por lotes/Monte Carlo inspirado en la capacidad de barrido de la v0.16. El investigador puede combinar listas de números de nodos, áreas, algoritmos (incluidos plugins Python), modelos de canal, perfiles de radio y repeticiones.

La matriz por defecto reproduce el espíritu del benchmark original: 20/50/100 nodos, áreas 100x100 y 500x500 m, Log-Normal/Rician y 20 repeticiones. El total de simulaciones se calcula antes de ejecutar.

Cada campaña guarda `campaign_results.csv` (una fila por corrida), `aggregate_summary.csv` (media y desviación estándar por combinación), `experiment_matrix.csv`, `failures.csv`, `campaign_config.json` y un ZIP completo bajo `results/gui_campaigns/`. Para velocidad y tamaño, las campañas no generan playback/trazas completas por corrida; el modo individual continúa disponible para análisis temporal detallado.

La opción de arquitectura `Automática por algoritmo` preserva la arquitectura natural: D-STEP/Distributed Edge usan peer-to-peer; Central Edge usa una arquitectura hacia el sink; Periodic/Event Driven utilizan la arquitectura seleccionada cuando es compatible.


## v0.26 — Campañas robustas

Las campañas de la GUI se ejecutan ahora en segundo plano. La interfaz consulta progreso, tiempo transcurrido y ETA sin mantener abierta una petición HTTP durante toda la campaña. Los CSV se actualizan después de cada corrida. Una campaña puede pausarse, cancelarse y reanudarse; tras reiniciar el servidor, una campaña incompleta queda marcada como interrumpida y puede continuar saltando los índices ya guardados.