import csv, math, random
from pathlib import Path
from collections import defaultdict
from statistics import mean, stdev
try:
 from scipy.stats import wilcoxon
except Exception:
 wilcoxon=None
ROOT=Path(__file__).parent; OUT=ROOT/'results_v050_core_holdout'
files=[OUT/'core_raw_00_09.csv',OUT/'core_raw_10_19.csv',OUT/'core_raw_20_29.csv']
rows=[]
for f in files:
 with open(f,newline='',encoding='utf-8') as fh: rows.extend(list(csv.DictReader(fh)))
# numeric conversion helpers
def num(r,k):
 v=r.get(k,'')
 try:return float(v)
 except:return float('nan')
def bootstrap_ci(vals,seed=1,B=5000):
 vals=[float(x) for x in vals if not math.isnan(float(x))]
 if not vals:return (float('nan'),float('nan'))
 rng=random.Random(seed); n=len(vals); bs=[]
 for _ in range(B): bs.append(mean(vals[rng.randrange(n)] for _ in range(n)))
 bs.sort(); return bs[int(.025*B)],bs[min(B-1,int(.975*B))]
def dz(vals):
 if len(vals)<2:return float('nan')
 sd=stdev(vals)
 return mean(vals)/sd if sd>1e-12 else (float('inf') if mean(vals)>0 else float('-inf') if mean(vals)<0 else 0.0)
# combined raw
keys=list(rows[0].keys())
with open(OUT/'core_raw.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
# summary
summary=[]
for e in ['deterministic','physical_pulse','absent']:
 for n in [20,50,100]:
  for p in ['dstep','dstep_payoff']:
   z=[r for r in rows if r['event_model']==e and int(float(r['nodes']))==n and r['policy']==p]
   entry={'event_model':e,'nodes':n,'policy':p,'runs':len(z)}
   metrics=['confirmation_f1','awareness_recall','dcr','tx_packets','energy_mj','false_confirmation_rate','false_awareness_rate','network_false_alarm']
   for m in metrics:
    vals=[num(r,m) for r in z]; entry[m+'_mean']=mean(vals); lo,hi=bootstrap_ci(vals,100+n+len(summary)); entry[m+'_ci_lo']=lo;entry[m+'_ci_hi']=hi
   summary.append(entry)
# paired diffs payoff-original
paired=[]; tests=[]
for e in ['deterministic','physical_pulse','absent']:
 for n in [20,50,100]:
  a={int(float(r['run'])):r for r in rows if r['event_model']==e and int(float(r['nodes']))==n and r['policy']=='dstep'}
  b={int(float(r['run'])):r for r in rows if r['event_model']==e and int(float(r['nodes']))==n and r['policy']=='dstep_payoff'}
  metrics=(['confirmation_f1','awareness_recall','dcr','tx_packets','energy_mj'] if e!='absent' else ['false_confirmation_rate','false_awareness_rate','network_false_alarm','tx_packets','energy_mj'])
  for m in metrics:
   runs=sorted(set(a)&set(b)); diffs=[num(b[r],m)-num(a[r],m) for r in runs]
   lo,hi=bootstrap_ci(diffs,999+n+len(paired)); pv=float('nan')
   if wilcoxon is not None and any(abs(x)>1e-12 for x in diffs):
    try: pv=float(wilcoxon(diffs,zero_method='pratt',alternative='two-sided').pvalue)
    except: pass
   rec={'event_model':e,'nodes':n,'metric':m,'runs':len(runs),'mean_diff_payoff_minus_dstep':mean(diffs),'ci_lo':lo,'ci_hi':hi,'cohen_dz':dz(diffs),'wilcoxon_p':pv}
   paired.append(rec); tests.append(rec)
# Holm correction over all non-nan paired tests
valid=[r for r in tests if not math.isnan(r['wilcoxon_p'])]
order=sorted(range(len(valid)), key=lambda i: valid[i]['wilcoxon_p']); M=len(valid); adj=[None]*M; running=0
for rank,idx in enumerate(order):
 raw=valid[idx]['wilcoxon_p']; val=min(1.0,(M-rank)*raw); running=max(running,val); adj[idx]=running
for i,r in enumerate(valid):r['holm_p']=adj[i]
for r in paired:
 if 'holm_p' not in r:r['holm_p']=float('nan')
def write(path,data):
 ks=[];seen=set()
 for r in data:
  for k in r:
   if k not in seen:seen.add(k);ks.append(k)
 with open(path,'w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=ks);w.writeheader();w.writerows(data)
write(OUT/'core_summary.csv',summary);write(OUT/'core_paired.csv',paired)
# report
lines=['# v0.50 frozen 30-seed core hold-out','', 'Seeds 5,000,000+ were held out from all v0.42-v0.49 development/tuning. v0.50 parameters were frozen before these runs.','', '## Means (95% bootstrap CI)','']
for e in ['deterministic','physical_pulse']:
 lines += [f'### {e}','', '| N | Policy | Confirmation F1 | Awareness | DCR | TX | Energy mJ |','|---:|---|---:|---:|---:|---:|---:|']
 for n in [20,50,100]:
  for p in ['dstep','dstep_payoff']:
   r=next(x for x in summary if x['event_model']==e and x['nodes']==n and x['policy']==p)
   def fmt(m):return f"{r[m+'_mean']:.3f} [{r[m+'_ci_lo']:.3f},{r[m+'_ci_hi']:.3f}]"
   lines.append(f"| {n} | {p} | {fmt('confirmation_f1')} | {fmt('awareness_recall')} | {fmt('dcr')} | {r['tx_packets_mean']:.1f} | {r['energy_mj_mean']:.1f} |")
 lines.append('')
lines += ['### event absent','', '| N | Policy | False confirmation | False awareness | Network false-alarm runs | TX | Energy mJ |','|---:|---|---:|---:|---:|---:|---:|']
for n in [20,50,100]:
 for p in ['dstep','dstep_payoff']:
  r=next(x for x in summary if x['event_model']=='absent' and x['nodes']==n and x['policy']==p)
  lines.append(f"| {n} | {p} | {r['false_confirmation_rate_mean']:.4f} | {r['false_awareness_rate_mean']:.4f} | {r['network_false_alarm_mean']*30:.0f}/30 | {r['tx_packets_mean']:.1f} | {r['energy_mj_mean']:.1f} |")
lines += ['', '## Paired payoff-minus-original D-STEP','', '| Event | N | Metric | Mean Δ | 95% bootstrap CI | dz | Holm p |','|---|---:|---|---:|---:|---:|---:|']
for r in paired:
 lines.append(f"| {r['event_model']} | {r['nodes']} | {r['metric']} | {r['mean_diff_payoff_minus_dstep']:.4f} | [{r['ci_lo']:.4f},{r['ci_hi']:.4f}] | {r['cohen_dz']:.3f} | {r['holm_p']:.4g} |")
(OUT/'V050_CORE_HOLDOUT_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print(OUT/'V050_CORE_HOLDOUT_REPORT.md')
